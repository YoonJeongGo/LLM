import hashlib
import json
import threading

import pytest

from edu_tutor.models import runtime
from edu_tutor.models.worker import emit
from edu_tutor.models.vision_runtime import transcribe
from edu_tutor.speech.provider import pronunciation


def test_metadata_event_can_describe_worker_kind(capsys):
    emit("metadata", kind="text", finish_reason="eos")
    value = json.loads(capsys.readouterr().out)
    assert value == {"type": "metadata", "kind": "text", "finish_reason": "eos"}


def test_partial_answer_is_never_completed(monkeypatch, tmp_path):
    monkeypatch.setattr(runtime, "model_status", lambda *_: {"ready": True})
    monkeypatch.setattr(runtime, "run_worker", lambda *_args, **_kwargs: iter([
        {"type": "delta", "text": "아직 완성되지 않은 답변"},
        {"type": "metadata", "finish_reason": "length_or_timeout"}, {"type":"done"}]))
    result = runtime.generate([{"role":"user","content":"질문"}],root=tmp_path)
    assert next(result) == "아직 완성되지 않은 답변"
    with pytest.raises(runtime.GenerationIncomplete):
        next(result)


def test_eos_answer_completes(monkeypatch, tmp_path):
    monkeypatch.setattr(runtime, "model_status", lambda *_: {"ready": True})
    monkeypatch.setattr(runtime, "run_worker", lambda *_args, **_kwargs: iter([
        {"type": "delta", "text": "설명"}, {"type": "metadata", "finish_reason": "eos"}, {"type":"done"}]))
    assert list(runtime.generate([{"role":"user","content":"질문"}],root=tmp_path)) == ["설명"]


def test_vision_only_accepts_registered_local_photos(tmp_path):
    outside = tmp_path / "not-a-photo.png"
    outside.write_bytes(b"not really an image")
    with pytest.raises(ValueError, match="registered"):
        transcribe(outside, root=tmp_path)


def test_speech_dictionary_preserves_values():
    assert pronunciation("COUNT(*) = 3, COUNT(v) = 2, NULL = 1") == "카운트 별표 = 3, COUNT(v) = 2, 널 = 1"
