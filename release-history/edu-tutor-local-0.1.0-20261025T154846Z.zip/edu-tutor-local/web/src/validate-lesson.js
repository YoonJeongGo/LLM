// Generated from lesson_plan.schema.json. Do not edit by hand.
"use strict";
export const validate = validate20;
export default validate20;
const schema31 = {"type":"object","additionalProperties":false,"properties":{"schema_version":{"const":"1.0"},"lesson_id":{"type":"string","minLength":1},"title":{"type":"string","minLength":1},"goal":{"type":"string","minLength":1},"question_text":{"type":"string","minLength":1},"problem_source":{"enum":["typed_user_input","confirmed_image","self_authored_example"]},"provenance":{"enum":["demo_fixture","model_generated","human_authored"]},"source_refs":{"type":"array","items":{"type":"object","additionalProperties":false,"properties":{"document_id":{"type":"string","minLength":1},"chunk_id":{"type":"string","minLength":1},"label":{"type":"string","minLength":1}},"required":["document_id","chunk_id","label"]}},"verification":{"type":"object","additionalProperties":false,"properties":{"status":{"enum":["unverified","fixture_sql_checked","sql_executed","human_reviewed"]},"scope":{"type":"string","minLength":1},"limitations":{"type":"array","items":{"type":"string","minLength":1}}},"required":["status","scope","limitations"]},"steps":{"type":"array","items":{"type":"object","additionalProperties":false,"properties":{"id":{"type":"string","minLength":1},"title":{"type":"string","minLength":1},"speech":{"type":"string","minLength":1},"board_actions":{"type":"array","items":{"oneOf":[{"type":"object","properties":{"type":{"const":"text"},"element_id":{"type":"string","minLength":1},"slot":{"enum":["main","left","right","bottom","overlay"]},"text":{"type":"string","minLength":1}},"required":["type","element_id","slot","text"],"additionalProperties":false},{"type":"object","properties":{"type":{"const":"equation"},"element_id":{"type":"string","minLength":1},"slot":{"enum":["main","left","right","bottom","overlay"]},"latex":{"type":"string","minLength":1}},"required":["type","element_id","slot","latex"],"additionalProperties":false},{"type":"object","properties":{"type":{"const":"table"},"element_id":{"type":"string","minLength":1},"slot":{"enum":["main","left","right","bottom","overlay"]},"columns":{"type":"array","minItems":1,"items":{"type":"string"}},"rows":{"type":"array","items":{"type":"array","items":{"type":["string","number","boolean","null"]}}},"caption":{"type":"string"}},"required":["type","element_id","slot","columns","rows"],"additionalProperties":false},{"type":"object","properties":{"type":{"const":"code"},"element_id":{"type":"string","minLength":1},"slot":{"enum":["main","left","right","bottom","overlay"]},"language":{"enum":["sql","python","java","c","text"]},"code":{"type":"string","minLength":1}},"required":["type","element_id","slot","language","code"],"additionalProperties":false},{"type":"object","properties":{"type":{"const":"highlight"},"element_id":{"type":"string","minLength":1},"slot":{"enum":["main","left","right","bottom","overlay"]},"target_element_id":{"type":"string","minLength":1},"row_indices":{"type":"array","items":{"type":"integer","minimum":0}},"column_indices":{"type":"array","items":{"type":"integer","minimum":0}},"style":{"enum":["outline","underline","background"]}},"required":["type","target_element_id","style"],"additionalProperties":false},{"type":"object","properties":{"type":{"const":"arrow"},"element_id":{"type":"string","minLength":1},"slot":{"enum":["main","left","right","bottom","overlay"]},"from_element_id":{"type":"string"},"to_element_id":{"type":"string"}},"required":["type","element_id","from_element_id","to_element_id"],"additionalProperties":false},{"type":"object","properties":{"type":{"const":"clear"},"element_id":{"type":"string","minLength":1},"slot":{"enum":["main","left","right","bottom","overlay"]},"target":{"type":"string","minLength":1}},"required":["type","target"],"additionalProperties":false}]}},"gesture":{"type":"object","additionalProperties":false,"properties":{"kind":{"enum":["idle","look_board","point","write","explain"]},"target_element_id":{"type":["string","null"]}},"required":["kind","target_element_id"]}},"required":["id","title","speech","board_actions","gesture"]},"minItems":1,"maxItems":12},"final_summary":{"type":"string","minLength":1}},"required":["schema_version","lesson_id","title","goal","question_text","problem_source","provenance","source_refs","verification","steps","final_summary"],"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"urn:edu-tutor:lesson-plan:1","title":"AI 강의실 강의 계획 v1"};
const func1 = Object.prototype.hasOwnProperty;
import func2 from "ajv/dist/runtime/ucs2length.js";

function validate20(data, {instancePath="", parentData, parentDataProperty, rootData=data, dynamicAnchors={}}={}){
/*# sourceURL="urn:edu-tutor:lesson-plan:1" */;
let vErrors = null;
let errors = 0;
const evaluated0 = validate20.evaluated;
if(evaluated0.dynamicProps){
evaluated0.props = undefined;
}
if(evaluated0.dynamicItems){
evaluated0.items = undefined;
}
if(data && typeof data == "object" && !Array.isArray(data)){
if(data.schema_version === undefined){
const err0 = {instancePath,schemaPath:"#/required",keyword:"required",params:{missingProperty: "schema_version"},message:"must have required property '"+"schema_version"+"'"};
if(vErrors === null){
vErrors = [err0];
}
else {
vErrors.push(err0);
}
errors++;
}
if(data.lesson_id === undefined){
const err1 = {instancePath,schemaPath:"#/required",keyword:"required",params:{missingProperty: "lesson_id"},message:"must have required property '"+"lesson_id"+"'"};
if(vErrors === null){
vErrors = [err1];
}
else {
vErrors.push(err1);
}
errors++;
}
if(data.title === undefined){
const err2 = {instancePath,schemaPath:"#/required",keyword:"required",params:{missingProperty: "title"},message:"must have required property '"+"title"+"'"};
if(vErrors === null){
vErrors = [err2];
}
else {
vErrors.push(err2);
}
errors++;
}
if(data.goal === undefined){
const err3 = {instancePath,schemaPath:"#/required",keyword:"required",params:{missingProperty: "goal"},message:"must have required property '"+"goal"+"'"};
if(vErrors === null){
vErrors = [err3];
}
else {
vErrors.push(err3);
}
errors++;
}
if(data.question_text === undefined){
const err4 = {instancePath,schemaPath:"#/required",keyword:"required",params:{missingProperty: "question_text"},message:"must have required property '"+"question_text"+"'"};
if(vErrors === null){
vErrors = [err4];
}
else {
vErrors.push(err4);
}
errors++;
}
if(data.problem_source === undefined){
const err5 = {instancePath,schemaPath:"#/required",keyword:"required",params:{missingProperty: "problem_source"},message:"must have required property '"+"problem_source"+"'"};
if(vErrors === null){
vErrors = [err5];
}
else {
vErrors.push(err5);
}
errors++;
}
if(data.provenance === undefined){
const err6 = {instancePath,schemaPath:"#/required",keyword:"required",params:{missingProperty: "provenance"},message:"must have required property '"+"provenance"+"'"};
if(vErrors === null){
vErrors = [err6];
}
else {
vErrors.push(err6);
}
errors++;
}
if(data.source_refs === undefined){
const err7 = {instancePath,schemaPath:"#/required",keyword:"required",params:{missingProperty: "source_refs"},message:"must have required property '"+"source_refs"+"'"};
if(vErrors === null){
vErrors = [err7];
}
else {
vErrors.push(err7);
}
errors++;
}
if(data.verification === undefined){
const err8 = {instancePath,schemaPath:"#/required",keyword:"required",params:{missingProperty: "verification"},message:"must have required property '"+"verification"+"'"};
if(vErrors === null){
vErrors = [err8];
}
else {
vErrors.push(err8);
}
errors++;
}
if(data.steps === undefined){
const err9 = {instancePath,schemaPath:"#/required",keyword:"required",params:{missingProperty: "steps"},message:"must have required property '"+"steps"+"'"};
if(vErrors === null){
vErrors = [err9];
}
else {
vErrors.push(err9);
}
errors++;
}
if(data.final_summary === undefined){
const err10 = {instancePath,schemaPath:"#/required",keyword:"required",params:{missingProperty: "final_summary"},message:"must have required property '"+"final_summary"+"'"};
if(vErrors === null){
vErrors = [err10];
}
else {
vErrors.push(err10);
}
errors++;
}
for(const key0 in data){
if(!(func1.call(schema31.properties, key0))){
const err11 = {instancePath,schemaPath:"#/additionalProperties",keyword:"additionalProperties",params:{additionalProperty: key0},message:"must NOT have additional properties"};
if(vErrors === null){
vErrors = [err11];
}
else {
vErrors.push(err11);
}
errors++;
}
}
if(data.schema_version !== undefined){
if("1.0" !== data.schema_version){
const err12 = {instancePath:instancePath+"/schema_version",schemaPath:"#/properties/schema_version/const",keyword:"const",params:{allowedValue: "1.0"},message:"must be equal to constant"};
if(vErrors === null){
vErrors = [err12];
}
else {
vErrors.push(err12);
}
errors++;
}
}
if(data.lesson_id !== undefined){
let data1 = data.lesson_id;
if(typeof data1 === "string"){
if(func2(data1) < 1){
const err13 = {instancePath:instancePath+"/lesson_id",schemaPath:"#/properties/lesson_id/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err13];
}
else {
vErrors.push(err13);
}
errors++;
}
}
else {
const err14 = {instancePath:instancePath+"/lesson_id",schemaPath:"#/properties/lesson_id/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err14];
}
else {
vErrors.push(err14);
}
errors++;
}
}
if(data.title !== undefined){
let data2 = data.title;
if(typeof data2 === "string"){
if(func2(data2) < 1){
const err15 = {instancePath:instancePath+"/title",schemaPath:"#/properties/title/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err15];
}
else {
vErrors.push(err15);
}
errors++;
}
}
else {
const err16 = {instancePath:instancePath+"/title",schemaPath:"#/properties/title/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err16];
}
else {
vErrors.push(err16);
}
errors++;
}
}
if(data.goal !== undefined){
let data3 = data.goal;
if(typeof data3 === "string"){
if(func2(data3) < 1){
const err17 = {instancePath:instancePath+"/goal",schemaPath:"#/properties/goal/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err17];
}
else {
vErrors.push(err17);
}
errors++;
}
}
else {
const err18 = {instancePath:instancePath+"/goal",schemaPath:"#/properties/goal/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err18];
}
else {
vErrors.push(err18);
}
errors++;
}
}
if(data.question_text !== undefined){
let data4 = data.question_text;
if(typeof data4 === "string"){
if(func2(data4) < 1){
const err19 = {instancePath:instancePath+"/question_text",schemaPath:"#/properties/question_text/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err19];
}
else {
vErrors.push(err19);
}
errors++;
}
}
else {
const err20 = {instancePath:instancePath+"/question_text",schemaPath:"#/properties/question_text/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err20];
}
else {
vErrors.push(err20);
}
errors++;
}
}
if(data.problem_source !== undefined){
let data5 = data.problem_source;
if(!(((data5 === "typed_user_input") || (data5 === "confirmed_image")) || (data5 === "self_authored_example"))){
const err21 = {instancePath:instancePath+"/problem_source",schemaPath:"#/properties/problem_source/enum",keyword:"enum",params:{allowedValues: schema31.properties.problem_source.enum},message:"must be equal to one of the allowed values"};
if(vErrors === null){
vErrors = [err21];
}
else {
vErrors.push(err21);
}
errors++;
}
}
if(data.provenance !== undefined){
let data6 = data.provenance;
if(!(((data6 === "demo_fixture") || (data6 === "model_generated")) || (data6 === "human_authored"))){
const err22 = {instancePath:instancePath+"/provenance",schemaPath:"#/properties/provenance/enum",keyword:"enum",params:{allowedValues: schema31.properties.provenance.enum},message:"must be equal to one of the allowed values"};
if(vErrors === null){
vErrors = [err22];
}
else {
vErrors.push(err22);
}
errors++;
}
}
if(data.source_refs !== undefined){
let data7 = data.source_refs;
if(Array.isArray(data7)){
const len0 = data7.length;
for(let i0=0; i0<len0; i0++){
let data8 = data7[i0];
if(data8 && typeof data8 == "object" && !Array.isArray(data8)){
if(data8.document_id === undefined){
const err23 = {instancePath:instancePath+"/source_refs/" + i0,schemaPath:"#/properties/source_refs/items/required",keyword:"required",params:{missingProperty: "document_id"},message:"must have required property '"+"document_id"+"'"};
if(vErrors === null){
vErrors = [err23];
}
else {
vErrors.push(err23);
}
errors++;
}
if(data8.chunk_id === undefined){
const err24 = {instancePath:instancePath+"/source_refs/" + i0,schemaPath:"#/properties/source_refs/items/required",keyword:"required",params:{missingProperty: "chunk_id"},message:"must have required property '"+"chunk_id"+"'"};
if(vErrors === null){
vErrors = [err24];
}
else {
vErrors.push(err24);
}
errors++;
}
if(data8.label === undefined){
const err25 = {instancePath:instancePath+"/source_refs/" + i0,schemaPath:"#/properties/source_refs/items/required",keyword:"required",params:{missingProperty: "label"},message:"must have required property '"+"label"+"'"};
if(vErrors === null){
vErrors = [err25];
}
else {
vErrors.push(err25);
}
errors++;
}
for(const key1 in data8){
if(!(((key1 === "document_id") || (key1 === "chunk_id")) || (key1 === "label"))){
const err26 = {instancePath:instancePath+"/source_refs/" + i0,schemaPath:"#/properties/source_refs/items/additionalProperties",keyword:"additionalProperties",params:{additionalProperty: key1},message:"must NOT have additional properties"};
if(vErrors === null){
vErrors = [err26];
}
else {
vErrors.push(err26);
}
errors++;
}
}
if(data8.document_id !== undefined){
let data9 = data8.document_id;
if(typeof data9 === "string"){
if(func2(data9) < 1){
const err27 = {instancePath:instancePath+"/source_refs/" + i0+"/document_id",schemaPath:"#/properties/source_refs/items/properties/document_id/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err27];
}
else {
vErrors.push(err27);
}
errors++;
}
}
else {
const err28 = {instancePath:instancePath+"/source_refs/" + i0+"/document_id",schemaPath:"#/properties/source_refs/items/properties/document_id/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err28];
}
else {
vErrors.push(err28);
}
errors++;
}
}
if(data8.chunk_id !== undefined){
let data10 = data8.chunk_id;
if(typeof data10 === "string"){
if(func2(data10) < 1){
const err29 = {instancePath:instancePath+"/source_refs/" + i0+"/chunk_id",schemaPath:"#/properties/source_refs/items/properties/chunk_id/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err29];
}
else {
vErrors.push(err29);
}
errors++;
}
}
else {
const err30 = {instancePath:instancePath+"/source_refs/" + i0+"/chunk_id",schemaPath:"#/properties/source_refs/items/properties/chunk_id/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err30];
}
else {
vErrors.push(err30);
}
errors++;
}
}
if(data8.label !== undefined){
let data11 = data8.label;
if(typeof data11 === "string"){
if(func2(data11) < 1){
const err31 = {instancePath:instancePath+"/source_refs/" + i0+"/label",schemaPath:"#/properties/source_refs/items/properties/label/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err31];
}
else {
vErrors.push(err31);
}
errors++;
}
}
else {
const err32 = {instancePath:instancePath+"/source_refs/" + i0+"/label",schemaPath:"#/properties/source_refs/items/properties/label/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err32];
}
else {
vErrors.push(err32);
}
errors++;
}
}
}
else {
const err33 = {instancePath:instancePath+"/source_refs/" + i0,schemaPath:"#/properties/source_refs/items/type",keyword:"type",params:{type: "object"},message:"must be object"};
if(vErrors === null){
vErrors = [err33];
}
else {
vErrors.push(err33);
}
errors++;
}
}
}
else {
const err34 = {instancePath:instancePath+"/source_refs",schemaPath:"#/properties/source_refs/type",keyword:"type",params:{type: "array"},message:"must be array"};
if(vErrors === null){
vErrors = [err34];
}
else {
vErrors.push(err34);
}
errors++;
}
}
if(data.verification !== undefined){
let data12 = data.verification;
if(data12 && typeof data12 == "object" && !Array.isArray(data12)){
if(data12.status === undefined){
const err35 = {instancePath:instancePath+"/verification",schemaPath:"#/properties/verification/required",keyword:"required",params:{missingProperty: "status"},message:"must have required property '"+"status"+"'"};
if(vErrors === null){
vErrors = [err35];
}
else {
vErrors.push(err35);
}
errors++;
}
if(data12.scope === undefined){
const err36 = {instancePath:instancePath+"/verification",schemaPath:"#/properties/verification/required",keyword:"required",params:{missingProperty: "scope"},message:"must have required property '"+"scope"+"'"};
if(vErrors === null){
vErrors = [err36];
}
else {
vErrors.push(err36);
}
errors++;
}
if(data12.limitations === undefined){
const err37 = {instancePath:instancePath+"/verification",schemaPath:"#/properties/verification/required",keyword:"required",params:{missingProperty: "limitations"},message:"must have required property '"+"limitations"+"'"};
if(vErrors === null){
vErrors = [err37];
}
else {
vErrors.push(err37);
}
errors++;
}
for(const key2 in data12){
if(!(((key2 === "status") || (key2 === "scope")) || (key2 === "limitations"))){
const err38 = {instancePath:instancePath+"/verification",schemaPath:"#/properties/verification/additionalProperties",keyword:"additionalProperties",params:{additionalProperty: key2},message:"must NOT have additional properties"};
if(vErrors === null){
vErrors = [err38];
}
else {
vErrors.push(err38);
}
errors++;
}
}
if(data12.status !== undefined){
let data13 = data12.status;
if(!((((data13 === "unverified") || (data13 === "fixture_sql_checked")) || (data13 === "sql_executed")) || (data13 === "human_reviewed"))){
const err39 = {instancePath:instancePath+"/verification/status",schemaPath:"#/properties/verification/properties/status/enum",keyword:"enum",params:{allowedValues: schema31.properties.verification.properties.status.enum},message:"must be equal to one of the allowed values"};
if(vErrors === null){
vErrors = [err39];
}
else {
vErrors.push(err39);
}
errors++;
}
}
if(data12.scope !== undefined){
let data14 = data12.scope;
if(typeof data14 === "string"){
if(func2(data14) < 1){
const err40 = {instancePath:instancePath+"/verification/scope",schemaPath:"#/properties/verification/properties/scope/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err40];
}
else {
vErrors.push(err40);
}
errors++;
}
}
else {
const err41 = {instancePath:instancePath+"/verification/scope",schemaPath:"#/properties/verification/properties/scope/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err41];
}
else {
vErrors.push(err41);
}
errors++;
}
}
if(data12.limitations !== undefined){
let data15 = data12.limitations;
if(Array.isArray(data15)){
const len1 = data15.length;
for(let i1=0; i1<len1; i1++){
let data16 = data15[i1];
if(typeof data16 === "string"){
if(func2(data16) < 1){
const err42 = {instancePath:instancePath+"/verification/limitations/" + i1,schemaPath:"#/properties/verification/properties/limitations/items/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err42];
}
else {
vErrors.push(err42);
}
errors++;
}
}
else {
const err43 = {instancePath:instancePath+"/verification/limitations/" + i1,schemaPath:"#/properties/verification/properties/limitations/items/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err43];
}
else {
vErrors.push(err43);
}
errors++;
}
}
}
else {
const err44 = {instancePath:instancePath+"/verification/limitations",schemaPath:"#/properties/verification/properties/limitations/type",keyword:"type",params:{type: "array"},message:"must be array"};
if(vErrors === null){
vErrors = [err44];
}
else {
vErrors.push(err44);
}
errors++;
}
}
}
else {
const err45 = {instancePath:instancePath+"/verification",schemaPath:"#/properties/verification/type",keyword:"type",params:{type: "object"},message:"must be object"};
if(vErrors === null){
vErrors = [err45];
}
else {
vErrors.push(err45);
}
errors++;
}
}
if(data.steps !== undefined){
let data17 = data.steps;
if(Array.isArray(data17)){
if(data17.length > 12){
const err46 = {instancePath:instancePath+"/steps",schemaPath:"#/properties/steps/maxItems",keyword:"maxItems",params:{limit: 12},message:"must NOT have more than 12 items"};
if(vErrors === null){
vErrors = [err46];
}
else {
vErrors.push(err46);
}
errors++;
}
if(data17.length < 1){
const err47 = {instancePath:instancePath+"/steps",schemaPath:"#/properties/steps/minItems",keyword:"minItems",params:{limit: 1},message:"must NOT have fewer than 1 items"};
if(vErrors === null){
vErrors = [err47];
}
else {
vErrors.push(err47);
}
errors++;
}
const len2 = data17.length;
for(let i2=0; i2<len2; i2++){
let data18 = data17[i2];
if(data18 && typeof data18 == "object" && !Array.isArray(data18)){
if(data18.id === undefined){
const err48 = {instancePath:instancePath+"/steps/" + i2,schemaPath:"#/properties/steps/items/required",keyword:"required",params:{missingProperty: "id"},message:"must have required property '"+"id"+"'"};
if(vErrors === null){
vErrors = [err48];
}
else {
vErrors.push(err48);
}
errors++;
}
if(data18.title === undefined){
const err49 = {instancePath:instancePath+"/steps/" + i2,schemaPath:"#/properties/steps/items/required",keyword:"required",params:{missingProperty: "title"},message:"must have required property '"+"title"+"'"};
if(vErrors === null){
vErrors = [err49];
}
else {
vErrors.push(err49);
}
errors++;
}
if(data18.speech === undefined){
const err50 = {instancePath:instancePath+"/steps/" + i2,schemaPath:"#/properties/steps/items/required",keyword:"required",params:{missingProperty: "speech"},message:"must have required property '"+"speech"+"'"};
if(vErrors === null){
vErrors = [err50];
}
else {
vErrors.push(err50);
}
errors++;
}
if(data18.board_actions === undefined){
const err51 = {instancePath:instancePath+"/steps/" + i2,schemaPath:"#/properties/steps/items/required",keyword:"required",params:{missingProperty: "board_actions"},message:"must have required property '"+"board_actions"+"'"};
if(vErrors === null){
vErrors = [err51];
}
else {
vErrors.push(err51);
}
errors++;
}
if(data18.gesture === undefined){
const err52 = {instancePath:instancePath+"/steps/" + i2,schemaPath:"#/properties/steps/items/required",keyword:"required",params:{missingProperty: "gesture"},message:"must have required property '"+"gesture"+"'"};
if(vErrors === null){
vErrors = [err52];
}
else {
vErrors.push(err52);
}
errors++;
}
for(const key3 in data18){
if(!(((((key3 === "id") || (key3 === "title")) || (key3 === "speech")) || (key3 === "board_actions")) || (key3 === "gesture"))){
const err53 = {instancePath:instancePath+"/steps/" + i2,schemaPath:"#/properties/steps/items/additionalProperties",keyword:"additionalProperties",params:{additionalProperty: key3},message:"must NOT have additional properties"};
if(vErrors === null){
vErrors = [err53];
}
else {
vErrors.push(err53);
}
errors++;
}
}
if(data18.id !== undefined){
let data19 = data18.id;
if(typeof data19 === "string"){
if(func2(data19) < 1){
const err54 = {instancePath:instancePath+"/steps/" + i2+"/id",schemaPath:"#/properties/steps/items/properties/id/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err54];
}
else {
vErrors.push(err54);
}
errors++;
}
}
else {
const err55 = {instancePath:instancePath+"/steps/" + i2+"/id",schemaPath:"#/properties/steps/items/properties/id/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err55];
}
else {
vErrors.push(err55);
}
errors++;
}
}
if(data18.title !== undefined){
let data20 = data18.title;
if(typeof data20 === "string"){
if(func2(data20) < 1){
const err56 = {instancePath:instancePath+"/steps/" + i2+"/title",schemaPath:"#/properties/steps/items/properties/title/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err56];
}
else {
vErrors.push(err56);
}
errors++;
}
}
else {
const err57 = {instancePath:instancePath+"/steps/" + i2+"/title",schemaPath:"#/properties/steps/items/properties/title/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err57];
}
else {
vErrors.push(err57);
}
errors++;
}
}
if(data18.speech !== undefined){
let data21 = data18.speech;
if(typeof data21 === "string"){
if(func2(data21) < 1){
const err58 = {instancePath:instancePath+"/steps/" + i2+"/speech",schemaPath:"#/properties/steps/items/properties/speech/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err58];
}
else {
vErrors.push(err58);
}
errors++;
}
}
else {
const err59 = {instancePath:instancePath+"/steps/" + i2+"/speech",schemaPath:"#/properties/steps/items/properties/speech/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err59];
}
else {
vErrors.push(err59);
}
errors++;
}
}
if(data18.board_actions !== undefined){
let data22 = data18.board_actions;
if(Array.isArray(data22)){
const len3 = data22.length;
for(let i3=0; i3<len3; i3++){
let data23 = data22[i3];
const _errs48 = errors;
let valid12 = false;
let passing0 = null;
const _errs49 = errors;
if(data23 && typeof data23 == "object" && !Array.isArray(data23)){
if(data23.type === undefined){
const err60 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/0/required",keyword:"required",params:{missingProperty: "type"},message:"must have required property '"+"type"+"'"};
if(vErrors === null){
vErrors = [err60];
}
else {
vErrors.push(err60);
}
errors++;
}
if(data23.element_id === undefined){
const err61 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/0/required",keyword:"required",params:{missingProperty: "element_id"},message:"must have required property '"+"element_id"+"'"};
if(vErrors === null){
vErrors = [err61];
}
else {
vErrors.push(err61);
}
errors++;
}
if(data23.slot === undefined){
const err62 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/0/required",keyword:"required",params:{missingProperty: "slot"},message:"must have required property '"+"slot"+"'"};
if(vErrors === null){
vErrors = [err62];
}
else {
vErrors.push(err62);
}
errors++;
}
if(data23.text === undefined){
const err63 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/0/required",keyword:"required",params:{missingProperty: "text"},message:"must have required property '"+"text"+"'"};
if(vErrors === null){
vErrors = [err63];
}
else {
vErrors.push(err63);
}
errors++;
}
for(const key4 in data23){
if(!((((key4 === "type") || (key4 === "element_id")) || (key4 === "slot")) || (key4 === "text"))){
const err64 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/0/additionalProperties",keyword:"additionalProperties",params:{additionalProperty: key4},message:"must NOT have additional properties"};
if(vErrors === null){
vErrors = [err64];
}
else {
vErrors.push(err64);
}
errors++;
}
}
if(data23.type !== undefined){
if("text" !== data23.type){
const err65 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/type",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/0/properties/type/const",keyword:"const",params:{allowedValue: "text"},message:"must be equal to constant"};
if(vErrors === null){
vErrors = [err65];
}
else {
vErrors.push(err65);
}
errors++;
}
}
if(data23.element_id !== undefined){
let data25 = data23.element_id;
if(typeof data25 === "string"){
if(func2(data25) < 1){
const err66 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/element_id",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/0/properties/element_id/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err66];
}
else {
vErrors.push(err66);
}
errors++;
}
}
else {
const err67 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/element_id",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/0/properties/element_id/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err67];
}
else {
vErrors.push(err67);
}
errors++;
}
}
if(data23.slot !== undefined){
let data26 = data23.slot;
if(!(((((data26 === "main") || (data26 === "left")) || (data26 === "right")) || (data26 === "bottom")) || (data26 === "overlay"))){
const err68 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/slot",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/0/properties/slot/enum",keyword:"enum",params:{allowedValues: schema31.properties.steps.items.properties.board_actions.items.oneOf[0].properties.slot.enum},message:"must be equal to one of the allowed values"};
if(vErrors === null){
vErrors = [err68];
}
else {
vErrors.push(err68);
}
errors++;
}
}
if(data23.text !== undefined){
let data27 = data23.text;
if(typeof data27 === "string"){
if(func2(data27) < 1){
const err69 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/text",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/0/properties/text/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err69];
}
else {
vErrors.push(err69);
}
errors++;
}
}
else {
const err70 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/text",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/0/properties/text/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err70];
}
else {
vErrors.push(err70);
}
errors++;
}
}
}
else {
const err71 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/0/type",keyword:"type",params:{type: "object"},message:"must be object"};
if(vErrors === null){
vErrors = [err71];
}
else {
vErrors.push(err71);
}
errors++;
}
var _valid0 = _errs49 === errors;
if(_valid0){
valid12 = true;
passing0 = 0;
var props0 = true;
}
const _errs58 = errors;
if(data23 && typeof data23 == "object" && !Array.isArray(data23)){
if(data23.type === undefined){
const err72 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/1/required",keyword:"required",params:{missingProperty: "type"},message:"must have required property '"+"type"+"'"};
if(vErrors === null){
vErrors = [err72];
}
else {
vErrors.push(err72);
}
errors++;
}
if(data23.element_id === undefined){
const err73 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/1/required",keyword:"required",params:{missingProperty: "element_id"},message:"must have required property '"+"element_id"+"'"};
if(vErrors === null){
vErrors = [err73];
}
else {
vErrors.push(err73);
}
errors++;
}
if(data23.slot === undefined){
const err74 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/1/required",keyword:"required",params:{missingProperty: "slot"},message:"must have required property '"+"slot"+"'"};
if(vErrors === null){
vErrors = [err74];
}
else {
vErrors.push(err74);
}
errors++;
}
if(data23.latex === undefined){
const err75 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/1/required",keyword:"required",params:{missingProperty: "latex"},message:"must have required property '"+"latex"+"'"};
if(vErrors === null){
vErrors = [err75];
}
else {
vErrors.push(err75);
}
errors++;
}
for(const key5 in data23){
if(!((((key5 === "type") || (key5 === "element_id")) || (key5 === "slot")) || (key5 === "latex"))){
const err76 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/1/additionalProperties",keyword:"additionalProperties",params:{additionalProperty: key5},message:"must NOT have additional properties"};
if(vErrors === null){
vErrors = [err76];
}
else {
vErrors.push(err76);
}
errors++;
}
}
if(data23.type !== undefined){
if("equation" !== data23.type){
const err77 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/type",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/1/properties/type/const",keyword:"const",params:{allowedValue: "equation"},message:"must be equal to constant"};
if(vErrors === null){
vErrors = [err77];
}
else {
vErrors.push(err77);
}
errors++;
}
}
if(data23.element_id !== undefined){
let data29 = data23.element_id;
if(typeof data29 === "string"){
if(func2(data29) < 1){
const err78 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/element_id",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/1/properties/element_id/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err78];
}
else {
vErrors.push(err78);
}
errors++;
}
}
else {
const err79 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/element_id",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/1/properties/element_id/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err79];
}
else {
vErrors.push(err79);
}
errors++;
}
}
if(data23.slot !== undefined){
let data30 = data23.slot;
if(!(((((data30 === "main") || (data30 === "left")) || (data30 === "right")) || (data30 === "bottom")) || (data30 === "overlay"))){
const err80 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/slot",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/1/properties/slot/enum",keyword:"enum",params:{allowedValues: schema31.properties.steps.items.properties.board_actions.items.oneOf[1].properties.slot.enum},message:"must be equal to one of the allowed values"};
if(vErrors === null){
vErrors = [err80];
}
else {
vErrors.push(err80);
}
errors++;
}
}
if(data23.latex !== undefined){
let data31 = data23.latex;
if(typeof data31 === "string"){
if(func2(data31) < 1){
const err81 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/latex",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/1/properties/latex/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err81];
}
else {
vErrors.push(err81);
}
errors++;
}
}
else {
const err82 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/latex",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/1/properties/latex/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err82];
}
else {
vErrors.push(err82);
}
errors++;
}
}
}
else {
const err83 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/1/type",keyword:"type",params:{type: "object"},message:"must be object"};
if(vErrors === null){
vErrors = [err83];
}
else {
vErrors.push(err83);
}
errors++;
}
var _valid0 = _errs58 === errors;
if(_valid0 && valid12){
valid12 = false;
passing0 = [passing0, 1];
}
else {
if(_valid0){
valid12 = true;
passing0 = 1;
if(props0 !== true){
props0 = true;
}
}
const _errs67 = errors;
if(data23 && typeof data23 == "object" && !Array.isArray(data23)){
if(data23.type === undefined){
const err84 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/2/required",keyword:"required",params:{missingProperty: "type"},message:"must have required property '"+"type"+"'"};
if(vErrors === null){
vErrors = [err84];
}
else {
vErrors.push(err84);
}
errors++;
}
if(data23.element_id === undefined){
const err85 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/2/required",keyword:"required",params:{missingProperty: "element_id"},message:"must have required property '"+"element_id"+"'"};
if(vErrors === null){
vErrors = [err85];
}
else {
vErrors.push(err85);
}
errors++;
}
if(data23.slot === undefined){
const err86 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/2/required",keyword:"required",params:{missingProperty: "slot"},message:"must have required property '"+"slot"+"'"};
if(vErrors === null){
vErrors = [err86];
}
else {
vErrors.push(err86);
}
errors++;
}
if(data23.columns === undefined){
const err87 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/2/required",keyword:"required",params:{missingProperty: "columns"},message:"must have required property '"+"columns"+"'"};
if(vErrors === null){
vErrors = [err87];
}
else {
vErrors.push(err87);
}
errors++;
}
if(data23.rows === undefined){
const err88 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/2/required",keyword:"required",params:{missingProperty: "rows"},message:"must have required property '"+"rows"+"'"};
if(vErrors === null){
vErrors = [err88];
}
else {
vErrors.push(err88);
}
errors++;
}
for(const key6 in data23){
if(!((((((key6 === "type") || (key6 === "element_id")) || (key6 === "slot")) || (key6 === "columns")) || (key6 === "rows")) || (key6 === "caption"))){
const err89 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/2/additionalProperties",keyword:"additionalProperties",params:{additionalProperty: key6},message:"must NOT have additional properties"};
if(vErrors === null){
vErrors = [err89];
}
else {
vErrors.push(err89);
}
errors++;
}
}
if(data23.type !== undefined){
if("table" !== data23.type){
const err90 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/type",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/2/properties/type/const",keyword:"const",params:{allowedValue: "table"},message:"must be equal to constant"};
if(vErrors === null){
vErrors = [err90];
}
else {
vErrors.push(err90);
}
errors++;
}
}
if(data23.element_id !== undefined){
let data33 = data23.element_id;
if(typeof data33 === "string"){
if(func2(data33) < 1){
const err91 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/element_id",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/2/properties/element_id/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err91];
}
else {
vErrors.push(err91);
}
errors++;
}
}
else {
const err92 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/element_id",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/2/properties/element_id/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err92];
}
else {
vErrors.push(err92);
}
errors++;
}
}
if(data23.slot !== undefined){
let data34 = data23.slot;
if(!(((((data34 === "main") || (data34 === "left")) || (data34 === "right")) || (data34 === "bottom")) || (data34 === "overlay"))){
const err93 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/slot",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/2/properties/slot/enum",keyword:"enum",params:{allowedValues: schema31.properties.steps.items.properties.board_actions.items.oneOf[2].properties.slot.enum},message:"must be equal to one of the allowed values"};
if(vErrors === null){
vErrors = [err93];
}
else {
vErrors.push(err93);
}
errors++;
}
}
if(data23.columns !== undefined){
let data35 = data23.columns;
if(Array.isArray(data35)){
if(data35.length < 1){
const err94 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/columns",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/2/properties/columns/minItems",keyword:"minItems",params:{limit: 1},message:"must NOT have fewer than 1 items"};
if(vErrors === null){
vErrors = [err94];
}
else {
vErrors.push(err94);
}
errors++;
}
const len4 = data35.length;
for(let i4=0; i4<len4; i4++){
if(typeof data35[i4] !== "string"){
const err95 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/columns/" + i4,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/2/properties/columns/items/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err95];
}
else {
vErrors.push(err95);
}
errors++;
}
}
}
else {
const err96 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/columns",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/2/properties/columns/type",keyword:"type",params:{type: "array"},message:"must be array"};
if(vErrors === null){
vErrors = [err96];
}
else {
vErrors.push(err96);
}
errors++;
}
}
if(data23.rows !== undefined){
let data37 = data23.rows;
if(Array.isArray(data37)){
const len5 = data37.length;
for(let i5=0; i5<len5; i5++){
let data38 = data37[i5];
if(Array.isArray(data38)){
const len6 = data38.length;
for(let i6=0; i6<len6; i6++){
let data39 = data38[i6];
if((((typeof data39 !== "string") && (!(typeof data39 == "number"))) && (typeof data39 !== "boolean")) && (data39 !== null)){
const err97 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/rows/" + i5+"/" + i6,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/2/properties/rows/items/items/type",keyword:"type",params:{type: schema31.properties.steps.items.properties.board_actions.items.oneOf[2].properties.rows.items.items.type},message:"must be string,number,boolean,null"};
if(vErrors === null){
vErrors = [err97];
}
else {
vErrors.push(err97);
}
errors++;
}
}
}
else {
const err98 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/rows/" + i5,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/2/properties/rows/items/type",keyword:"type",params:{type: "array"},message:"must be array"};
if(vErrors === null){
vErrors = [err98];
}
else {
vErrors.push(err98);
}
errors++;
}
}
}
else {
const err99 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/rows",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/2/properties/rows/type",keyword:"type",params:{type: "array"},message:"must be array"};
if(vErrors === null){
vErrors = [err99];
}
else {
vErrors.push(err99);
}
errors++;
}
}
if(data23.caption !== undefined){
if(typeof data23.caption !== "string"){
const err100 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/caption",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/2/properties/caption/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err100];
}
else {
vErrors.push(err100);
}
errors++;
}
}
}
else {
const err101 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/2/type",keyword:"type",params:{type: "object"},message:"must be object"};
if(vErrors === null){
vErrors = [err101];
}
else {
vErrors.push(err101);
}
errors++;
}
var _valid0 = _errs67 === errors;
if(_valid0 && valid12){
valid12 = false;
passing0 = [passing0, 2];
}
else {
if(_valid0){
valid12 = true;
passing0 = 2;
if(props0 !== true){
props0 = true;
}
}
const _errs86 = errors;
if(data23 && typeof data23 == "object" && !Array.isArray(data23)){
if(data23.type === undefined){
const err102 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/3/required",keyword:"required",params:{missingProperty: "type"},message:"must have required property '"+"type"+"'"};
if(vErrors === null){
vErrors = [err102];
}
else {
vErrors.push(err102);
}
errors++;
}
if(data23.element_id === undefined){
const err103 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/3/required",keyword:"required",params:{missingProperty: "element_id"},message:"must have required property '"+"element_id"+"'"};
if(vErrors === null){
vErrors = [err103];
}
else {
vErrors.push(err103);
}
errors++;
}
if(data23.slot === undefined){
const err104 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/3/required",keyword:"required",params:{missingProperty: "slot"},message:"must have required property '"+"slot"+"'"};
if(vErrors === null){
vErrors = [err104];
}
else {
vErrors.push(err104);
}
errors++;
}
if(data23.language === undefined){
const err105 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/3/required",keyword:"required",params:{missingProperty: "language"},message:"must have required property '"+"language"+"'"};
if(vErrors === null){
vErrors = [err105];
}
else {
vErrors.push(err105);
}
errors++;
}
if(data23.code === undefined){
const err106 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/3/required",keyword:"required",params:{missingProperty: "code"},message:"must have required property '"+"code"+"'"};
if(vErrors === null){
vErrors = [err106];
}
else {
vErrors.push(err106);
}
errors++;
}
for(const key7 in data23){
if(!(((((key7 === "type") || (key7 === "element_id")) || (key7 === "slot")) || (key7 === "language")) || (key7 === "code"))){
const err107 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/3/additionalProperties",keyword:"additionalProperties",params:{additionalProperty: key7},message:"must NOT have additional properties"};
if(vErrors === null){
vErrors = [err107];
}
else {
vErrors.push(err107);
}
errors++;
}
}
if(data23.type !== undefined){
if("code" !== data23.type){
const err108 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/type",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/3/properties/type/const",keyword:"const",params:{allowedValue: "code"},message:"must be equal to constant"};
if(vErrors === null){
vErrors = [err108];
}
else {
vErrors.push(err108);
}
errors++;
}
}
if(data23.element_id !== undefined){
let data42 = data23.element_id;
if(typeof data42 === "string"){
if(func2(data42) < 1){
const err109 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/element_id",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/3/properties/element_id/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err109];
}
else {
vErrors.push(err109);
}
errors++;
}
}
else {
const err110 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/element_id",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/3/properties/element_id/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err110];
}
else {
vErrors.push(err110);
}
errors++;
}
}
if(data23.slot !== undefined){
let data43 = data23.slot;
if(!(((((data43 === "main") || (data43 === "left")) || (data43 === "right")) || (data43 === "bottom")) || (data43 === "overlay"))){
const err111 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/slot",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/3/properties/slot/enum",keyword:"enum",params:{allowedValues: schema31.properties.steps.items.properties.board_actions.items.oneOf[3].properties.slot.enum},message:"must be equal to one of the allowed values"};
if(vErrors === null){
vErrors = [err111];
}
else {
vErrors.push(err111);
}
errors++;
}
}
if(data23.language !== undefined){
let data44 = data23.language;
if(!(((((data44 === "sql") || (data44 === "python")) || (data44 === "java")) || (data44 === "c")) || (data44 === "text"))){
const err112 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/language",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/3/properties/language/enum",keyword:"enum",params:{allowedValues: schema31.properties.steps.items.properties.board_actions.items.oneOf[3].properties.language.enum},message:"must be equal to one of the allowed values"};
if(vErrors === null){
vErrors = [err112];
}
else {
vErrors.push(err112);
}
errors++;
}
}
if(data23.code !== undefined){
let data45 = data23.code;
if(typeof data45 === "string"){
if(func2(data45) < 1){
const err113 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/code",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/3/properties/code/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err113];
}
else {
vErrors.push(err113);
}
errors++;
}
}
else {
const err114 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/code",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/3/properties/code/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err114];
}
else {
vErrors.push(err114);
}
errors++;
}
}
}
else {
const err115 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/3/type",keyword:"type",params:{type: "object"},message:"must be object"};
if(vErrors === null){
vErrors = [err115];
}
else {
vErrors.push(err115);
}
errors++;
}
var _valid0 = _errs86 === errors;
if(_valid0 && valid12){
valid12 = false;
passing0 = [passing0, 3];
}
else {
if(_valid0){
valid12 = true;
passing0 = 3;
if(props0 !== true){
props0 = true;
}
}
const _errs96 = errors;
if(data23 && typeof data23 == "object" && !Array.isArray(data23)){
if(data23.type === undefined){
const err116 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/4/required",keyword:"required",params:{missingProperty: "type"},message:"must have required property '"+"type"+"'"};
if(vErrors === null){
vErrors = [err116];
}
else {
vErrors.push(err116);
}
errors++;
}
if(data23.target_element_id === undefined){
const err117 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/4/required",keyword:"required",params:{missingProperty: "target_element_id"},message:"must have required property '"+"target_element_id"+"'"};
if(vErrors === null){
vErrors = [err117];
}
else {
vErrors.push(err117);
}
errors++;
}
if(data23.style === undefined){
const err118 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/4/required",keyword:"required",params:{missingProperty: "style"},message:"must have required property '"+"style"+"'"};
if(vErrors === null){
vErrors = [err118];
}
else {
vErrors.push(err118);
}
errors++;
}
for(const key8 in data23){
if(!(((((((key8 === "type") || (key8 === "element_id")) || (key8 === "slot")) || (key8 === "target_element_id")) || (key8 === "row_indices")) || (key8 === "column_indices")) || (key8 === "style"))){
const err119 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/4/additionalProperties",keyword:"additionalProperties",params:{additionalProperty: key8},message:"must NOT have additional properties"};
if(vErrors === null){
vErrors = [err119];
}
else {
vErrors.push(err119);
}
errors++;
}
}
if(data23.type !== undefined){
if("highlight" !== data23.type){
const err120 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/type",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/4/properties/type/const",keyword:"const",params:{allowedValue: "highlight"},message:"must be equal to constant"};
if(vErrors === null){
vErrors = [err120];
}
else {
vErrors.push(err120);
}
errors++;
}
}
if(data23.element_id !== undefined){
let data47 = data23.element_id;
if(typeof data47 === "string"){
if(func2(data47) < 1){
const err121 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/element_id",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/4/properties/element_id/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err121];
}
else {
vErrors.push(err121);
}
errors++;
}
}
else {
const err122 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/element_id",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/4/properties/element_id/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err122];
}
else {
vErrors.push(err122);
}
errors++;
}
}
if(data23.slot !== undefined){
let data48 = data23.slot;
if(!(((((data48 === "main") || (data48 === "left")) || (data48 === "right")) || (data48 === "bottom")) || (data48 === "overlay"))){
const err123 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/slot",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/4/properties/slot/enum",keyword:"enum",params:{allowedValues: schema31.properties.steps.items.properties.board_actions.items.oneOf[4].properties.slot.enum},message:"must be equal to one of the allowed values"};
if(vErrors === null){
vErrors = [err123];
}
else {
vErrors.push(err123);
}
errors++;
}
}
if(data23.target_element_id !== undefined){
let data49 = data23.target_element_id;
if(typeof data49 === "string"){
if(func2(data49) < 1){
const err124 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/target_element_id",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/4/properties/target_element_id/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err124];
}
else {
vErrors.push(err124);
}
errors++;
}
}
else {
const err125 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/target_element_id",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/4/properties/target_element_id/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err125];
}
else {
vErrors.push(err125);
}
errors++;
}
}
if(data23.row_indices !== undefined){
let data50 = data23.row_indices;
if(Array.isArray(data50)){
const len7 = data50.length;
for(let i7=0; i7<len7; i7++){
let data51 = data50[i7];
if(!((typeof data51 == "number") && (!(data51 % 1) && !isNaN(data51)))){
const err126 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/row_indices/" + i7,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/4/properties/row_indices/items/type",keyword:"type",params:{type: "integer"},message:"must be integer"};
if(vErrors === null){
vErrors = [err126];
}
else {
vErrors.push(err126);
}
errors++;
}
if(typeof data51 == "number"){
if(data51 < 0 || isNaN(data51)){
const err127 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/row_indices/" + i7,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/4/properties/row_indices/items/minimum",keyword:"minimum",params:{comparison: ">=", limit: 0},message:"must be >= 0"};
if(vErrors === null){
vErrors = [err127];
}
else {
vErrors.push(err127);
}
errors++;
}
}
}
}
else {
const err128 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/row_indices",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/4/properties/row_indices/type",keyword:"type",params:{type: "array"},message:"must be array"};
if(vErrors === null){
vErrors = [err128];
}
else {
vErrors.push(err128);
}
errors++;
}
}
if(data23.column_indices !== undefined){
let data52 = data23.column_indices;
if(Array.isArray(data52)){
const len8 = data52.length;
for(let i8=0; i8<len8; i8++){
let data53 = data52[i8];
if(!((typeof data53 == "number") && (!(data53 % 1) && !isNaN(data53)))){
const err129 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/column_indices/" + i8,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/4/properties/column_indices/items/type",keyword:"type",params:{type: "integer"},message:"must be integer"};
if(vErrors === null){
vErrors = [err129];
}
else {
vErrors.push(err129);
}
errors++;
}
if(typeof data53 == "number"){
if(data53 < 0 || isNaN(data53)){
const err130 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/column_indices/" + i8,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/4/properties/column_indices/items/minimum",keyword:"minimum",params:{comparison: ">=", limit: 0},message:"must be >= 0"};
if(vErrors === null){
vErrors = [err130];
}
else {
vErrors.push(err130);
}
errors++;
}
}
}
}
else {
const err131 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/column_indices",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/4/properties/column_indices/type",keyword:"type",params:{type: "array"},message:"must be array"};
if(vErrors === null){
vErrors = [err131];
}
else {
vErrors.push(err131);
}
errors++;
}
}
if(data23.style !== undefined){
let data54 = data23.style;
if(!(((data54 === "outline") || (data54 === "underline")) || (data54 === "background"))){
const err132 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/style",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/4/properties/style/enum",keyword:"enum",params:{allowedValues: schema31.properties.steps.items.properties.board_actions.items.oneOf[4].properties.style.enum},message:"must be equal to one of the allowed values"};
if(vErrors === null){
vErrors = [err132];
}
else {
vErrors.push(err132);
}
errors++;
}
}
}
else {
const err133 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/4/type",keyword:"type",params:{type: "object"},message:"must be object"};
if(vErrors === null){
vErrors = [err133];
}
else {
vErrors.push(err133);
}
errors++;
}
var _valid0 = _errs96 === errors;
if(_valid0 && valid12){
valid12 = false;
passing0 = [passing0, 4];
}
else {
if(_valid0){
valid12 = true;
passing0 = 4;
if(props0 !== true){
props0 = true;
}
}
const _errs114 = errors;
if(data23 && typeof data23 == "object" && !Array.isArray(data23)){
if(data23.type === undefined){
const err134 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/5/required",keyword:"required",params:{missingProperty: "type"},message:"must have required property '"+"type"+"'"};
if(vErrors === null){
vErrors = [err134];
}
else {
vErrors.push(err134);
}
errors++;
}
if(data23.element_id === undefined){
const err135 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/5/required",keyword:"required",params:{missingProperty: "element_id"},message:"must have required property '"+"element_id"+"'"};
if(vErrors === null){
vErrors = [err135];
}
else {
vErrors.push(err135);
}
errors++;
}
if(data23.from_element_id === undefined){
const err136 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/5/required",keyword:"required",params:{missingProperty: "from_element_id"},message:"must have required property '"+"from_element_id"+"'"};
if(vErrors === null){
vErrors = [err136];
}
else {
vErrors.push(err136);
}
errors++;
}
if(data23.to_element_id === undefined){
const err137 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/5/required",keyword:"required",params:{missingProperty: "to_element_id"},message:"must have required property '"+"to_element_id"+"'"};
if(vErrors === null){
vErrors = [err137];
}
else {
vErrors.push(err137);
}
errors++;
}
for(const key9 in data23){
if(!(((((key9 === "type") || (key9 === "element_id")) || (key9 === "slot")) || (key9 === "from_element_id")) || (key9 === "to_element_id"))){
const err138 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/5/additionalProperties",keyword:"additionalProperties",params:{additionalProperty: key9},message:"must NOT have additional properties"};
if(vErrors === null){
vErrors = [err138];
}
else {
vErrors.push(err138);
}
errors++;
}
}
if(data23.type !== undefined){
if("arrow" !== data23.type){
const err139 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/type",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/5/properties/type/const",keyword:"const",params:{allowedValue: "arrow"},message:"must be equal to constant"};
if(vErrors === null){
vErrors = [err139];
}
else {
vErrors.push(err139);
}
errors++;
}
}
if(data23.element_id !== undefined){
let data56 = data23.element_id;
if(typeof data56 === "string"){
if(func2(data56) < 1){
const err140 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/element_id",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/5/properties/element_id/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err140];
}
else {
vErrors.push(err140);
}
errors++;
}
}
else {
const err141 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/element_id",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/5/properties/element_id/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err141];
}
else {
vErrors.push(err141);
}
errors++;
}
}
if(data23.slot !== undefined){
let data57 = data23.slot;
if(!(((((data57 === "main") || (data57 === "left")) || (data57 === "right")) || (data57 === "bottom")) || (data57 === "overlay"))){
const err142 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/slot",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/5/properties/slot/enum",keyword:"enum",params:{allowedValues: schema31.properties.steps.items.properties.board_actions.items.oneOf[5].properties.slot.enum},message:"must be equal to one of the allowed values"};
if(vErrors === null){
vErrors = [err142];
}
else {
vErrors.push(err142);
}
errors++;
}
}
if(data23.from_element_id !== undefined){
if(typeof data23.from_element_id !== "string"){
const err143 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/from_element_id",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/5/properties/from_element_id/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err143];
}
else {
vErrors.push(err143);
}
errors++;
}
}
if(data23.to_element_id !== undefined){
if(typeof data23.to_element_id !== "string"){
const err144 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/to_element_id",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/5/properties/to_element_id/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err144];
}
else {
vErrors.push(err144);
}
errors++;
}
}
}
else {
const err145 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/5/type",keyword:"type",params:{type: "object"},message:"must be object"};
if(vErrors === null){
vErrors = [err145];
}
else {
vErrors.push(err145);
}
errors++;
}
var _valid0 = _errs114 === errors;
if(_valid0 && valid12){
valid12 = false;
passing0 = [passing0, 5];
}
else {
if(_valid0){
valid12 = true;
passing0 = 5;
if(props0 !== true){
props0 = true;
}
}
const _errs125 = errors;
if(data23 && typeof data23 == "object" && !Array.isArray(data23)){
if(data23.type === undefined){
const err146 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/6/required",keyword:"required",params:{missingProperty: "type"},message:"must have required property '"+"type"+"'"};
if(vErrors === null){
vErrors = [err146];
}
else {
vErrors.push(err146);
}
errors++;
}
if(data23.target === undefined){
const err147 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/6/required",keyword:"required",params:{missingProperty: "target"},message:"must have required property '"+"target"+"'"};
if(vErrors === null){
vErrors = [err147];
}
else {
vErrors.push(err147);
}
errors++;
}
for(const key10 in data23){
if(!((((key10 === "type") || (key10 === "element_id")) || (key10 === "slot")) || (key10 === "target"))){
const err148 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/6/additionalProperties",keyword:"additionalProperties",params:{additionalProperty: key10},message:"must NOT have additional properties"};
if(vErrors === null){
vErrors = [err148];
}
else {
vErrors.push(err148);
}
errors++;
}
}
if(data23.type !== undefined){
if("clear" !== data23.type){
const err149 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/type",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/6/properties/type/const",keyword:"const",params:{allowedValue: "clear"},message:"must be equal to constant"};
if(vErrors === null){
vErrors = [err149];
}
else {
vErrors.push(err149);
}
errors++;
}
}
if(data23.element_id !== undefined){
let data61 = data23.element_id;
if(typeof data61 === "string"){
if(func2(data61) < 1){
const err150 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/element_id",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/6/properties/element_id/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err150];
}
else {
vErrors.push(err150);
}
errors++;
}
}
else {
const err151 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/element_id",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/6/properties/element_id/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err151];
}
else {
vErrors.push(err151);
}
errors++;
}
}
if(data23.slot !== undefined){
let data62 = data23.slot;
if(!(((((data62 === "main") || (data62 === "left")) || (data62 === "right")) || (data62 === "bottom")) || (data62 === "overlay"))){
const err152 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/slot",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/6/properties/slot/enum",keyword:"enum",params:{allowedValues: schema31.properties.steps.items.properties.board_actions.items.oneOf[6].properties.slot.enum},message:"must be equal to one of the allowed values"};
if(vErrors === null){
vErrors = [err152];
}
else {
vErrors.push(err152);
}
errors++;
}
}
if(data23.target !== undefined){
let data63 = data23.target;
if(typeof data63 === "string"){
if(func2(data63) < 1){
const err153 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/target",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/6/properties/target/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err153];
}
else {
vErrors.push(err153);
}
errors++;
}
}
else {
const err154 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3+"/target",schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/6/properties/target/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err154];
}
else {
vErrors.push(err154);
}
errors++;
}
}
}
else {
const err155 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf/6/type",keyword:"type",params:{type: "object"},message:"must be object"};
if(vErrors === null){
vErrors = [err155];
}
else {
vErrors.push(err155);
}
errors++;
}
var _valid0 = _errs125 === errors;
if(_valid0 && valid12){
valid12 = false;
passing0 = [passing0, 6];
}
else {
if(_valid0){
valid12 = true;
passing0 = 6;
if(props0 !== true){
props0 = true;
}
}
}
}
}
}
}
}
if(!valid12){
const err156 = {instancePath:instancePath+"/steps/" + i2+"/board_actions/" + i3,schemaPath:"#/properties/steps/items/properties/board_actions/items/oneOf",keyword:"oneOf",params:{passingSchemas: passing0},message:"must match exactly one schema in oneOf"};
if(vErrors === null){
vErrors = [err156];
}
else {
vErrors.push(err156);
}
errors++;
}
else {
errors = _errs48;
if(vErrors !== null){
if(_errs48){
vErrors.length = _errs48;
}
else {
vErrors = null;
}
}
}
}
}
else {
const err157 = {instancePath:instancePath+"/steps/" + i2+"/board_actions",schemaPath:"#/properties/steps/items/properties/board_actions/type",keyword:"type",params:{type: "array"},message:"must be array"};
if(vErrors === null){
vErrors = [err157];
}
else {
vErrors.push(err157);
}
errors++;
}
}
if(data18.gesture !== undefined){
let data64 = data18.gesture;
if(data64 && typeof data64 == "object" && !Array.isArray(data64)){
if(data64.kind === undefined){
const err158 = {instancePath:instancePath+"/steps/" + i2+"/gesture",schemaPath:"#/properties/steps/items/properties/gesture/required",keyword:"required",params:{missingProperty: "kind"},message:"must have required property '"+"kind"+"'"};
if(vErrors === null){
vErrors = [err158];
}
else {
vErrors.push(err158);
}
errors++;
}
if(data64.target_element_id === undefined){
const err159 = {instancePath:instancePath+"/steps/" + i2+"/gesture",schemaPath:"#/properties/steps/items/properties/gesture/required",keyword:"required",params:{missingProperty: "target_element_id"},message:"must have required property '"+"target_element_id"+"'"};
if(vErrors === null){
vErrors = [err159];
}
else {
vErrors.push(err159);
}
errors++;
}
for(const key11 in data64){
if(!((key11 === "kind") || (key11 === "target_element_id"))){
const err160 = {instancePath:instancePath+"/steps/" + i2+"/gesture",schemaPath:"#/properties/steps/items/properties/gesture/additionalProperties",keyword:"additionalProperties",params:{additionalProperty: key11},message:"must NOT have additional properties"};
if(vErrors === null){
vErrors = [err160];
}
else {
vErrors.push(err160);
}
errors++;
}
}
if(data64.kind !== undefined){
let data65 = data64.kind;
if(!(((((data65 === "idle") || (data65 === "look_board")) || (data65 === "point")) || (data65 === "write")) || (data65 === "explain"))){
const err161 = {instancePath:instancePath+"/steps/" + i2+"/gesture/kind",schemaPath:"#/properties/steps/items/properties/gesture/properties/kind/enum",keyword:"enum",params:{allowedValues: schema31.properties.steps.items.properties.gesture.properties.kind.enum},message:"must be equal to one of the allowed values"};
if(vErrors === null){
vErrors = [err161];
}
else {
vErrors.push(err161);
}
errors++;
}
}
if(data64.target_element_id !== undefined){
let data66 = data64.target_element_id;
if((typeof data66 !== "string") && (data66 !== null)){
const err162 = {instancePath:instancePath+"/steps/" + i2+"/gesture/target_element_id",schemaPath:"#/properties/steps/items/properties/gesture/properties/target_element_id/type",keyword:"type",params:{type: schema31.properties.steps.items.properties.gesture.properties.target_element_id.type},message:"must be string,null"};
if(vErrors === null){
vErrors = [err162];
}
else {
vErrors.push(err162);
}
errors++;
}
}
}
else {
const err163 = {instancePath:instancePath+"/steps/" + i2+"/gesture",schemaPath:"#/properties/steps/items/properties/gesture/type",keyword:"type",params:{type: "object"},message:"must be object"};
if(vErrors === null){
vErrors = [err163];
}
else {
vErrors.push(err163);
}
errors++;
}
}
}
else {
const err164 = {instancePath:instancePath+"/steps/" + i2,schemaPath:"#/properties/steps/items/type",keyword:"type",params:{type: "object"},message:"must be object"};
if(vErrors === null){
vErrors = [err164];
}
else {
vErrors.push(err164);
}
errors++;
}
}
}
else {
const err165 = {instancePath:instancePath+"/steps",schemaPath:"#/properties/steps/type",keyword:"type",params:{type: "array"},message:"must be array"};
if(vErrors === null){
vErrors = [err165];
}
else {
vErrors.push(err165);
}
errors++;
}
}
if(data.final_summary !== undefined){
let data67 = data.final_summary;
if(typeof data67 === "string"){
if(func2(data67) < 1){
const err166 = {instancePath:instancePath+"/final_summary",schemaPath:"#/properties/final_summary/minLength",keyword:"minLength",params:{limit: 1},message:"must NOT have fewer than 1 characters"};
if(vErrors === null){
vErrors = [err166];
}
else {
vErrors.push(err166);
}
errors++;
}
}
else {
const err167 = {instancePath:instancePath+"/final_summary",schemaPath:"#/properties/final_summary/type",keyword:"type",params:{type: "string"},message:"must be string"};
if(vErrors === null){
vErrors = [err167];
}
else {
vErrors.push(err167);
}
errors++;
}
}
}
else {
const err168 = {instancePath,schemaPath:"#/type",keyword:"type",params:{type: "object"},message:"must be object"};
if(vErrors === null){
vErrors = [err168];
}
else {
vErrors.push(err168);
}
errors++;
}
validate20.errors = vErrors;
return errors === 0;
}
validate20.evaluated = {"props":true,"dynamicProps":false,"dynamicItems":false};
