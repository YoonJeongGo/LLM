import validate from "./validate-lesson.js";
export type Slot = "main" | "left" | "right" | "bottom" | "overlay";
export type BoardElement = {
  type: "text" | "equation" | "table" | "code";
  element_id: string;
  slot: Slot;
  text?: string;
  latex?: string;
  columns?: string[];
  rows?: (string | number | boolean | null)[][];
  caption?: string;
  language?: string;
  code?: string;
};
export type Highlight = {
  type: "highlight";
  target_element_id: string;
  row_indices?: number[];
  column_indices?: number[];
  style: "outline" | "underline" | "background";
};
export type Arrow = {
  type: "arrow";
  element_id: string;
  from_element_id: string;
  to_element_id: string;
};
export type Action =
  BoardElement | Highlight | Arrow | { type: "clear"; target: string };
export type LessonStep = {
  id: string;
  title: string;
  speech: string;
  board_actions: Action[];
  gesture: {
    kind: "idle" | "look_board" | "point" | "write" | "explain";
    target_element_id: string | null;
  };
};
export type Lesson = {
  schema_version: "1.0";
  lesson_id: string;
  title: string;
  goal: string;
  question_text: string;
  problem_source: string;
  provenance: "demo_fixture" | "model_generated" | "human_authored";
  source_refs: { document_id: string; chunk_id: string; label: string }[];
  verification: { status: string; scope: string; limitations: string[] };
  steps: LessonStep[];
  final_summary: string;
};
export type Scene = {
  elements: BoardElement[];
  highlights: Highlight[];
  arrows: Arrow[];
};
export function parseLesson(value: unknown): Lesson {
  if (!validate(value))
    throw new Error(
      `강의 계획 형식 오류: ${validate.errors
        ?.map((e) => `${e.instancePath} ${e.message}`)
        .slice(0, 3)
        .join(", ")}`,
    );
  return value as Lesson;
}
export const emptyScene = (): Scene => ({
  elements: [],
  highlights: [],
  arrows: [],
});
export function applyAction(scene: Scene, action: Action): Scene {
  if (action.type === "clear")
    return action.target === "all"
      ? emptyScene()
      : {
          elements: scene.elements.filter(
            (e) => e.element_id !== action.target,
          ),
          highlights: scene.highlights.filter(
            (e) => e.target_element_id !== action.target,
          ),
          arrows: scene.arrows.filter(
            (e) =>
              e.from_element_id !== action.target &&
              e.to_element_id !== action.target,
          ),
        };
  if (action.type === "highlight")
    return {
      ...scene,
      highlights: [
        ...scene.highlights.filter(
          (e) => e.target_element_id !== action.target_element_id,
        ),
        action,
      ],
    };
  if (action.type === "arrow")
    return {
      ...scene,
      arrows: [
        ...scene.arrows.filter((e) => e.element_id !== action.element_id),
        action,
      ],
    };
  return {
    ...scene,
    elements: [
      ...scene.elements.filter((e) => e.element_id !== action.element_id),
      action,
    ],
  };
}
export function replayScene(plan: Lesson, step: number, progress = 1): Scene {
  let scene = emptyScene();
  for (let i = 0; i <= Math.min(step, plan.steps.length - 1); i++) {
    const actions = plan.steps[i].board_actions;
    const count =
      i === step
        ? Math.ceil(actions.length * Math.max(0, Math.min(progress, 1)))
        : actions.length;
    scene = actions.slice(0, count).reduce(applyAction, scene);
  }
  return scene;
}
export type Playback = {
  step: number;
  playing: boolean;
  epoch: number;
  progress: number;
  interrupted: boolean;
};
export type PlaybackEvent =
  | {
      type: "next" | "previous" | "play" | "pause" | "interrupt" | "return";
      total?: number;
    }
  | { type: "seek"; step: number }
  | { type: "restore"; step: number; progress: number }
  | { type: "tick"; epoch: number; progress: number };
export const initialPlayback: Playback = {
  step: 0,
  playing: false,
  epoch: 0,
  progress: 1,
  interrupted: false,
};
export function playbackReducer(
  state: Playback,
  event: PlaybackEvent,
): Playback {
  switch (event.type) {
    case "interrupt":
      return {
        ...state,
        playing: false,
        interrupted: true,
        epoch: state.epoch + 1,
      };
    case "return":
      return {
        ...state,
        playing: false,
        interrupted: false,
        epoch: state.epoch + 1,
      };
    case "pause":
      return { ...state, playing: false };
    case "play":
      return { ...state, playing: true };
    case "next":
      return {
        ...state,
        step: Math.min(state.step + 1, (event.total ?? state.step + 2) - 1),
        progress: 1,
        playing: false,
        epoch: state.epoch + 1,
      };
    case "previous":
      return {
        ...state,
        step: Math.max(0, state.step - 1),
        progress: 1,
        playing: false,
        epoch: state.epoch + 1,
      };
    case "seek":
      return {
        ...state,
        step: event.step,
        progress: 1,
        playing: false,
        epoch: state.epoch + 1,
      };
    case "restore":
      return {
        ...state,
        step: event.step,
        progress: event.progress,
        playing: false,
        epoch: state.epoch + 1,
      };
    case "tick":
      return event.epoch === state.epoch && state.playing
        ? { ...state, progress: Math.min(1, Math.max(0, event.progress)) }
        : state;
  }
}
export function shouldSubmit(
  event: {
    key: string;
    shiftKey: boolean;
    isComposing?: boolean;
    keyCode?: number;
  },
  composing: boolean,
) {
  return (
    event.key === "Enter" &&
    !event.shiftKey &&
    !event.isComposing &&
    !composing &&
    event.keyCode !== 229
  );
}
