"""Bounded subprocess inference: the API never imports torch or holds weights."""
from __future__ import annotations

import importlib.util
import json
import os
import queue
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path

from edu_tutor.paths import initialize, project_root


class ModelUnavailable(RuntimeError):
    pass


class GenerationIncomplete(RuntimeError):
    pass


def model_status(root=None):
    root = project_root(root)
    folder = root / ".local/models/text"
    manifest = folder / "model-manifest.json"
    result = {"model_id": "Qwen/Qwen3-1.7B", "installed": False, "ready": False,
              "revision": None, "reason": "모델 미설치", "validation": "not_run", "modules": []}
    if manifest.exists():
        meta = json.loads(manifest.read_text(encoding="utf-8"))
        installed = meta.get("download_complete", False) and all((folder / f["path"]).is_file() for f in meta["files"])
        result.update(installed=installed, revision=meta["revision"], license=meta["license"])
        missing = [name for name in ("torch", "transformers", "bitsandbytes", "accelerate") if importlib.util.find_spec(name) is None]
        result.update(ready=installed and not missing, reason="로컬 GPU 실행 가능 여부는 실제 검증 결과를 확인하세요." if not missing else "런타임 미설치: " + ", ".join(missing))
    structure = folder / "runtime-structure.json"
    if structure.exists():
        result.update(json.loads(structure.read_text(encoding="utf-8")))
    from .registry import selection
    result["active_adapter"] = selection(root)["active_adapter"]
    return result


def _read_pipe(stream, events):
    try:
        for line in stream:
            events.put(line)
    finally:
        events.put(None)


def run_worker(payload, *, root=None, cancel_event=None, timeout=300):
    root = initialize(root)
    ident = uuid.uuid4().hex
    folder = root / "runs" / ("runtime-" + ident)
    folder.mkdir()
    cancel_path = folder / "cancel.requested"
    payload = {**payload, "root": str(root), "cancel_path": str(cancel_path), "run_dir": str(folder)}
    payload.setdefault("job_id", ident)
    env = os.environ.copy()
    env.update(PYTHONUTF8="0", PYTHONIOENCODING="utf-8", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", HF_HUB_DISABLE_TELEMETRY="1", DO_NOT_TRACK="1", TOKENIZERS_PARALLELISM="false")
    # Also works from a source checkout without an editable installation.
    env["PYTHONPATH"] = str(root / "src") + os.pathsep + env.get("PYTHONPATH", "")
    started = time.monotonic()
    cancel_at = None
    events = queue.Queue()
    with (folder / "stderr.log").open("w", encoding="utf-8") as errors:
        process = subprocess.Popen([sys.executable, "-m", "edu_tutor.models.worker"], cwd=root,
                                   stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=errors,
                                   text=True, encoding="utf-8", env=env,
                                   creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        process.stdin.write(json.dumps(payload, ensure_ascii=False) + "\n")
        process.stdin.close()
        reader = threading.Thread(target=_read_pipe, args=(process.stdout, events), daemon=True)
        reader.start()
        success = False
        try:
            while True:
                if cancel_event is not None and cancel_event.is_set():
                    if cancel_at is None:
                        cancel_path.touch()
                        cancel_at = time.monotonic()
                    if time.monotonic() - cancel_at > 5:
                        return
                if time.monotonic() - started > timeout:
                    raise TimeoutError(f"모델 작업이 {timeout}초 제한에 도달했습니다. 결과는 미완료입니다.")
                try:
                    line = events.get(timeout=0.1)
                except queue.Empty:
                    continue
                if line is None:
                    break
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if event.get("type") == "error":
                    raise ModelUnavailable(event["message"])
                if event.get("type") == "done":
                    success = True
                if cancel_at is None:
                    yield event
            process.wait(timeout=5)
            if cancel_at is None and (process.returncode != 0 or not success):
                raise ModelUnavailable(f"Model worker unavailable (exit={process.returncode}); 로그: {folder.name}/stderr.log")
        finally:
            # Only terminate the child created by this exact Popen; never a guessed PID.
            if process.poll() is None:
                cancel_path.touch()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.terminate()
                    process.wait(timeout=5)
            process.stdout.close()
            reader.join(timeout=2)


def generate(messages, cancel_event=None, adapter=None, root=None, job_id=None, max_new_tokens=512, metadata_out=None):
    if not messages or len(messages) > 30:
        raise ValueError("대화는 1~30개 메시지여야 합니다.")
    if any(m.get("role") not in {"system", "user", "assistant"} or not isinstance(m.get("content"), str) for m in messages):
        raise ValueError("잘못된 대화 형식입니다.")
    if sum(len(m["content"]) for m in messages) > 24000:
        raise ValueError("입력이 너무 깁니다. 대화나 자료를 줄여 주세요.")
    state = model_status(root)
    if not state["ready"]:
        raise ModelUnavailable("Model unavailable: " + state["reason"])
    from .registry import adapters, resolve_adapter
    adapter_path = resolve_adapter(adapter, root)
    # Capture the exact resolved selection once. Later UI selection changes must
    # never relabel a historical answer or replace actual worker provenance.
    adapter_id = "base" if adapter_path is None else next(
        (item["id"] for item in adapters(root)
         if Path(item["path"]).resolve() == Path(adapter_path).resolve()), None)
    payload = {"kind": "text", "messages": messages, "adapter": adapter_path,
               "max_new_tokens": max(16, min(int(max_new_tokens), 768))}
    if job_id:
        payload["job_id"] = job_id
    for event in run_worker(payload, root=root, cancel_event=cancel_event):
        if event.get("type") == "delta":
            yield event["text"]
        elif event.get("type") == "metadata":
            if metadata_out is not None:
                metadata_out.update({key: event.get(key) for key in
                    ("model_id", "revision", "finish_reason", "input_tokens", "output_tokens", "timestamp")})
                metadata_out.update(source="worker_metadata",
                    adapter_id=adapter_id if event.get("adapter") == adapter_path else None)
            if event.get("finish_reason") != "eos":
                raise GenerationIncomplete("답변이 토큰/시간 제한 또는 취소로 끝났습니다. 부분 출력은 완성된 답변이 아닙니다.")
