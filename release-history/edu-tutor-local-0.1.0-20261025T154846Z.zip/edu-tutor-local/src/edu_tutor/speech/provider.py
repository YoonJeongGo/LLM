from __future__ import annotations
import hashlib
import importlib.util
import json
import re
import time
from pathlib import Path
from edu_tutor.paths import initialize, project_root

VOICES = {"Sohee", "Vivian", "Serena", "Ryan", "Aiden", "Ono_Anna", "Uncle_Fu", "Dylan", "Eric"}


def pronunciation(text):
    text = re.sub(r"COUNT\s*\(\s*\*\s*\)", "카운트 별표", text, flags=re.I)
    return re.sub(r"\bNULL\b", "널", text, flags=re.I)


def status(root=None):
    folder = project_root(root) / ".local/models/tts"
    installed = (folder / "model-manifest.json").exists()
    ready = installed and importlib.util.find_spec("qwen_tts") is not None
    return {"installed": installed, "ready": ready, "provider": "qwen3_tts_local", "voice": "Sohee",
            "reason": None if ready else "음성 사용 불가: 로컬 TTS 모델 또는 패키지가 없습니다.", "listening_review": "not_run"}


def prepare(text, root=None, voice="Sohee", cancel_event=None, job_id=None):
    from edu_tutor.models.runtime import run_worker, ModelUnavailable
    root = initialize(root)
    if not isinstance(text, str) or not text.strip() or len(text) > 1000:
        raise ValueError("음성은 비어 있지 않은 1,000자 이하 문장만 지원합니다.")
    if voice not in VOICES:
        raise ValueError("지원하지 않는 제공 화자입니다.")
    if not status(root)["ready"]:
        raise ModelUnavailable("TTS unavailable: " + status(root)["reason"])
    manifest = json.loads((root / ".local/models/tts/model-manifest.json").read_text(encoding="utf-8"))
    spec = {"text": pronunciation(text), "display_text": text, "voice": voice,
            "revision": manifest["revision"], "language": "Korean", "max_new_tokens": 2048, "dictionary_version": 1}
    key = hashlib.sha256(json.dumps(spec, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
    meta_file = root / ".local/audio" / (key + ".json")
    if meta_file.exists() and (meta_file.with_suffix(".wav")).exists():
        cached = json.loads(meta_file.read_text(encoding="utf-8"))
        with meta_file.with_suffix(".wav").open("rb") as stream:
            checksum = hashlib.file_digest(stream, "sha256").hexdigest()
        if checksum == cached.get("checksum"):
            return cached
    payload = {"kind": "speech", "spec": spec, "audio_id": key}
    if job_id:
        payload["job_id"] = job_id
    for event in run_worker(payload, root=root, cancel_event=cancel_event):
        if event.get("type") == "audio":
            return {key: value for key, value in event.items() if key != "type"}
    raise RuntimeError("음성 생성이 중단되었습니다.")


def speech_job(payload, emit):
    import numpy as np
    import torch
    import soundfile as sf
    from qwen_tts import Qwen3TTSModel
    root = Path(payload["root"])
    spec = payload["spec"]
    started = time.monotonic()
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA unavailable")
    model = Qwen3TTSModel.from_pretrained(str(root / ".local/models/tts"),
        device_map="cuda:0", dtype=torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16,
        attn_implementation="sdpa", local_files_only=True)
    wavs, sample_rate = model.generate_custom_voice(text=spec["text"], language="Korean",
        speaker=spec["voice"], max_new_tokens=spec["max_new_tokens"], do_sample=False)
    samples = np.asarray(wavs[0], dtype=np.float32)
    if samples.size < sample_rate / 10 or not np.isfinite(samples).all() or float(np.max(np.abs(samples))) < 0.00001:
        raise RuntimeError("Invalid or silent waveform")
    if Path(payload["cancel_path"]).exists():
        raise RuntimeError("Speech cancelled")
    audio_id = payload["audio_id"]
    if not re.fullmatch(r"[a-f0-9]{64}", audio_id):
        raise ValueError("Invalid audio id")
    folder = root / ".local/audio"
    folder.mkdir(parents=True, exist_ok=True)
    file = folder / (audio_id + ".wav")
    sf.write(file, samples, sample_rate, subtype="PCM_16")
    with file.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    result = {"audio_id": audio_id, "url": f"/api/audio/{audio_id}", "duration": len(samples) / sample_rate,
              "sample_rate": sample_rate, "checksum": digest, "provider": "qwen3_tts_local", "voice": spec["voice"],
              "revision": spec["revision"], "text_hash": hashlib.sha256(spec["text"].encode()).hexdigest(),
              "generation_settings": {"language":spec["language"],"do_sample":False,"max_new_tokens":spec["max_new_tokens"],"dictionary_version":spec["dictionary_version"]},
              "elapsed_seconds": time.monotonic() - started, "peak_vram_bytes": torch.cuda.max_memory_allocated(),
              "rms": float(np.sqrt(np.mean(samples**2))), "tier": "T2", "listening_review": "not_run"}
    file.with_suffix(".json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    (Path(payload["run_dir"]) / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    emit("audio", **result)
