from __future__ import annotations

import os
import threading
from concurrent.futures import ThreadPoolExecutor

from edu_tutor.storage.db import Store, new_id, utcnow
from edu_tutor.jobs.lease import GPULease

TERMINAL = {"succeeded", "failed", "cancelled", "interrupted", "blocked"}


class JobManager:
    def __init__(self, store: Store):
        self.store = store
        self.lock = threading.RLock()
        self.cancels = {}
        self.closed = False
        self.instance = new_id()
        # Acquire before recovery: a second server must not interrupt live jobs.
        self.instance_lease = GPULease(store.local, self.instance, device="api", lock_name="api").__enter__()
        self.pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix="tutor-job")
        try:
            self.recover()
        except BaseException:
            self.instance_lease.__exit__(None, None, None)
            raise

    def recover(self):
        # Called only when the application starts. No processes are killed.
        for job in self.store.list("jobs"):
            if job["state"] not in TERMINAL:
                job.update(state="interrupted", error="서버 재시작으로 작업이 중단되었습니다.", updated_at=utcnow())
                self.store.put("jobs", job)

    def update(self, ident, **fields):
        with self.lock:
            job = self.store.get("jobs", ident)
            if self.closed:
                return job
            job.update(fields, updated_at=utcnow())
            self.store.put("jobs", job)
            return job

    def submit(self, kind, target, *, request_id=None, session_id=None, generation_epoch=0):
        with self.lock:
            if self.closed:
                raise RuntimeError("API job manager is shutting down")
            if request_id:
                for job in self.store.list("jobs"):
                    if job.get("request_id") == request_id and job.get("session_id") == session_id and job.get("kind") == kind:
                        return job
            ident = new_id()
            job = {"id": ident, "kind": kind, "state": "queued", "cancel_requested": False,
                   "progress": 0, "result": None, "error": None, "request_id": request_id,
                   "session_id": session_id, "generation_epoch": generation_epoch,
                   "created_at": utcnow(), "updated_at": utcnow(), "owner_pid": os.getpid(),
                   "owner_instance": self.instance}
            self.store.put("jobs", job)
            cancel = threading.Event()
            self.cancels[ident] = cancel

            def run():
                try:
                    if cancel.is_set():
                        self.update(ident, state="cancelled")
                        return
                    self.update(ident, state="loading")
                    result = target(ident, cancel)
                    self.update(ident, state="cancelled" if cancel.is_set() else "succeeded", result=result,
                                progress=1 if not cancel.is_set() else 0)
                except Exception as exc:
                    blocked = isinstance(exc, (FileNotFoundError, ImportError)) or type(exc).__name__ in {"ModelUnavailable", "LeaseBusy", "ResourceBudgetExceeded"} or "unavailable" in str(exc).lower()
                    self.update(ident, state="cancelled" if cancel.is_set() else ("blocked" if blocked else "failed"),
                                error=str(exc)[:700])
                finally:
                    with self.lock:
                        self.cancels.pop(ident, None)

            self.pool.submit(run)
            return job

    def cancel(self, ident):
        with self.lock:
            job = self.store.get("jobs", ident)
            if not job:
                raise KeyError(ident)
            if job["state"] not in TERMINAL:
                if ident in self.cancels:
                    self.cancels[ident].set()
                job = self.update(ident, cancel_requested=True)
            return job

    def close(self):
        with self.lock:
            if self.closed:
                return
            self.closed = True
            for ident, cancel in list(self.cancels.items()):
                cancel.set()
                job = self.store.get("jobs", ident)
                if job and job["state"] not in TERMINAL:
                    job.update(state="interrupted", cancel_requested=True, updated_at=utcnow(),
                               error="서버 종료로 작업이 중단되었습니다.")
                    self.store.put("jobs", job)
        self.pool.shutdown(wait=False, cancel_futures=True)
        self.instance_lease.__exit__(None, None, None)
