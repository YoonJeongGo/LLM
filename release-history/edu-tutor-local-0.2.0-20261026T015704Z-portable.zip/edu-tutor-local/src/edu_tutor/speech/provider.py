from __future__ import annotations
import hashlib
import importlib.util
import json
import re
import time
from pathlib import Path
from edu_tutor.paths import initialize, project_root

VOICES = {"Sohee", "Vivian", "Serena", "Ryan", "Aiden", "Ono_Anna", "Uncle_Fu", "Dylan", "Eric"}


def pronunciation(text):
    text = re.sub(r"COUNT\s*\(\s*\*\s*\)", "카운트 별표", text, flags=re.I)
    return re.sub(r"\bNULL\b", "널", text, flags=re.I)


def status(root=None):
    folder = project_root(root) / ".local/models/tts"
    installed = (folder / "model-manifest.json").exists()
    ready = installed and importlib.util.find_spec("qwen_tts") is not None
    return {"installed": installed, "ready": ready, "provider": "qwen3_tts_local", "voice": "Sohee",
            "reason": None if ready else "음성 사용 불가: 로컬 TTS 모델 또는 패키지가 없습니다.", "listening_review": "not_run"}


def prepare(text, root=None, voice="Sohee", cancel_event=None, job_id=None):
    return prepare_batch([{"id": "answer", "text": text}], root=root, voice=voice,
                         cancel_event=cancel_event, job_id=job_id)[0]["audio"]


def _spec(text, root, voice):
    if not isinstance(text, str) or not text.strip() or len(text) > 1000:
        raise ValueError("음성은 비어 있지 않은 1,000자 이하 문장만 지원합니다.")
    manifest = json.loads((root / ".local/models/tts/model-manifest.json").read_text(encoding="utf-8"))
    spec = {"text": pronunciation(text), "display_text": text, "voice": voice,
            "revision": manifest["revision"], "language": "Korean", "max_new_tokens": 768,
            "dictionary_version": 1, "completion_check_version": 2}
    key = hashlib.sha256(json.dumps(spec, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
    return key, spec


def prepare_batch(items, root=None, voice="Sohee", cancel_event=None, job_id=None, on_audio=None):
    """Prepare 1..4 short units with a single sequential TTS model load.

    on_audio(id, audio) publishes complete clips as they arrive; subsequent
    units can be generated while the first complete unit is already playable.
    """
    from edu_tutor.models.runtime import run_worker, ModelUnavailable
    root = initialize(root)
    if not isinstance(items, list) or not 1 <= len(items) <= 4 or len({i["id"] for i in items}) != len(items):
        raise ValueError("한 번에 서로 다른 1~4개 음성 단위를 준비할 수 있습니다.")
    if voice not in VOICES:
        raise ValueError("지원하지 않는 제공 화자입니다.")
    if not status(root)["ready"]:
        raise ModelUnavailable("TTS unavailable: " + status(root)["reason"])
    specs = {i["id"]: _spec(i["text"], root, voice) for i in items}
    by_key = {}
    missing = {}
    for key, spec in specs.values():
        meta_file = root / ".local/audio" / (key + ".json")
        if meta_file.exists() and meta_file.with_suffix(".wav").exists():
            cached = json.loads(meta_file.read_text(encoding="utf-8"))
            with meta_file.with_suffix(".wav").open("rb") as stream:
                checksum = hashlib.file_digest(stream, "sha256").hexdigest()
            if checksum == cached.get("checksum"):
                by_key[key] = {**cached, "cache_hit": True}
                continue
        missing[key] = {"spec": spec, "audio_id": key}
    def publish(key, audio):
        if on_audio:
            for ident, (audio_key, _) in specs.items():
                if key == audio_key:
                    on_audio(ident, audio)
    for key, audio in by_key.items():
        publish(key, audio)
    payload = {"kind": "speech_batch", "items": list(missing.values())}
    if job_id:
        payload["job_id"] = job_id
    if missing:
        for event in run_worker(payload, root=root, cancel_event=cancel_event):
            if event.get("type") == "audio":
                audio = {k: v for k, v in event.items() if k != "type"}
                by_key[audio["audio_id"]] = {**audio, "cache_hit": False}
                publish(audio["audio_id"], by_key[audio["audio_id"]])
    if any(key not in by_key for key, _ in specs.values()):
        raise RuntimeError("음성 생성이 중단되었습니다.")
    return [{"id": ident, "audio": by_key[key]} for ident, (key, _) in specs.items()]


def speech_batch_job(payload, emit):
    import torch
    from qwen_tts import Qwen3TTSModel
    if not 1 <= len(payload["items"]) <= 4:
        raise ValueError("Speech batch must contain 1..4 clips")
    started = time.monotonic()
    root = Path(payload["root"])
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA unavailable")
    model = Qwen3TTSModel.from_pretrained(str(root / ".local/models/tts"),
        device_map="cuda:0", dtype=torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16,
        attn_implementation="sdpa", local_files_only=True)
    load_seconds = time.monotonic() - started
    for index, item in enumerate(payload["items"]):
        if Path(payload["cancel_path"]).exists():
            raise RuntimeError("Speech cancelled")
        speech_job({**payload, **item}, emit, model=model,
                   model_load_seconds=load_seconds if index == 0 else 0, batch_index=index)


def _checked_custom_voice(model, spec, report_path=None):
    """Observe the installed qwen-tts 0.1.1 codec stop marker without patching it.

    The public helper returns WAVs even when its code budget is exhausted.
    Observe the generated token sequence, not lagging hidden-state audio codes
    (the last EOS token need not have a following hidden state).
    """
    talker = model.model.talker
    original = talker.generate
    completion = {"finish_reason": "not_observed", "output_code_frames": 0}
    def observe(*args, **kwargs):
        output = original(*args, **kwargs)
        first_codes = output.sequences[0].tolist()
        eos = model.model.config.talker_config.codec_eos_token_id
        completion.update(finish_reason="eos" if eos in first_codes else "length_or_timeout",
                          output_code_frames=len(first_codes), completion_check_version=2,
                          observed_eos_token_id=eos, last_generated_tokens=first_codes[-5:])
        if report_path:
            Path(report_path).write_text(json.dumps(completion, indent=2), encoding="utf-8")
        return output
    talker.generate = observe
    try:
        wavs, sample_rate = model.generate_custom_voice(text=spec["text"], language="Korean",
            speaker=spec["voice"], max_new_tokens=spec["max_new_tokens"], do_sample=False)
    finally:
        talker.generate = original
    if completion["finish_reason"] != "eos":
        raise RuntimeError("음성 종료 토큰을 확인하지 못했습니다. 잘린 음성은 재생하지 않습니다. 대사를 더 짧게 나눠 주세요.")
    return wavs, sample_rate, completion


def speech_job(payload, emit, model=None, model_load_seconds=0, batch_index=0):
    import numpy as np
    import torch
    import soundfile as sf
    from qwen_tts import Qwen3TTSModel
    root = Path(payload["root"])
    spec = payload["spec"]
    started = time.monotonic()
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA unavailable")
    if model is None:
        model = Qwen3TTSModel.from_pretrained(str(root / ".local/models/tts"),
            device_map="cuda:0", dtype=torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16,
            attn_implementation="sdpa", local_files_only=True)
        model_load_seconds = time.monotonic() - started
    wavs, sample_rate, completion = _checked_custom_voice(model, spec,
        Path(payload["run_dir"]) / ("completion-"+payload["audio_id"]+".json"))
    samples = np.asarray(wavs[0], dtype=np.float32)
    if samples.size < sample_rate / 10 or not np.isfinite(samples).all() or float(np.max(np.abs(samples))) < 0.00001:
        raise RuntimeError("Invalid or silent waveform")
    if len(samples) / sample_rate > 35:
        raise RuntimeError("짧은 강의 단위의 음성이 35초를 초과했습니다. 대사를 나눠 다시 준비하세요. 이 음성은 재생하지 않습니다.")
    if Path(payload["cancel_path"]).exists():
        raise RuntimeError("Speech cancelled")
    audio_id = payload["audio_id"]
    if not re.fullmatch(r"[a-f0-9]{64}", audio_id):
        raise ValueError("Invalid audio id")
    folder = root / ".local/audio"
    folder.mkdir(parents=True, exist_ok=True)
    file = folder / (audio_id + ".wav")
    sf.write(file, samples, sample_rate, subtype="PCM_16")
    with file.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    result = {"audio_id": audio_id, "url": f"/api/audio/{audio_id}", "duration": len(samples) / sample_rate,
              "sample_rate": sample_rate, "checksum": digest, "provider": "qwen3_tts_local", "voice": spec["voice"],
              "revision": spec["revision"], "text_hash": hashlib.sha256(spec["text"].encode()).hexdigest(),
              "generation_settings": {"language":spec["language"],"do_sample":False,"max_new_tokens":spec["max_new_tokens"],"dictionary_version":spec["dictionary_version"],"completion_check_version":spec.get("completion_check_version",2)},
              "completion": completion,
              "elapsed_seconds": time.monotonic() - started, "peak_vram_bytes": torch.cuda.max_memory_allocated(),
              "model_load_seconds": model_load_seconds, "model_load_count": int(batch_index == 0),
              "batch_index": batch_index, "batch_mode": "sequential_shared_model", "cache_hit": False,
              "rms": float(np.sqrt(np.mean(samples**2))), "tier": "T2", "listening_review": "not_run"}
    file.with_suffix(".json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    (Path(payload["run_dir"]) / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    emit("audio", **result)
