"""Tentative structures extracted only from actual OCR characters, never images' oracles."""
from __future__ import annotations
import re


def structure_candidate(candidate):
    value=dict(candidate)
    text=value.get("original_text",value.get("question",""))
    schemas=[]
    for match in re.finditer(r"\b([A-Za-z_]\w*)\s*\(([^)\n]+)\)",text):
        parts=match.group(2).split(",")
        cols=[]
        for part in parts:
            col=re.fullmatch(r"\s*([A-Za-z_]\w*)\s+(INTEGER|REAL|TEXT|NUMERIC)\s*",part,re.I)
            if not col:break
            cols.append({"name":col.group(1),"type":col.group(2).upper()})
        if len(cols)==len(parts):schemas.append((match,cols))
    extracted=[]; used=[]
    if len(schemas)==1:
        match,columns=schemas[0]
        rows=[]
        for line in text[match.end():].splitlines():
            raw=line.strip().strip("|").strip()
            if not raw or re.search(r"\b(?:SELECT|FROM|WHERE|GROUP|HAVING|ORDER)\b",raw,re.I):continue
            if re.fullmatch(r"[|:\s-]+",raw):continue
            raw=raw.strip("()")
            cells=[x.strip() for x in raw.split("|")] if "|" in raw else [x.strip() for x in raw.split(",")] if "," in raw else re.split(r"\s{2,}|\t+",raw)
            if len(cells)!=len(columns):continue
            parsed=[]
            for cell,col in zip(cells,columns):
                if cell.upper()=="NULL":parsed.append(None)
                elif col["type"] in {"INTEGER","REAL","NUMERIC"}:
                    if not re.fullmatch(r"[-+]?\d+(?:\.\d+)?",cell):break
                    parsed.append(float(cell) if "." in cell else int(cell))
                else:parsed.append(cell.strip("'\""))
            if len(parsed)==len(columns):rows.append(parsed);used.append(line)
        if rows:extracted=[{"name":match.group(1),"columns":columns,"rows":rows[:500]}]
    sqls=re.findall(r"\b(?:SELECT|WITH)\s+[\s\S]*?;",text,re.I)
    if len(sqls)==1:value["sql"]=sqls[0]
    if extracted:value["tables"]=extracted
    value["structure_extraction"]={"status":"candidate_requires_confirmation" if extracted else "not_extracted",
        "method":"explicit_schema_and_delimited_OCR_rows_only","source":"actual_original_text",
        "recognized_row_lines":used,"accuracy":"not_established","sql_extracted":len(sqls)==1}
    return value
