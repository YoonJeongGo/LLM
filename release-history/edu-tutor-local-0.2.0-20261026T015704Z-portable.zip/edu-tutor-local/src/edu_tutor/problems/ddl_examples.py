"""Execute a tiny, model-authored DDL/DML illustration in a disposable DB.

Only reconstructed CREATE TABLE, literal INSERT VALUES, ADD COLUMN and DROP
TABLE are executable. This is a new teaching example, never the student's DB
or an inferred replacement for the original problem. Free prose is unreviewed.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import sqlite3
import time
from contextlib import closing

import sqlglot
from sqlglot import exp

LIMITS = {"sql_characters": 8000, "statements": 8, "tables": 3,
          "columns_per_table": 8, "rows_per_table": 20, "string_characters": 128,
          "execution_seconds": 1.0}
TYPES = {"INT": "INTEGER", "INTEGER": "INTEGER", "REAL": "REAL", "FLOAT": "REAL",
         "DOUBLE": "REAL", "TEXT": "TEXT", "NUMERIC": "NUMERIC"}


def _identifier(value):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]{0,63}", value):
        raise ValueError("예시 식별자는 64자 이하 영문·숫자·밑줄만 지원합니다.")
    if value.casefold().startswith("sqlite_"):
        raise ValueError("SQLite 내부 이름은 예시에 사용할 수 없습니다.")
    return value


def _quoted(value):
    return '"' + _identifier(value) + '"'


def _table(node):
    if (not isinstance(node, exp.Table) or not isinstance(node.this, exp.Identifier)
            or any(v for k,v in node.args.items() if k != "this")):
        raise ValueError("연결 DB·스키마·별칭 없는 예시 표 이름만 지원합니다.")
    return _identifier(node.name)


def _column(node):
    if not isinstance(node, exp.ColumnDef) or node.args.get("constraints") or node.args.get("exists"):
        raise ValueError("예시 열은 제약식 없는 단순 이름과 자료형만 지원합니다.")
    if any(v for k,v in node.args.items() if k not in {"this", "kind", "exists"}):
        raise ValueError("지원하지 않는 예시 열 속성입니다.")
    typ = node.args.get("kind")
    if not isinstance(typ, exp.DataType) or typ.expressions:
        raise ValueError("예시 자료형은 INTEGER, REAL, TEXT, NUMERIC만 지원합니다.")
    kind = TYPES.get(typ.sql(dialect="sqlite").upper())
    if kind is None:
        raise ValueError("예시 자료형은 INTEGER, REAL, TEXT, NUMERIC만 지원합니다.")
    return {"name": _identifier(node.name), "type": kind}


def _literal(node):
    if isinstance(node, exp.Null):
        return None
    negative = isinstance(node, exp.Neg)
    if negative:
        node = node.this
    if not isinstance(node, exp.Literal) or negative and node.is_string:
        raise ValueError("INSERT 예시는 함수·식·서브쿼리 없이 문자·숫자·NULL 값만 지원합니다.")
    if node.is_string:
        if len(node.this) > LIMITS["string_characters"]:
            raise ValueError("예시 문자열 길이 제한을 초과했습니다.")
        return node.this
    try:
        value = int(node.this) if re.fullmatch(r"\d+", node.this) else float(node.this)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("유한 숫자만 사용할 수 있습니다.") from exc
    if negative:
        value = -value
    if isinstance(value, float) and not math.isfinite(value) or isinstance(value, int) and not -(2**63) <= value < 2**63:
        raise ValueError("SQLite의 유한 숫자 범위를 초과했습니다.")
    return value


def _sql_value(value):
    if value is None:
        return "NULL"
    if isinstance(value, str):
        return "'" + value.replace("'", "''") + "'"
    return str(value)


def _command(node):
    """Validate all AST nodes first, then create a tiny independent command."""
    if isinstance(node, exp.Create):
        if node.args.get("kind") != "TABLE" or not isinstance(node.this, exp.Schema):
            raise ValueError("CREATE TABLE의 명시적 열 선언만 지원합니다.")
        if any(v for k,v in node.args.items() if k not in {"this", "kind", "exists"}):
            raise ValueError("CREATE AS/임시·가상 표/교체 등의 확장 문법은 지원하지 않습니다.")
        name = _table(node.this.this)
        columns = [_column(c) for c in node.this.expressions]
        if not 1 <= len(columns) <= LIMITS["columns_per_table"]:
            raise ValueError("예시 표 열 개수 제한을 초과했습니다.")
        return {"operation": "create_table", "table": name, "columns": columns,
                "if_not_exists": bool(node.args.get("exists"))}
    if isinstance(node, exp.Insert):
        allowed = {"this", "expression", "is_function"}
        if any(v for k,v in node.args.items() if k not in allowed) or node.args.get("is_function"):
            raise ValueError("INSERT의 기본 VALUES 형식만 지원합니다.")
        target = node.this
        columns = None
        if isinstance(target, exp.Schema):
            columns = [_identifier(c.name) if isinstance(c, exp.Identifier) else _identifier(None) for c in target.expressions]
            target = target.this
        name = _table(target)
        values = node.args.get("expression")
        if not isinstance(values, exp.Values) or not 1 <= len(values.expressions) <= LIMITS["rows_per_table"]:
            raise ValueError("INSERT VALUES의 작은 행 목록만 지원합니다.")
        rows = []
        for row in values.expressions:
            if not isinstance(row, exp.Tuple) or not 1 <= len(row.expressions) <= LIMITS["columns_per_table"]:
                raise ValueError("INSERT 행 너비 제한을 초과했습니다.")
            rows.append([_literal(value) for value in row.expressions])
        return {"operation": "insert_rows", "table": name, "columns": columns, "rows": rows}
    if isinstance(node, exp.Alter):
        if node.args.get("kind") != "TABLE" or any(v for k,v in node.args.items() if k not in {"this", "kind", "actions"}):
            raise ValueError("ALTER TABLE ADD COLUMN만 지원합니다.")
        actions = node.args.get("actions", [])
        if len(actions) != 1:
            raise ValueError("한 문장에서는 열 하나만 추가할 수 있습니다.")
        return {"operation": "add_column", "table": _table(node.this), "column": _column(actions[0])}
    if isinstance(node, exp.Drop):
        if node.args.get("kind") != "TABLE" or any(v for k,v in node.args.items() if k not in {"this", "kind", "exists"}):
            raise ValueError("단순 DROP TABLE만 지원합니다.")
        return {"operation": "drop_table", "table": _table(node.this), "if_exists": bool(node.args.get("exists"))}
    raise ValueError("설명용 예시는 CREATE TABLE, INSERT VALUES, ALTER ADD COLUMN, DROP TABLE만 지원합니다.")


def _extract(raw):
    if not isinstance(raw, str) or len(raw) > 30000:
        raise ValueError("예시 응답 길이 제한을 초과했습니다.")
    blocks = []
    for match in re.finditer(r"```([^\r\n`]*)\r?\n(.*?)(```|\Z)",raw,re.S):
        language,body,closing=match.groups()
        language=language.strip().casefold()
        candidate=language=="sql" or not language and re.match(r"^\s*(CREATE|INSERT|ALTER|DROP)\b",body,re.I)
        if candidate:
            if not closing:
                raise ValueError("SQL 예시 코드 블록이 닫히지 않았습니다.")
            blocks.append(body)
    if not blocks:
        try:
            value = json.loads(raw)
        except (TypeError, ValueError):
            value = None
        if isinstance(value, dict) and isinstance(value.get("sql"), str):
            blocks = [value["sql"]]
        elif re.match(r"^\s*(CREATE|INSERT|ALTER|DROP)\b", raw, re.I):
            blocks = [raw]
    if sum(map(len, blocks)) > LIMITS["sql_characters"]:
        raise ValueError("예시 SQL 길이 제한을 초과했습니다.")
    return blocks


def _snapshot(db, known, namespace):
    tables = []
    for name in known:
        # Identifiers come only from the validated command model. These internal
        # introspection SELECTs never expose sqlite_schema to supplied SQL.
        columns = db.execute('SELECT name, type FROM pragma_table_info(?)', (name,)).fetchall()
        rows = [list(row) for row in db.execute('SELECT * FROM '+_quoted(name))]
        ident = namespace + '-table-' + name.casefold()
        row_ids = [ident+'-r'+str(i) for i in range(len(rows))]
        column_ids = [ident+'-c-'+c[0].casefold() for c in columns]
        tables.append({"id":ident,"name":name,"columns":[c[0] for c in columns],
                       "column_types":[c[1] for c in columns],"rows":rows,
                       "row_ids":row_ids,"column_ids":column_ids,
                       "cell_ids":[[r+'-c-'+c[0].casefold() for c in columns] for r in row_ids]})
    return tables


def _execute(db, command, known):
    op, name = command["operation"], command["table"]
    qname = _quoted(name)
    if op == "create_table":
        if name.casefold() not in {n.casefold() for n in known} and len(known) >= LIMITS["tables"]:
            raise ValueError("예시 표 개수 제한을 초과했습니다.")
        sql = 'CREATE TABLE '+('IF NOT EXISTS ' if command['if_not_exists'] else '')+qname+' ('+', '.join(_quoted(c['name'])+' '+c['type'] for c in command['columns'])+')'
        db.execute(sql)
        if name.casefold() not in {n.casefold() for n in known}:known.append(name)
    elif op == "insert_rows":
        width = len(command["rows"][0])
        if any(len(row) != width for row in command["rows"]):
            raise ValueError("INSERT 행 너비가 서로 다릅니다.")
        if command["columns"] and len(command["columns"]) != width:
            raise ValueError("INSERT 대상 열과 값 개수가 다릅니다.")
        existing = db.execute('SELECT COUNT(*) FROM '+qname).fetchone()[0]
        if existing + len(command["rows"]) > LIMITS["rows_per_table"]:
            raise ValueError("예시 행 개수 제한을 초과했습니다.")
        prefix = 'INSERT INTO '+qname+(' ('+', '.join(_quoted(c) for c in command['columns'])+')' if command['columns'] else '')+' VALUES '
        db.executemany(prefix+'('+','.join('?' for _ in range(width))+')',command['rows'])
        sql = prefix+', '.join('('+', '.join(_sql_value(v) for v in row)+')' for row in command['rows'])
    elif op == "add_column":
        count = db.execute('SELECT COUNT(*) FROM pragma_table_info(?)',(name,)).fetchone()[0]
        if count >= LIMITS["columns_per_table"]:
            raise ValueError("예시 열 개수 제한을 초과했습니다.")
        column = command["column"]
        sql = 'ALTER TABLE '+qname+' ADD COLUMN '+_quoted(column['name'])+' '+column['type']
        db.execute(sql)
    else:
        sql = 'DROP TABLE '+('IF EXISTS ' if command['if_exists'] else '')+qname
        db.execute(sql)
        known[:] = [n for n in known if n.casefold() != name.casefold()]
    return sql+';'


def build_ddl_example(raw_response):
    report = {"status":"not_available","source":"model_authored_sql","label":"설명용 새 예시",
              "problem_role":"separate_illustration_not_original_problem","steps":[],"limits":LIMITS.copy(),
              "execution":{"status":"not_run","dialect":"sqlite","database":":memory:"},
              "human_review":"not_reviewed","free_prose_verification":"not_verified"}
    try:
        blocks = _extract(raw_response)
        if not blocks:
            return {**report,"reason":"실제 모델 응답에 실행할 SQL 예시가 없습니다. 예시를 만들어 넣지 않았습니다."}
        report["source_sql_blocks"] = blocks
        nodes = [n for block in blocks for n in sqlglot.parse(block,read='sqlite') if n is not None]
        if not 1 <= len(nodes) <= LIMITS["statements"]:
            raise ValueError("예시 SQL 문장 개수 제한을 초과했습니다.")
        # Validate every statement before executing any of them.
        commands = [_command(node) for node in nodes]
        namespace = 'example-'+hashlib.sha256('\n'.join(blocks).encode()).hexdigest()[:12]
        started = time.monotonic()
        known = []
        with closing(sqlite3.connect(':memory:')) as db:
            db.enable_load_extension(False)
            db.setlimit(sqlite3.SQLITE_LIMIT_ATTACHED,0)
            db.setlimit(sqlite3.SQLITE_LIMIT_LENGTH,100000)
            db.setlimit(sqlite3.SQLITE_LIMIT_SQL_LENGTH,10000)
            db.setlimit(sqlite3.SQLITE_LIMIT_COLUMN,16)
            db.set_progress_handler(lambda: int(time.monotonic()-started > LIMITS['execution_seconds']),100)
            for i,command in enumerate(commands):
                if time.monotonic()-started > LIMITS['execution_seconds']:
                    raise ValueError("예시 SQL 실행 시간 제한을 초과했습니다.")
                before = _snapshot(db,known,namespace)
                sql = _execute(db,command,known)
                after = _snapshot(db,known,namespace)
                b = next((t for t in before if t['name'].casefold()==command['table'].casefold()),None)
                a = next((t for t in after if t['name'].casefold()==command['table'].casefold()),None)
                effects = {'table_count_before':len(before),'table_count_after':len(after),
                           'rows_before':len(b['rows']) if b else 0,'rows_after':len(a['rows']) if a else 0,
                           'columns_before':len(b['columns']) if b else 0,'columns_after':len(a['columns']) if a else 0}
                op=command['operation']
                if op=='create_table':
                    narration=f"설명용 새 예시입니다. CREATE TABLE 실행 뒤 {command['table']} 표에는 열 {effects['columns_after']}개와 행 {effects['rows_after']}개가 있습니다."
                elif op=='insert_rows':
                    narration=f"INSERT는 이 예시의 행을 {effects['rows_before']}개에서 {effects['rows_after']}개로 늘렸습니다. 열은 {effects['columns_after']}개로 그대로입니다."
                elif op=='add_column':
                    narration=f"ALTER TABLE은 이 예시의 열을 {effects['columns_before']}개에서 {effects['columns_after']}개로 늘렸습니다. 행은 {effects['rows_after']}개로 그대로입니다."
                else:
                    narration=f"DROP TABLE 실행 뒤 이 예시의 표 개수는 {effects['table_count_before']}개에서 {effects['table_count_after']}개가 됐습니다."
                report['steps'].append({'id':namespace+'-step-'+str(i),'operation':op,'sql':sql,
                    'before':before,'after':after,'table_name':command['table'],'effects':effects,
                    'narration':narration,'label':'설명용 새 예시','execution_status':'executed_in_disposable_sqlite'})
        report.update(status='verified',namespace=namespace)
        report['execution'].update(status='executed',statement_count=len(commands),elapsed_seconds=time.monotonic()-started)
        return report
    except (ValueError,TypeError,KeyError,sqlite3.Error,sqlglot.errors.ParseError) as exc:
        partial = report.pop('steps',[])
        return {**report,'status':'blocked','steps':[], 'partial_steps_audit_only':partial,
                'reason':str(exc),'execution':{**report['execution'],'status':'blocked_or_failed'}}
