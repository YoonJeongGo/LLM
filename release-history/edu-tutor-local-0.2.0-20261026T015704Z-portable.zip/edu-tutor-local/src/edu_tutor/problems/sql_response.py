"""Phase-2 response formatting support, separate from the frozen v1 extractor.

This only extracts a candidate. The caller must still perform the existing
isolated SQL execution, schema and intent checks before accepting an answer.
"""
from __future__ import annotations

import json
import re

from edu_tutor.evaluation.sql_sandbox import extract_sql as _legacy_extract_sql

SQL_EXTRACTION_PROTOCOL = "phase2_sql_response_v2_json_fence"
_JSON_FENCE = re.compile(
    r"[ \t\r\n]*```[ \t]*json[ \t]*\r?\n(.*?)\r?\n[ \t]*```[ \t\r\n]*",
    re.IGNORECASE | re.DOTALL,
)


def _unique_object(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError("ambiguous_parse: duplicate JSON key")
        value[key] = item
    return value


def extract_sql_candidate(output):
    """Accept existing forms or one complete JSON fence, never repair its text."""
    try:
        return _legacy_extract_sql(output)
    except ValueError:
        pass
    if not isinstance(output, str) or len(output) > 60000:
        raise ValueError("ambiguous_parse")
    match = _JSON_FENCE.fullmatch(output)
    if match is None:
        raise ValueError("ambiguous_parse")
    try:
        value = json.loads(match.group(1), object_pairs_hook=_unique_object)
    except (ValueError, TypeError) as exc:
        raise ValueError("ambiguous_parse: invalid or ambiguous JSON fence") from exc
    if (not isinstance(value, dict) or set(value) - {"sql", "explanation", "schema_version"}
            or not isinstance(value.get("sql"), str) or not value["sql"].strip()):
        raise ValueError("ambiguous_parse")
    return _legacy_extract_sql(value)
