"""SQLite execution and explicitly bounded intent/calculation evidence.

No reference answers or question IDs are consulted. Tables supplied by the user
are the only numerical inputs. SQL execution is not an intent verdict.
"""
from __future__ import annotations

import copy
import hashlib
import re

import sqlglot
from sqlglot import exp

from edu_tutor.evaluation.sql_sandbox import execute_sql, compare_results
from .sql_response import extract_sql_candidate, SQL_EXTRACTION_PROTOCOL
from .models import canonical, identified_table, derive_hypothesis, infer_basic_intent


def quote(name):
    if not re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]{0,63}", name):
        raise ValueError("지원하지 않는 식별자입니다.")
    return '"' + name + '"'


def fixture(problem):
    return {"tables": [{"name": t["name"], "columns": [{"name": c["name"], "type": c["type"]} for c in t["columns"]],
                        "rows": t["rows"]} for t in problem["tables"]]}


def aggregate_spec(expression):
    value = expression.this if isinstance(expression, exp.Alias) else expression
    if not isinstance(value, (exp.Count, exp.Sum, exp.Avg)):
        return None
    operand = value.this
    distinct = isinstance(operand, exp.Distinct)
    if distinct:
        if len(operand.expressions) != 1:
            return None
        operand = operand.expressions[0]
    column = "*" if isinstance(operand, exp.Star) else operand.name if isinstance(operand, exp.Column) else None
    if column is None or column == "*" and not isinstance(value, exp.Count):
        return None
    return {"function": type(value).__name__.lower(), "column": column, "distinct": distinct}


def bounded_query(sql, problem):
    statements = sqlglot.parse(sql, read="sqlite")
    if len(statements) != 1 or not isinstance(statements[0], exp.Select):
        raise ValueError("논리 단계 계산 범위는 단일 SELECT입니다.")
    query = statements[0]
    if any(query.args.get(key) for key in ("with_", "joins", "limit", "offset", "distinct")) or any(query.find_all(exp.Subquery)):
        raise ValueError("이 계산 설명은 단일 표의 집계만 지원합니다. JOIN/CTE/중첩 질의는 실행 결과만 표시합니다.")
    source = query.args.get("from_")
    if not source or not isinstance(source.this, exp.Table):
        raise ValueError("원본 표를 확인할 수 없습니다.")
    table = next((t for t in problem["tables"] if t["name"].casefold() == source.this.name.casefold()), None)
    if table is None:
        raise ValueError("SQL이 원본에 없는 표를 참조합니다.")
    group = query.args.get("group")
    groups = list(group.expressions) if group else []
    if any(not isinstance(item, exp.Column) for item in groups):
        raise ValueError("그룹 식은 원본 열 이름만 지원합니다.")
    group_names = [item.name for item in groups]
    specs = []
    for item in query.expressions:
        spec = aggregate_spec(item)
        if spec:
            specs.append(spec)
        elif not isinstance(item, exp.Column) or item.name not in group_names:
            raise ValueError("집계 설명 범위는 그룹 열 및 COUNT/SUM/AVG입니다.")
    if not specs:
        raise ValueError("COUNT/SUM/AVG 계산을 찾지 못했습니다.")
    return query, table, specs, group_names


def normalized_clause(clause):
    if clause is None:
        return ""
    value = clause.copy()
    for column in value.find_all(exp.Column):
        column.set("table", None)
    for ident in value.find_all(exp.Identifier):
        ident.set("this", ident.name.casefold())
    return value.sql(dialect="sqlite", normalize=True)


def intent_sql(intent):
    columns = [quote(name) for name in intent.get("group_by", [])]
    for i, item in enumerate(intent["aggregates"]):
        function = item["function"].upper()
        if function not in {"COUNT", "SUM", "AVG"}:
            raise ValueError("지원하지 않는 집계 연산입니다.")
        operand = "*" if item["column"] == "*" else quote(item["column"])
        if item.get("distinct"):
            operand = "DISTINCT " + operand
        columns.append(f"{function}({operand}) AS result_{i + 1}")
    sql = "SELECT " + ", ".join(columns) + " FROM " + quote(intent["table"])
    for key, keyword in (("where", " WHERE "), ("group_by", " GROUP BY "), ("having", " HAVING ")):
        value = intent.get(key)
        if value:
            sql += keyword + (", ".join(quote(x) for x in value) if key == "group_by" else value)
    return sql


def check_intent(sql, problem, question):
    intent, scope = infer_basic_intent(problem, question)
    if not intent:
        return {"status": "unsupported", "scope": scope}, None
    try:
        candidate, table, specs, groups = bounded_query(sql, problem)
        expected, expected_table, expected_specs, expected_groups = bounded_query(intent_sql(intent), problem)
        def spec_key(items):
            return [(s["function"], s["column"].casefold(), bool(s["distinct"])) for s in items]
        same = (table["name"].casefold() == expected_table["name"].casefold()
                and spec_key(specs) == spec_key(expected_specs)
                and [x.casefold() for x in groups] == [x.casefold() for x in expected_groups]
                and all(normalized_clause(candidate.args.get(k)) == normalized_clause(expected.args.get(k)) for k in ("where", "having")))
        return {"status": "supported_match" if same else "mismatch", "scope": scope,
                "requested": intent, "candidate_aggregates": specs,
                "reason": "확인된 기본 집계·조건·그룹 구조가 질문의 의도와 일치합니다." if same else "실행 가능 여부와 별개로 집계 대상·NULL 처리·조건·그룹 중 요청과 다른 부분이 있습니다."}, intent
    except (ValueError, sqlglot.errors.ParseError) as exc:
        return {"status": "unsupported", "scope": scope, "reason": str(exc)}, intent


def logical_evidence(sql, problem, namespace):
    query, table, specs, group_names = bounded_query(sql, problem)
    display = identified_table(problem, table, namespace=namespace)
    names = [c["name"] for c in table["columns"]]
    lookup = {name.casefold(): i for i, name in enumerate(names)}
    if any(s["column"] != "*" and s["column"].casefold() not in lookup for s in specs):
        raise ValueError("집계 열이 원본에 없습니다.")
    source = query.args["from_"].this
    rowid = next((name for name in ("_rowid_", "rowid", "oid") if name.casefold() not in lookup), None)
    if rowid is None:
        raise ValueError("안정적인 행 추적에 필요한 내부 식별자가 모두 가려져 있습니다.")
    qualifier = quote(source.alias_or_name)
    trace = "SELECT " + qualifier + "." + rowid + " - 1 AS row_index FROM " + source.sql(dialect="sqlite")
    if query.args.get("where"):
        trace += " " + query.args["where"].sql(dialect="sqlite")
    filtered = execute_sql(trace, fixture(problem))
    if filtered["status"] != "executed":
        raise ValueError("WHERE 행 추적 실패: " + filtered.get("error", ""))
    indices = [int(row[0]) for row in filtered["rows"]]
    groups = {}
    for index in indices:
        row = table["rows"][index]
        key = tuple(row[lookup[name.casefold()]] for name in group_names)
        groups.setdefault(key, []).append(index)
    if not group_names and not groups:
        groups[()] = []
    aggregates, computed_rows = [], []
    for number, (key, members) in enumerate(groups.items()):
        group_id = display["id"] + "-group-" + hashlib.sha256(canonical(key).encode()).hexdigest()[:10]
        results = []
        for position, spec in enumerate(specs):
            column = spec["column"]
            col = None if column == "*" else lookup[column.casefold()]
            included = members if col is None else [i for i in members if table["rows"][i][col] is not None]
            values = [1 if col is None else table["rows"][i][col] for i in included]
            if spec["distinct"]:
                unique = []
                seen = []
                for index, value in zip(included, values):
                    if value not in seen:
                        seen.append(value)
                        unique.append(index)
                included, values = unique, seen
            count = len(values)
            if spec["function"] in {"sum", "avg"} and any(not isinstance(v, (int, float)) for v in values):
                raise ValueError("SUM/AVG 중간 계산은 숫자 열만 지원합니다.")
            total = sum(values) if values and spec["function"] in {"sum", "avg"} else None
            value = count if spec["function"] == "count" else total if spec["function"] == "sum" else total / count if count else None
            results.append(value)
            aggregates.append({"id": f"{group_id}-aggregate-{position}", "group_id": group_id, "group_values": list(key),
                **spec, "included_values": values, "count": count, "sum": total, "result": value,
                "included_row_ids": [display["row_ids"][i] for i in included],
                "included_cell_ids": [] if col is None else [display["cell_ids"][i][col] for i in included],
                "excluded_null_cell_ids": [] if col is None else [display["cell_ids"][i][col] for i in members if table["rows"][i][col] is None]})
        row, aggregate_index = [], 0
        for item in query.expressions:
            if aggregate_spec(item):
                row.append(results[aggregate_index]); aggregate_index += 1
            else:
                row.append(key[group_names.index(item.name)])
        computed_rows.append(row)
    unfiltered = query.copy()
    unfiltered.set("having", None)
    unfiltered.set("order", None)
    intermediate = execute_sql(unfiltered.sql(dialect="sqlite"), fixture(problem))
    expected = {"columns": intermediate.get("columns", []), "rows": computed_rows, "row_order": "unordered", "numeric_abs_tolerance": 1e-8}
    if not compare_results(intermediate, expected):
        raise ValueError("독립 집계 계산과 SQLite 중간 결과가 일치하지 않습니다.")
    return {"kind": "logical_teaching_steps_not_physical_execution", "table_id": display["id"],
            "where_sql": query.args["where"].sql(dialect="sqlite") if query.args.get("where") else None,
            "filtered_row_ids": [display["row_ids"][i] for i in indices],
            "group_columns": group_names, "groups": [{"values": list(key), "row_ids": [display["row_ids"][i] for i in members]} for key, members in groups.items()],
            "aggregates": aggregates, "before_having": intermediate,
            "having_sql": query.args["having"].sql(dialect="sqlite") if query.args.get("having") else None}


def verify_answer(problem, raw_response, question, hypothesis=None):
    base = copy.deepcopy(problem)
    scope_problem, hypothesis_value = derive_hypothesis(base, hypothesis) if hypothesis else (base, None)
    scenario = "hypothesis" if hypothesis_value else "original"
    evidence = {"id": "evidence-" + hashlib.sha256(canonical({"problem": base, "hypothesis": hypothesis_value, "question": question}).encode()).hexdigest()[:20],
        "problem_id": base["id"], "problem_revision": base["revision"], "task_kind":base["task_kind"], "scenario": scenario, "hypothesis": hypothesis_value,
        "input": {"status": "user_confirmed" if base["confirmed"] else "unconfirmed", "source": base["source"]},
        "schema": {"status": "not_checked"}, "execution": {"status": "not_run", "dialect": base["dialect"]},
        "calculation": {"status": "not_checked"}, "intent": {"status": "not_checked"},
        "expected_result_check": {"status": "not_available", "reason": "실사용 문제에 독립 정답이 제공되지 않았습니다."},
        "explanation": {"status": "not_verified"}, "human_review": "not_reviewed",
        "original_tables": [identified_table(base, t) for t in base["tables"]],
        "working_tables": [identified_table(scope_problem, t, namespace=scenario) for t in scope_problem["tables"]],
        "result": None, "logical_steps": None, "status": "needs_input", "can_repair": False, "reasons": []}
    def stop(reason, status="needs_input", repair=False):
        evidence.update(status=status, reasons=[reason], can_repair=repair)
        return evidence
    if base["task_kind"] == "concept":
        return stop("일반 설명은 자동 진실성 검증 대상이 아닙니다. 새 예시는 설명용으로 표시합니다.", "concept_unverified")
    if not base["confirmed"]:
        return stop("원본 표·SQL·조건을 확인하고 확정해 주세요.")
    if base["missing_conditions"]:
        return stop("필요한 조건: " + "; ".join(base["missing_conditions"]))
    if base["dialect"] != "sqlite":
        return stop(f"{base['dialect']} 문제는 SQLite로 정확성을 검증하지 않습니다. DBMS에 맞는 실행 결과 또는 조건이 필요합니다.", "unsupported")
    if not base["tables"]:
        return stop("수치 결과를 계산할 원본 표의 열 이름·자료형·행 값이 필요합니다.")
    supplied = base["task_kind"] in {"query_result", "explain_error"}
    if supplied:
        sql = base.get("query")
        if not sql:
            # Aggregate requests with no supplied SQL can still be computed
            # from an unambiguous, bounded requested intent.
            intent, reason = infer_basic_intent(base, base["raw_text"])
            if not intent:
                return stop("실행할 원문 SQL이 필요합니다. " + reason)
            sql = intent_sql(intent)
            evidence["intent"] = {"status": "supported_match", "scope": reason, "requested": intent}
            evidence["sql_origin"] = "application_from_confirmed_bounded_intent"
        else:
            evidence["intent"] = {"status": "given_query_result", "scope": "학생이 제공한 SQL 자체의 실행 결과. 그 SQL이 다른 자연어 목적에 맞는지는 별개입니다."}
            evidence["sql_origin"] = "unchanged_user_query"
    else:
        try:
            evidence["sql_extraction_protocol"] = SQL_EXTRACTION_PROTOCOL
            sql = extract_sql_candidate(raw_response)
        except ValueError:
            return stop("모델 SQL 후보를 명확히 추출하지 못했습니다.", "stopped", True)
        evidence["sql_origin"] = "model_candidate"
        evidence["intent"], _ = check_intent(sql, base, base["raw_text"])
    evidence["sql"] = sql
    actual = execute_sql(sql, fixture(scope_problem), dialect=base["dialect"])
    evidence["execution"] = {**actual, "dialect": base["dialect"]}
    if actual["status"] != "executed":
        evidence["schema"] = {"status": "failed", "reason": actual.get("error")}
        return stop("원문 스키마에서 SQL을 실행하지 못했습니다: " + actual.get("error", actual["status"]), "stopped", not supplied)
    evidence["schema"] = {"status": "resolved_by_sqlite_prepare", "scope": "별칭·CTE를 포함한 SQLite 이름 해석과 안전한 실행"}
    if evidence["intent"]["status"] not in {"given_query_result", "supported_match"}:
        return stop(evidence["intent"].get("reason", evidence["intent"].get("scope", "질문 의도 확인 불가")), "stopped", evidence["intent"]["status"] == "mismatch")
    evidence["result"] = {"columns": actual["columns"], "rows": actual["rows"]}
    try:
        evidence["logical_steps"] = logical_evidence(sql, scope_problem, scenario)
        evidence["calculation"] = {"status": "independent_aggregate_match", "scope": "원본 값의 COUNT/SUM/AVG를 별도 계산하여 SQLite 집계 결과와 비교"}
    except (ValueError, KeyError, sqlglot.errors.ParseError) as exc:
        evidence["calculation"] = {"status": "outside_supported_trace", "reason": str(exc)}
    evidence.update(status="verified", can_repair=False)
    evidence["explanation"] = {"status": "tool_derived_numeric_statements_only", "scope": "수치·표·집계 대사만 공유 근거에서 생성. 모델 자유 설명 전체는 검증하지 않음."}
    return evidence


def display_answer(evidence):
    if evidence["status"] != "verified":
        return "확인 필요: " + " ".join(evidence["reasons"])
    prefix = "설명용 새 가정의 결과입니다. 원래 문제의 값은 바꾸지 않았습니다.\n" if evidence["scenario"] == "hypothesis" else "확정한 원본 문제를 기준으로 도구가 계산한 결과입니다. 모델 초안과 구분합니다.\n"
    result = evidence["result"]
    lines = [" | ".join(result["columns"])]
    lines.extend(" | ".join("NULL" if v is None else str(v) for v in row) for row in result["rows"])
    if not result["rows"]:
        lines.append("결과 행이 없습니다.")
    sql = "```sql\n" + evidence["sql"] + "\n```\n" if evidence.get("task_kind") == "write_sql" else ""
    return prefix + sql + "\n".join(lines)
