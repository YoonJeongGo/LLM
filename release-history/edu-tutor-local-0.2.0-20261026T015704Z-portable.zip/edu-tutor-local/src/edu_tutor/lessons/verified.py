"""Board cells and spoken numbers are rendered from a single evidence object."""
from __future__ import annotations
import copy
import re
from edu_tutor.lessons.plans import validate_plan
from edu_tutor.problems.evidence import display_answer


def value_text(value):
    return "NULL" if value is None else str(value)


def table_action(table, slot="main", caption="확정한 원본 표"):
    return {"type":"table", "element_id":table["id"], "slot":slot, "columns":table["columns"],
            "rows":table["rows"], "row_ids":table["row_ids"], "column_ids":table["column_ids"],
            "cell_ids":table["cell_ids"], "table_name":table["name"], "caption":caption,
            "timing":{"start":0,"end":0}}


def step(ident, title, speech, actions, target, kind="point"):
    return {"id":ident,"title":title,"speech":speech,"board_actions":actions,
            "gesture":{"kind":kind,"target_element_id":target}}


def base_plan(message, question, lesson_id):
    problem=message["problem"]
    plan={"schema_version":"1.0", "lesson_id":lesson_id,"title":"원본 문제 확인", "goal":"원본 조건과 계산 근거를 연결합니다.",
          "question_text":question,"problem_source":"confirmed_image" if problem["source"]["kind"]=="photo" else "typed_user_input",
          "provenance":"tool_derived","source_refs":[],"steps":[],"final_summary":"계산 근거 확인",
          "problem_revision":problem["revision"],"source_message_id":message["id"],
          "evidence_ref":{"message_id":message["id"],"problem_revision":problem["revision"],"mode":message.get("evidence",{}).get("scenario","original")}}
    if problem["source"].get("photo_id"):plan["source_photo_id"]=problem["source"]["photo_id"]
    return plan


def generate_verified_plan(message, question, lesson_id):
    evidence=message["evidence"]
    if evidence["status"]!="verified":
        return {"plan":None,"fallback_text":message["content"],"status":"verification_stopped","reason":"수치·판서·음성으로 내보낼 계산 근거가 없습니다.","speech_allowed":False}
    plan=base_plan(message,question,lesson_id)
    independent=evidence["calculation"]["status"]=="independent_aggregate_match"
    plan["verification"]={"status":"calculation_checked" if independent else "execution_grounded",
        "scope":"확정한 원본 SQLite 실행 결과와 공유 수치 근거" + (" 및 독립 집계 대조" if independent else ""),
        "limitations":["자연어 설명 전체의 진실성 또는 일반 SQL 의도를 자동 증명하지 않습니다.","실사용 독립 정답 일치 검사는 없으며 사람 검토도 미실시입니다.","논리 단계는 학습용이며 데이터베이스 물리 실행 추적이 아닙니다."]}
    tables=evidence["working_tables"]
    # Bound visible teaching units, not the numerical sandbox's input capacity.
    if any(len(t["rows"])>200 for t in tables):
        return {"plan":None,"fallback_text":message["content"],"status":"verification_stopped","reason":"판서는 표당 200행까지만 지원합니다.","speech_allowed":False}
    actions=[table_action(t, "main" if i==0 else "right", "설명용 새 가정의 표 · 원본은 보존" if evidence["scenario"]=="hypothesis" else "확정한 원본 표") for i,t in enumerate(tables)]
    logical=evidence.get("logical_steps")
    result=evidence["result"]
    result_id=evidence["id"]+"-result"
    result_board={"type":"table","element_id":result_id,"slot":"bottom","columns":result["columns"],"rows":result["rows"],"caption":"최종 SELECT 실행 결과","timing":{"start":0,"end":0}}
    supplementary=bool(message.get("lesson_context"))
    if logical and not logical["group_columns"] and len(logical["aggregates"])<=3 and not logical["where_sql"]:
        table=next(t for t in tables if t["id"]==logical["table_id"])
        for i,aggregate in enumerate(logical["aggregates"]):
            column=aggregate["column"]; function=aggregate["function"]
            value=value_text(aggregate["result"])
            if function=="count":
                speech=f"카운트 별표는 전체 행을 세어 {value}입니다." if column=="*" else f"{column}의 카운트는 NULL을 제외한 값을 세어 {value}입니다."
            else:
                speech=f"{column}의 합계는 {value}입니다." if function=="sum" else f"{column}의 합계 {value_text(aggregate['sum'])}을 값 {aggregate['count']}개로 나누면 평균 {value}입니다." if aggregate["count"] else f"{column}에 평균을 낼 값이 없어 결과는 NULL입니다."
            if aggregate["distinct"]:speech="중복을 제외합니다. "+speech
            highlight={"type":"highlight","element_id":f"highlight-{i}","target_element_id":table["id"],"style":"background","timing":{"start":0,"end":0}}
            if column=="*":highlight["row_indices"]=[table["row_ids"].index(r) for r in aggregate["included_row_ids"]]
            else:highlight["cell_ids"]=aggregate["included_cell_ids"]
            unit_actions=(actions if i==0 else [{"type":"clear","target":f"highlight-{i-1}"}])+[highlight]
            if i==len(logical["aggregates"])-1:unit_actions.append(result_board)
            plan["steps"].append(step(f"s{i+1}",f"{function.upper()}({column})",speech,unit_actions,table["id"]))
        if supplementary:
            combined=actions+[result_board]
            selected=(message.get("lesson_context") or {}).get("selected_cell") or {}
            cell=selected.get("cell_id")
            validcells={c for t in tables for row in t["cell_ids"] for c in row}
            if cell in validcells:combined.append({"type":"highlight","target_element_id":table["id"],"cell_ids":[cell],"style":"outline","timing":{"start":0,"end":0}})
            else:
                nulls=[c for row,ids in zip(table["rows"],table["cell_ids"]) for v,c in zip(row,ids) if v is None]
                if nulls:combined.append({"type":"highlight","target_element_id":table["id"],"cell_ids":nulls,"style":"outline","timing":{"start":0,"end":0}})
            prefix="설명용 새 가정입니다. " if evidence["scenario"]=="hypothesis" else "NULL인 칸이 있어도 그 행은 존재합니다. "
            speech=prefix+" ".join(s["speech"] for s in plan["steps"])
            whole=next((a for a in logical["aggregates"] if a["function"]=="count" and a["column"]=="*" and not a["distinct"]),None)
            valued=[a for a in logical["aggregates"] if a["function"]=="count" and a["column"]!="*" and not a["distinct"]]
            if whole and len(valued)==1 and len(logical["aggregates"])==2:
                item=valued[0]
                original_table=next(t for t in message["problem"]["tables"] if t["name"]==table["name"])
                original_column=next(c for c in original_table["columns"] if c["name"].casefold()==item["column"].casefold())
                label=original_column.get("label") or item["column"]
                if len(label)>12:label="해당 열"
                prefix="새 가정입니다. " if evidence["scenario"]=="hypothesis" else "값이 없어도 행은 남습니다. "
                speech=prefix+f"전체 행 {value_text(whole['result'])}개, {label} 값 {value_text(item['result'])}개입니다."
            plan["steps"]=[step("s1","현재 표로 다시 확인",speech,combined,table["id"])]
    elif logical:
        table=next(t for t in tables if t["id"]==logical["table_id"])
        selected=[table["row_ids"].index(r) for r in logical["filtered_row_ids"]]
        plan["steps"].append(step("s1","원본에서 WHERE 적용",f"원본 {len(table['rows'])}행 중 WHERE를 통과한 행은 {len(selected)}개입니다. 학습용 논리 순서입니다.",actions+[{"type":"highlight","target_element_id":table["id"],"row_indices":selected,"style":"background","timing":{"start":0,"end":0}}],table["id"]))
        filtered={"type":"table","element_id":evidence["id"]+"-where","slot":"right","columns":table["columns"],"rows":[table["rows"][i] for i in selected],"caption":"WHERE 이후 남은 원본 행"}
        grouping={"type":"table","element_id":evidence["id"]+"-groups","slot":"bottom","columns":[*logical["group_columns"],"포함 행"],"rows":[[*g["values"],", ".join(str(table["row_ids"].index(r)+1) for r in g["row_ids"])] for g in logical["groups"]],"caption":"GROUP BY 묶음 · 원본 행 번호"}
        plan["steps"].append(step("s2","그룹으로 묶기",f"남은 행을 {len(logical['groups'])}개 그룹으로 묶습니다.",[filtered,grouping],grouping["element_id"]))
        intermediate={"type":"table","element_id":evidence["id"]+"-aggregate","slot":"right","columns":logical["before_having"]["columns"],"rows":logical["before_having"]["rows"],"caption":"그룹별 집계 · HAVING 이전"}
        plan["steps"].append(step("s3","집계 계산", "각 그룹의 실제 입력값으로 집계하고 SQLite 결과와 대조했습니다.",[{"type":"clear","target":filtered["element_id"]},intermediate],intermediate["element_id"]))
        plan["steps"].append(step("s4","HAVING과 최종 SELECT",f"HAVING 조건을 적용한 최종 SELECT 결과는 {len(result['rows'])}행입니다.",[{"type":"clear","target":grouping["element_id"]},result_board],result_id))
    else:
        plan["steps"]=[step("s1","원본 SQL의 실행 결과",f"학생이 준 SQL의 SQLite 실행 결과는 {len(result['rows'])}행입니다. 중간 계산 설명은 지원 범위 밖입니다.",actions+[result_board],result_id)]
    plan["title"]="새 가정의 계산" if evidence["scenario"]=="hypothesis" else "원본 문제의 계산 근거"
    plan["final_summary"]=display_answer(evidence)
    validate_plan(plan)
    return {"plan":plan,"status":"verified_tool_plan","reason":None,"speech_allowed":True,
            "generation":{"source":"shared_evidence","model_plan_calls":0,"repair_requests":0}}


def concept_plan(message, question, lesson_id):
    """Directly reuse the actual short model answer, never re-generate numbers."""
    plan=base_plan(message,question,lesson_id)
    plan.update(title="개념 설명",goal="질문의 핵심 개념을 확인합니다.",provenance="model_generated")
    plan["evidence_ref"]["mode"]="concept_example"
    plan["verification"]={"status":"unverified","scope":"실제 모델의 일반 개념 설명; 계산 또는 설명 전체의 정확성은 검증하지 않음",
        "limitations":["사람 검토가 필요합니다.","나오는 예시는 설명용 새 예시이며 학생 원본 문제의 수치 답이 아닙니다."]}
    text=message["content"].strip()
    from edu_tutor.problems.ddl_examples import build_ddl_example
    example=build_ddl_example(message.get("raw_model_response",text)) if message["problem"]["dialect"]=="sqlite" else {"status":"not_available","reason":"다른 DBMS의 동작을 SQLite 예시로 검증하지 않습니다."}
    if example["status"]=="blocked":
        return {"plan":None,"status":"verification_stopped","fallback_text":text,
            "reason":"설명용 SQL 예시 검증 실패: "+example["reason"],"speech_allowed":False,
            "example_evidence":example,"generation":{"source":"blocked_model_authored_example","model_plan_calls":0}}
    if example["status"]=="verified" and len(example["steps"])<=4:
        plan.update(title="설명용 새 예시 · 구조와 행 변화",provenance="tool_derived")
        plan["verification"]={"status":"execution_grounded","scope":"실제 모델이 작성한 예시 SQL을 격리 SQLite에서 실행한 전후 표와 변화 설명",
            "limitations":["학생 원본 문제의 답이 아니라 명시된 새 예시입니다.","모델의 자유 설명은 검증하지 않았습니다.","다른 DBMS 동작 및 사람의 교육·청취 검토는 미검증입니다."]}
        for number,item in enumerate(example["steps"]):
            actions=[{"type":"clear","target":"all"},{"type":"code","element_id":item["id"]+"-sql","slot":"bottom","language":"sql","code":item["sql"]}]
            before=next((t for t in item["before"] if t["name"].casefold()==item["table_name"].casefold()),None)
            after=next((t for t in item["after"] if t["name"].casefold()==item["table_name"].casefold()),None)
            if before:
                previous=copy.deepcopy(before)
                previous["id"]+="-before"
                previous["row_ids"]=[r+"-before" for r in previous["row_ids"]]
                previous["column_ids"]=[c+"-before" for c in previous["column_ids"]]
                previous["cell_ids"]=[[c+"-before" for c in row] for row in previous["cell_ids"]]
                actions.append(table_action(previous,"left","설명용 새 예시 · 실행 전"))
            else:actions.append({"type":"text","element_id":item["id"]+"-empty-before","slot":"left","text":"실행 전: 이 예시 표가 없습니다."})
            if after:actions.append(table_action(after,"right","설명용 새 예시 · 실행 후"))
            else:actions.append({"type":"text","element_id":item["id"]+"-empty-after","slot":"right","text":"실행 후: 이 예시 표가 없습니다."})
            target=after["id"] if after else item["id"]+"-empty-after"
            if after and item["operation"]=="add_column":
                actions.append({"type":"highlight","target_element_id":after["id"],"column_indices":[len(after["columns"])-1],"style":"background"})
            elif after and item["operation"]=="insert_rows":
                actions.append({"type":"highlight","target_element_id":after["id"],"row_indices":list(range(item["effects"]["rows_before"],item["effects"]["rows_after"])),"style":"background"})
            plan["steps"].append(step(f"s{number+1}",item["operation"],item["narration"],actions,target))
        plan["final_summary"]="설명용 새 예시. "+" ".join(i["narration"] for i in example["steps"])
        validate_plan(plan)
        return {"plan":plan,"status":"verified_example_plan","reason":"일반 모델 설명과 별도로 예시 실행 변화만 검증했습니다.",
            "speech_allowed":True,"fallback_text":text,"example_evidence":example,
            "generation":{"source":"executed_model_authored_example","model_plan_calls":0}}
    sentences=[s.strip() for s in re.split(r"(?<=[.!?。])\s+|\n+",text) if s.strip()]
    chunks=[]
    for sentence in sentences:
        if chunks and len(chunks[-1])+len(sentence)<220:chunks[-1]+=" "+sentence
        else:chunks.append(sentence)
    if not chunks or len(chunks)>4 or any(len(c)>1000 for c in chunks):
        return {"plan":None,"status":"text_fallback","fallback_text":text,"reason":"짧은 설명 단위 4개를 초과하여 텍스트로 보존합니다.","speech_allowed":False,"example_evidence":example}
    for i,chunk in enumerate(chunks):
        ident=f"concept-{i}"
        plan["steps"].append(step(f"s{i+1}","핵심 설명" if i==0 else "설명 이어서",chunk,
            [{"type":"clear","target":"all"},{"type":"text","element_id":ident,"slot":"main","text":chunk},
             {"type":"text","element_id":ident+"-notice","slot":"bottom","text":"일반 설명 미검증 · 새 예시는 설명용"}],ident,"explain"))
    plan["final_summary"]=text
    validate_plan(plan)
    return {"plan":plan,"status":"structured_unverified","reason":"일반 개념 설명은 검증 전이므로 음성을 준비하지 않습니다.","speech_allowed":False,"example_evidence":example,
            "generation":{"source":"actual_model_answer_units","model_plan_calls":0}}
