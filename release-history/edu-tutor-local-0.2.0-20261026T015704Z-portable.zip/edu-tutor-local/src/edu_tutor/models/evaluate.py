"""Frozen-protocol baseline/adapter evaluation. No reference answers in generation inputs."""
from __future__ import annotations
import hashlib
import json
import time
from pathlib import Path

PROTOCOL = {"version": 1, "max_new_tokens": 256, "do_sample": False, "rag": False,
            "notice": "소규모 데모 평가입니다. 파이프라인 검증용이며, 전체 교육 성능이나 일반화 성능을 보장하지 않습니다."}


def evaluation_job(payload, emit):
    import torch
    from transformers import StoppingCriteria, StoppingCriteriaList
    from .worker import load_text
    root = Path(payload["root"])
    model, tokenizer, meta = load_text(root, payload.get("adapter"))
    rows = payload["questions"]
    if not isinstance(rows, list) or not 1 <= len(rows) <= 12:
        raise ValueError("Evaluation batches contain 1..12 questions")
    cancelled = Path(payload["cancel_path"])
    class Stop(StoppingCriteria):
        def __call__(self, *_args, **_kwargs):
            return cancelled.exists()
    for record in rows:
        prompt = "SQLite 문제에 답하세요. 조건이 충분하면 정확히 JSON {\"sql\":\"SELECT ...\",\"explanation\":\"짧은 설명\"}만 출력하세요. 조건이 부족하면 필요한 조건을 질문하세요."
        inputs = tokenizer.apply_chat_template([{"role":"system","content":prompt},{"role":"user","content":record["question"]}],
            add_generation_prompt=True, enable_thinking=False, tokenize=True, return_dict=True, return_tensors="pt").to(model.device)
        if inputs["input_ids"].shape[-1] + PROTOCOL["max_new_tokens"] > 2048:
            raise ValueError("Evaluation input exceeds context budget")
        started = time.monotonic()
        with torch.inference_mode():
            output = model.generate(**inputs, max_new_tokens=PROTOCOL["max_new_tokens"], do_sample=False,
                pad_token_id=tokenizer.pad_token_id, stopping_criteria=StoppingCriteriaList([Stop()]))
        tokens = output[0][inputs["input_ids"].shape[-1]:].tolist()
        if cancelled.exists():
            raise RuntimeError("Evaluation cancelled")
        emit("evaluation_item", id=record["id"], text=tokenizer.decode(tokens, skip_special_tokens=True),
             finish_reason="eos" if tokens and tokens[-1] == tokenizer.eos_token_id else "length",
             output_tokens=len(tokens), latency_seconds=time.monotonic()-started,
             peak_vram_bytes=torch.cuda.max_memory_allocated(), revision=meta["revision"])


def run_evaluation(root, output_dir, adapter=None, *, cancel_event=None, job_id=None):
    from edu_tutor.evaluation.sql_sandbox import extract_sql, evaluate_sql
    from .runtime import run_worker
    root, output_dir = Path(root), Path(output_dir)
    data_file = root / "data/demo/test.jsonl"
    records = [json.loads(line) for line in data_file.read_text(encoding="utf-8").splitlines() if line.strip()]
    # Only public problem text is passed into the model subprocess.
    questions = [{"id": r["id"], "question": next(m["content"] for m in r["messages"] if m["role"] == "user")} for r in records]
    by_id = {r["id"]:r for r in records}
    output_dir.mkdir(parents=True, exist_ok=True)
    report = {"tier":"T2", "protocol":PROTOCOL, "dataset_sha256":hashlib.sha256(data_file.read_bytes()).hexdigest(),
              "adapter":str(adapter) if adapter else None, "human_review":"not_reviewed", "items":[], "status":"running"}
    artifact = output_dir / "evaluation.json"
    def save():
        artifact.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    save()
    try:
        payload = {"kind":"evaluation","questions":questions,"adapter":str(adapter) if adapter else None}
        if job_id:
            payload["job_id"] = job_id
        for event in run_worker(payload, root=root, timeout=900, cancel_event=cancel_event):
            if event["type"] != "evaluation_item":
                continue
            record = by_id[event["id"]]
            item = {k:v for k,v in event.items() if k != "type"}
            item["sql_match"] = False
            if "expected" in record and event["finish_reason"] == "eos":
                try:
                    sql = extract_sql(event["text"])
                    result = evaluate_sql(sql, record)
                    item.update(sql=sql, sql_result=result, sql_match=result["match"])
                except ValueError as exc:
                    item["parse_error"] = str(exc)
            elif "expected" not in record:
                item["clarification_auto_signal"] = any(word in event["text"] for word in ["알려", "필요", "조건", "제공", "확인"])
                item["clarification_quality"] = "not_reviewed"
            report["items"].append(item)
            print(json.dumps({"id":item["id"],"finish_reason":item["finish_reason"],"sql_match":item["sql_match"]},ensure_ascii=False),flush=True)
            save()
        if cancel_event is not None and cancel_event.is_set():
            report.update(status="cancelled")
            return report
        if sorted(i["id"] for i in report["items"]) != sorted(by_id):
            raise RuntimeError("평가 일부 문항이 누락되어 완료로 기록할 수 없습니다.")
        sql_ids = {r["id"] for r in records if "expected" in r}
        report.update(status="completed", sql_correct=sum(i["sql_match"] for i in report["items"] if i["id"] in sql_ids),
                      sql_total=len(sql_ids), total=len(records), truncated=sum(i["finish_reason"] != "eos" for i in report["items"]))
    except Exception as exc:
        if cancel_event is not None and cancel_event.is_set():
            report.update(status="cancelled", error=str(exc))
            return report
        report.update(status="failed",error=str(exc))
        raise
    finally:
        save()
    return report
