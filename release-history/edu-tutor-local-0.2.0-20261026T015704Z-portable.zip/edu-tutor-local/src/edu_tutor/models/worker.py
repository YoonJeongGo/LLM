"""Private JSON pipe protocol. Not an arbitrary-command worker."""
from __future__ import annotations
import json
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

from edu_tutor.jobs.lease import GPULease


def emit(event_type, **values):
    print(json.dumps({"type": event_type, **values}, ensure_ascii=False), flush=True)


def load_text(root, adapter=None):
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
    folder = root / ".local/models/text"
    meta = json.loads((folder / "model-manifest.json").read_text(encoding="utf-8"))
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA unavailable; full 1.7B CPU fallback is disabled")
    dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
    tokenizer = AutoTokenizer.from_pretrained(folder, local_files_only=True, trust_remote_code=False)
    model = AutoModelForCausalLM.from_pretrained(folder, local_files_only=True, trust_remote_code=False,
        use_safetensors=True, device_map={"": 0}, torch_dtype=dtype, attn_implementation="sdpa",
        quantization_config=BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
            bnb_4bit_use_double_quant=True, bnb_4bit_compute_dtype=dtype))
    if adapter:
        from peft import PeftModel
        path = Path(adapter).resolve()
        if not any(path.is_relative_to(base.resolve()) for base in (root / ".local/adapters", root / "runs")):
            raise ValueError("Adapter must be a registered project artifact")
        manifest_path = path / "adapter-manifest.json"
        if not manifest_path.exists():
            manifest_path = path.parent / "manifest.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        revision = manifest.get("base_revision") or manifest.get("model_revision") or manifest.get("revision")
        if revision != meta["revision"]:
            raise ValueError("Adapter base revision mismatch")
        if not (path / "adapter_model.safetensors").is_file() or any(path.glob("*.bin")) or any(path.glob("*.pkl")) or any(path.glob("*.pt")):
            raise ValueError("Only safetensors adapters are allowed")
        model = PeftModel.from_pretrained(model, path, local_files_only=True, is_trainable=False,
                                         use_safetensors=True, trust_remote_code=False)
    model.eval()
    structure = {"validation": "loaded_on_gpu", "device": str(model.device), "dtype": str(dtype),
        "last_loaded_at": datetime.now(timezone.utc).isoformat(), "last_loaded_adapter": str(adapter) if adapter else None,
        "resident": False, "structure_notice": "최근 로딩 기록입니다. 작업이 끝나면 모델 프로세스는 종료됩니다.",
        "parameter_count": sum(p.numel() for p in model.parameters()),
        "parameter_count_kind": "stored_tensor_elements_quantized",
        "parameter_count_notice": "양자화된 저장 텐서의 요소 수입니다. 원래 모델의 논리적 파라미터 수와 다를 수 있습니다.",
        "config": model.config.to_dict(),
        "modules": [{"name": name, "type": type(module).__name__, "parameters": sum(p.numel() for p in module.parameters(recurse=False)),
                     "lora": "lora_" in name or hasattr(module, "lora_A"),
                     "tensors": [{"name": key, "shape": list(parameter.shape), "dtype": str(parameter.dtype),
                                  "device": str(parameter.device), "trainable": parameter.requires_grad}
                                 for key, parameter in module.named_parameters(recurse=False)]}
                    for name, module in model.named_modules() if name]}
    structure["module_count_total"] = len(structure["modules"])
    structure["modules_truncated"] = False
    (folder / "runtime-structure.json").write_text(json.dumps(structure, ensure_ascii=False, indent=2), encoding="utf-8")
    return model, tokenizer, meta


def text_job(payload):
    import torch
    from transformers import TextIteratorStreamer, StoppingCriteria, StoppingCriteriaList
    root = Path(payload["root"])
    started = time.monotonic()
    model, tokenizer, meta = load_text(root, payload.get("adapter"))
    loaded_at = time.monotonic()
    inputs = tokenizer.apply_chat_template(payload["messages"], add_generation_prompt=True,
        enable_thinking=False, tokenize=True, return_dict=True, return_tensors="pt").to(model.device)
    count = inputs["input_ids"].shape[-1]
    budget = payload["max_new_tokens"]
    if count + budget > 2048:
        raise ValueError(f"Token budget exceeded ({count}+{budget}>2048). 질문/대화를 줄여 주세요.")
    cancel = Path(payload["cancel_path"])
    class Stop(StoppingCriteria):
        def __call__(self, *_args, **_kwargs):
            return cancel.exists() or time.monotonic() - started > 285
    streamer = TextIteratorStreamer(tokenizer, skip_prompt=True, skip_special_tokens=True, timeout=1)
    errors = []
    outputs = []
    def work():
        try:
            with torch.inference_mode():
                outputs.append(model.generate(**inputs, max_new_tokens=budget, do_sample=False,
                    streamer=streamer, stopping_criteria=StoppingCriteriaList([Stop()]),
                    pad_token_id=tokenizer.pad_token_id, eos_token_id=tokenizer.eos_token_id))
        except BaseException as exc:
            errors.append(exc)
            streamer.end()
    thread = threading.Thread(target=work)
    thread.start()
    import queue
    while True:
        try:
            delta = next(streamer)
        except queue.Empty:
            if not thread.is_alive():
                break
            continue
        except StopIteration:
            break
        if delta:
            emit("delta", text=delta)
    thread.join()
    if errors:
        raise errors[0]
    output = outputs[0][0][count:].tolist() if outputs else []
    reason = "cancelled" if cancel.exists() else "eos" if output and output[-1] == tokenizer.eos_token_id else "length_or_timeout"
    report = {"tier": "T2", "kind": "text", "timestamp": datetime.now(timezone.utc).isoformat(),
              "model_id": meta["model_id"], "revision": meta["revision"], "adapter": payload.get("adapter"),
              "input_tokens": count, "output_tokens": len(output), "finish_reason": reason,
              "elapsed_seconds": time.monotonic() - started,
              "model_load_seconds": loaded_at - started, "generation_seconds": time.monotonic() - loaded_at,
              "model_load_count": 1, "peak_vram_bytes": torch.cuda.max_memory_allocated(),
              "gpu": torch.cuda.get_device_name(0), "text": tokenizer.decode(output, skip_special_tokens=True)}
    (Path(payload["run_dir"]) / "result.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    emit("metadata", **report)


def main():
    try:
        payload = json.loads(sys.stdin.readline())
        if payload.get("kind") not in {"text", "speech", "speech_batch", "vision", "evaluation"}:
            raise ValueError("Unsupported worker type")
        with GPULease(Path(payload["root"]) / ".local", payload["job_id"]):
            if payload["kind"] == "text":
                text_job(payload)
            elif payload["kind"] == "evaluation":
                from edu_tutor.models.evaluate import evaluation_job
                evaluation_job(payload, emit)
            elif payload["kind"] == "speech":
                from edu_tutor.speech.provider import speech_job
                speech_job(payload, emit)
            elif payload["kind"] == "speech_batch":
                from edu_tutor.speech.provider import speech_batch_job
                speech_batch_job(payload, emit)
            else:
                from edu_tutor.models.vision_runtime import vision_job
                vision_job(payload, emit)
        emit("done")
    except Exception as exc:
        emit("error", message=f"{type(exc).__name__}: {exc}")
        sys.exit(1)


if __name__ == "__main__":
    main()
