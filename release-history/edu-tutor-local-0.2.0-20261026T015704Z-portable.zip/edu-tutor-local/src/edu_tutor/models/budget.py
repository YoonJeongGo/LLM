"""Persistent, conservative limits for the explicitly enabled phase-two run.

Reserve the full request duration before starting a process. An interrupted API
leaves that reservation charged; a restart cannot silently reset its budget.
"""
from __future__ import annotations

import json
import os
import shutil
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

from filelock import FileLock


class ResourceBudgetExceeded(RuntimeError):
    pass


def policy(root):
    path = Path(root) / ".local/phase2-policy.json"
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}


def status(root):
    root = Path(root)
    limits = policy(root)
    if not limits.get("enabled"):
        return {"enabled": False}
    path = root / "runs/phase2/current/resource-budget.json"
    with FileLock(str(root / ".local/phase2-budget.lock")):
        state = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {"requests": []}
    rows = state["requests"]
    used = sum(r["charged_seconds"] for r in rows)
    clips = sum(r["new_audio_clips"] for r in rows)
    photos = sum(r["vision_requests"] for r in rows)
    return {"enabled": True, "gpu_seconds_used": used, "gpu_seconds_remaining": max(0,limits["gpu_seconds"]-used),
            "new_audio_attempts":clips,"new_audio_remaining":max(0,limits["new_audio_clips"]-clips),
            "vision_attempts":photos,"vision_remaining":max(0,limits["vision_requests"]-photos),
            "requests":len(rows),"new_training_allowed":False,"new_model_download_allowed":False,
            "storage_estimate_bytes":state.get("storage_estimate_bytes",limits.get("conservative_total_bytes_at_start")),
            "storage_warning":state.get("storage_warning",False),"per_request_seconds":300,
            "accounting":"Model subprocess wall time including load, failed attempts included; unfinished reservations remain charged."}


def _save(path, value):
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(path)


def mutable_bytes(root):
    total = 0
    for part in ("runs", ".local"):
        for directory, dirs, files in os.walk(Path(root) / part, followlinks=False):
            dirs[:] = [d for d in dirs if not Path(directory, d).is_symlink() and not Path(directory, d).is_junction()]
            for name in files:
                try:
                    total += Path(directory, name).stat().st_size
                except FileNotFoundError:
                    continue
    return total


def reserve(root, payload, timeout):
    root = Path(root)
    limits = policy(root)
    if not limits.get("enabled"):
        return None, timeout
    path = root / "runs/phase2/current/resource-budget.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    with FileLock(str(root / ".local/phase2-budget.lock")):
        state = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {"requests": []}
        charged = sum(r.get("charged_seconds", 0) for r in state["requests"])
        duration = min(float(timeout), 300.0, limits["gpu_seconds"] - charged)
        if duration < 1:
            raise ResourceBudgetExceeded("이번 회차의 90분 모델 작업 예산을 모두 사용했습니다.")
        clips = len(payload.get("items", [])) if payload["kind"] == "speech_batch" else int(payload["kind"] == "speech")
        photos = int(payload["kind"] == "vision")
        if sum(r["new_audio_clips"] for r in state["requests"]) + clips > limits["new_audio_clips"]:
            raise ResourceBudgetExceeded("이번 회차의 새 음성 12개 제한에 도달했습니다.")
        if sum(r["vision_requests"] for r in state["requests"]) + photos > limits["vision_requests"]:
            raise ResourceBudgetExceeded("이번 회차의 사진 추론 4개 제한에 도달했습니다.")
        # On Windows C is the protected system volume. Tests use an injected
        # path so they do not depend on the host's available disk space.
        if shutil.disk_usage(limits.get("system_volume", "C:/")).free < limits["min_C_free_bytes"]:
            raise ResourceBudgetExceeded("C 드라이브 50GB 여유 공간 조건을 충족하지 못합니다.")
        if "fixed_storage_upper_bound_bytes" in limits:
            usage = limits["fixed_storage_upper_bound_bytes"] + mutable_bytes(root)
            # Keep room for at most four small PCM clips and runtime reports.
            if usage + 100_000_000 > limits["max_project_bytes"]:
                raise ResourceBudgetExceeded("프로젝트 귀속 50GB 저장공간 한도에 도달했습니다.")
            state["storage_estimate_bytes"] = usage
            state["storage_warning"] = usage >= limits["warning_project_bytes"]
        ident = uuid.uuid4().hex
        entry = {"id": ident, "kind": payload["kind"], "job_id": payload.get("job_id"),
                 "started_at": datetime.now(timezone.utc).isoformat(), "status": "reserved",
                 "charged_seconds": duration, "request_limit_seconds": duration,
                 "new_audio_clips": clips, "vision_requests": photos}
        state["requests"].append(entry)
        state["limits"] = limits
        state["accounting"] = "Parent subprocess wall time including model load; conservative GPU-work upper bound. Unfinished reservations remain fully charged. New clip attempts charged even if failed."
        _save(path, state)
    return (root, path, ident, time.monotonic()), duration


def finish(reservation, success):
    if reservation is None:
        return
    root, path, ident, started = reservation
    with FileLock(str(root / ".local/phase2-budget.lock")):
        state = json.loads(path.read_text(encoding="utf-8"))
        row = next(r for r in state["requests"] if r["id"] == ident)
        row.update(charged_seconds=time.monotonic() - started,
                   finished_at=datetime.now(timezone.utc).isoformat(),
                   status="completed" if success else "failed_or_cancelled")
        _save(path, state)
