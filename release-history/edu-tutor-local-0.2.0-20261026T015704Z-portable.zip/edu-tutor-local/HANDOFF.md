# v0.2 구현·제한 검증 완료 — 교육 NOT_READY

작업 위치는 `D:\LLM\edu-tutor-local`이다. 최종 결과는 `docs/PHASE2_ACCEPTANCE.md`, 모델 판단은 `docs/MODEL_DECISION.md`, 사람이 확인할 다섯 장면은 `docs/PHASE2_HUMAN_REVIEW.md`에 있다. 기존 v0.1 기록은 아래에 보존했다.

Python 전체254/254(102.74초, 경고2개), 웹 단위18/18, UI fixture16/16을 통과했다. 실제 모델·음성·내용 있는 칠판에서 두 번 질문하고 복귀하는 경로, 사진 수정 후 이전 결과 차단, 최종 저장 결과의 브라우저 재생을 확인했다. 마지막 UI 제품 해시는 `c8322cff55935a5b4c9c5b80699ea23621ceb6754b75e0131a0c08070e98ffcc`다.

실제 비교54문항·68모델 호출을 완료하고 원본 보고서를 보존했다. 새 진단의 질의6문항은 기반1/6, 기존 어댑터2/6이며 어댑터는 다른2문항에서 잘렸다. 공개18의 별도 형식 교정 재채점은 원시7/18, 당시 실제 앱은6/18 정답·12안전 중단이다. 도구 결과, 저장 응답 재채점, 모델 학습 효과를 섞지 않는다. 새12와 공개18은 결과를 활용한 수정 이후 development다.

실제 T01의 바꿔 말한 질문은 중복 열 오류를 한 번 수정시켜도 반복해 판서·음성을 차단했다. RAG를 붙여도 Oracle NVL 설명이 틀렸다. T03 원시 응답의3/1은 도구가3/0으로 계산했으며, 첫 수업10초 목표는 미달이다. 교육·청취 사람 검토는 미실시이고, 일반 교육 준비는 NOT_READY다. 테스트 수 증가를 정확도 향상으로 표현하지 않는다.

기본 Qwen3-1.7B를 유지하며 어댑터는 승격하지 않았다. 세 모델 파일의 해시와 기존 기록 보존을 확인했다. 신규 모델 다운로드, 기반모델/GPU 추가 학습, 외부 업로드, 저장소 이동은 하지 않았다. 전체 검사 안의 무작위 극소형 CPU LoRA 배선 검사는 별도다. `.local/phase2-policy.json`이 이번 회차의 다운로드·학습을 차단한다. 예산은2929.645/5400초, 새음성11/12시도, 사진4/4시도를 사용했다. 재개할 때 예산을 몰래 초기화하지 않는다. 유효한 기존 캐시를 검토할 수 있다.

최종 전체 소스 SHA256는 `8f4b756778c8da44d3fe111248aa1d929dae1797de5ac7c40fbac488177d5021`이다. 원래54개 비교의 소스는 `runs/phase2/current/source-before-format-fix.zip`에 보존했다. 구형256토큰 채점기, 원래 실패와 평가 보고서는 변경하지 않았다.

서버 주소는 `http://127.0.0.1:8000`이다. PID33100/도구 실행세션49177은 검증 당시 스냅샷이므로 재개 시 실제 명령줄·cwd·활성 작업을 확인한다. 실행 중이면 중복 서버를 띄우지 않는다. 종료됐다면 `powershell -ExecutionPolicy Bypass -File .\scripts\start.ps1`로 실행한다. 인증은 `.local/auth-token` 파일을 앱에서 불러오며 채팅·로그에 출력하지 않는다. 토큰·모델·개인DB·실행 증거는 소스ZIP에서 제외된다. 별도 새 폴더의 소스 부팅 검증은 `runs/phase2/current/release-verification.json`을 참고한다.

다음은 다섯 실제 장면의 사람 검토와, 그 결과에 따른 지원 범위 또는 새 소형 모델 비교 결정이다. 지금 모델을 다운로드하거나50-step 학습을 다시 실행하라는 지시가 아니다. 다음 독립 평가에 현재 공개 문항을 재사용하지 않는다.

---

# 현재 작업 상태

사용자 요청: 첨부 `edu_tutor_codex_pack.zip` 요구사항을 기반으로 실제 로컬 앱 구현. 모델 다운로드 및 제한 GPU 학습까지 명시 승인됨. 일시 중지 요청 뒤 사용자가 설치·작업 재개를 지시함.

위치: `D:\LLM\edu-tutor-local`. 기존 프로젝트가 없는 폴더에서 새로 작성; 원본 ZIP/명세 보존. Git commit/push/공개 배포 없음.

현재 구현: FastAPI/SQLite/API 인증, GPU lease, 작업/취소, 검색, SQL 격리 실행, React UI, 데이터 25/8/12, CPU/GPU 학습 runner, 텍스트/사진/음성 subprocess. Python 3.12.14, Torch 2.9.1+cu128, Transformers 4.57.3, PEFT 0.18.1, qwen-tts 0.1.1과 세 모델 설치 완료. 실제 모델 실행은 Windows RTX 3060 Ti에서 확인했다.

현재 상태는 **LOCAL_MVP_VERIFIED(로컬 기능 동작 범위)**, 교육 실사용 준비는 **NOT_READY**다. Python 전체 119개 통과(38.83초, exit0), 웹 단위 12/12·fixture UI 11/11·실제 API UI 4/4·실제 모델/TTS/S2 2/2·S3 1/1을 확인했다. T1 실제 CPU LoRA, T2 GPU smoke 5단계와 demo 50단계 및 별도 프로세스 재로딩은 완료했다. 데이터 45개 실제 토크나이저 마스킹, SQLite 정답 42/42를 검증했다. 모델 정답률과는 다르다. 상세 증거는 `docs/ACCEPTANCE.md`와 `STATUS.json`에 있다.

고정된 12문항 평가에서 SQL 정답은 기반 3/11, 어댑터 3/11이며 잘림은 0/12에서 2/12로 늘었다. 설명에 COUNT/NULL 오류가 실제 발견되었다. 어댑터는 승격하지 않았다. `runs/eval-comparison-v1/comparison.json`의 같은 조건 비교를 유지하고 점수를 높이려고 채점기를 바꾸지 않는다. 승인된 demo 50단계는 한 번 완료했으므로 반복하지 않는다.

실제 API 대화와 구조화 강의 생성은 작동했으나 통합 COUNT SQL은 존재하지 않는 열을 참조해 실행 실패했다. 강의는 `structured_unverified`다. 실제 TTS 총3개 WAV(7.84초/9.12초/13.84초)와 브라우저 재생·pause/resume·중간 질문·원강의 복귀를 확인했다. 실제 중단 시점 판서는 clear 이후 비어 있었고 비어 있지 않은 표 복원은 fixture 검사다. 사진3개에는 OCR 오류·구조화 표 추출 한계가 있다. 잘린 SQL 조건은 별도 형식 검사로 실제 풀이 API가 409 차단한다. 청취/교육 H는 미검토다.

S3 취소 시험은 추가 smoke 1회에서 2 optimizer step 뒤 멈췄다. 어댑터는 저장했지만 재로딩은 취소로 미실시이며 optimizer 이어하기는 미지원이다. S5는 실제 생성 중 서버 PID42360을 종료하고 PID37568로 재시작해 interrupted·기존 기록 보존·GPU 자식 종료·OS 잠금 재획득을 확인했다. 서버는 `http://127.0.0.1:8000`에서 실행 상태로 남겼다. PID는 당시 스냅샷이므로 나중에 동일 PID를 추측해 종료하지 않는다.

재개 시 먼저 STATUS.json, AGENTS.md, docs/DECISIONS.md와 보존한 참고 명세 `docs/source-pack/specs/00_EXECUTION_PLAN.md`를 읽고 현재 프로세스를 확인한다. 다른 프로세스를 종료하거나 이미 받은 모델을 다시 다운로드하지 않는다. 모델·실행 증거·개인 DB는 소스 ZIP에서 제외되며 현재 PC의 `.local/`·`runs/`에 보존한다.

필수 로컬 구현/통합 작업은 마쳤다. 다음 품질 작업은 실제 오답 원인 분석, 사람이 검토할 수정 데이터와 평가 기준 준비다. 사람 대신 검토를 완료했다고 기록하지 않는다. 50단계 학습을 자동 반복하거나 더 큰 모델을 자동 다운로드하지 않는다. 운영 학습·FP16·다른 OS·hardware OOM·전문가 교육/청취 검토는 미검증/미지원 범위를 유지한다.

마지막 전체 검사: `.\.venv\Scripts\python.exe -m pytest -q --basetemp=.local/pytest-final-20261026 --junitxml=runs/final-tests/junit.xml` (119 passed). 서버가 종료되어 있으면 `powershell -ExecutionPolicy Bypass -File .\scripts\start.ps1`로 실행한다. 소스 release는 `release/`의 ZIP 및 동일 이름 JSON 해시 목록이다.

재개 지시: “STATUS.json과 HANDOFF.md를 읽고 기존 로컬 기능을 보존하며 실제 오답부터 분석해라. 검증된 코드를 다시 만들거나 50단계 학습을 자동 반복하지 말고, 품질 개선안을 실행 증거와 함께 준비해라.”
