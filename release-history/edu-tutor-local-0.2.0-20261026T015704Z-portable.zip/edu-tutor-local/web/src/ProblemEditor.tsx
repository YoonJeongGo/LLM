export type ProblemDraft = {
  enabled: boolean;
  task_kind: "query_result" | "write_sql" | "concept" | "explain_error";
  dialect: "sqlite" | "oracle";
  tables: string;
  query: string;
  confirmed: boolean;
  revision: number;
};
export const emptyProblemDraft: ProblemDraft = {
  enabled: false,
  task_kind: "query_result",
  dialect: "sqlite",
  tables: "[]",
  query: "",
  confirmed: false,
  revision: 1,
};
export function typedProblem(draft: ProblemDraft, raw_text: string) {
  if (!draft.enabled) return undefined;
  if (!draft.confirmed)
    throw new Error("원본 표·SQL을 확인한 뒤 확정 표시를 선택하세요.");
  const tables = JSON.parse(draft.tables);
  if (!Array.isArray(tables) || tables.length > 5)
    throw new Error("표는 최대 5개의 JSON 배열로 입력하세요.");
  for (const table of tables) {
    if (
      typeof table.name !== "string" ||
      !Array.isArray(table.columns) ||
      !Array.isArray(table.rows) ||
      table.rows.some(
        (row: unknown) =>
          !Array.isArray(row) || row.length !== table.columns.length,
      )
    )
      throw new Error("표의 이름·columns·rows와 행 너비를 확인하세요.");
  }
  return {
    task_kind: draft.task_kind,
    dialect: draft.dialect,
    raw_text,
    source: { kind: "typed" },
    revision: draft.revision,
    confirmed: true,
    tables,
    query: draft.query || undefined,
    missing_conditions: [],
  };
}
export default function ProblemEditor({
  value,
  onChange,
}: {
  value: ProblemDraft;
  onChange: (draft: ProblemDraft) => void;
}) {
  const edit = (patch: Partial<ProblemDraft>) =>
    onChange({
      ...value,
      ...patch,
      confirmed: false,
      revision: value.revision + 1,
    });
  return (
    <details className="problem-editor">
      <summary>
        원본 표·SQL 입력{" "}
        <span>
          {value.enabled ? `사용 중 · revision ${value.revision}` : "선택 사항"}
        </span>
      </summary>
      <label className="inline-check">
        <input
          type="checkbox"
          checked={value.enabled}
          onChange={(event) => edit({ enabled: event.target.checked })}
        />{" "}
        이 질문에 원본 표·SQL을 함께 보냅니다
      </label>
      {value.enabled && (
        <>
          <div className="problem-selects">
            <label>
              문제 종류
              <select
                value={value.task_kind}
                onChange={(event) =>
                  edit({
                    task_kind: event.target.value as ProblemDraft["task_kind"],
                  })
                }
              >
                <option value="query_result">주어진 SQL 결과</option>
                <option value="write_sql">질문에 맞는 SQL 작성</option>
                <option value="concept">개념 설명</option>
                <option value="explain_error">원본 SQL 오류 설명</option>
              </select>
            </label>
            <label>
              DBMS
              <select
                value={value.dialect}
                onChange={(event) =>
                  edit({
                    dialect: event.target.value as ProblemDraft["dialect"],
                  })
                }
              >
                <option value="sqlite">SQLite</option>
                <option value="oracle">Oracle (실행 지원 범위 별도)</option>
              </select>
            </label>
          </div>
          <label>
            원본 SQL
            <textarea
              aria-label="문제의 원본 SQL"
              rows={3}
              value={value.query}
              onChange={(event) => edit({ query: event.target.value })}
              placeholder="문제에 SQL이 주어졌을 때 그대로 입력하세요."
            />
          </label>
          <label>
            원본 표 (JSON)
            <textarea
              aria-label="문제의 원본 표 JSON"
              rows={5}
              value={value.tables}
              onChange={(event) => edit({ tables: event.target.value })}
              spellCheck={false}
            />
          </label>
          <p className="fine-print">
            형식:
            [&#123;"name":"표이름","columns":[&#123;"name":"열이름","type":"INTEGER"&#125;],"rows":[[1],[null]]&#125;].
            자료형은 INTEGER·REAL·TEXT·NUMERIC입니다. NULL은 따옴표 없는 null로
            입력합니다.
          </p>
          <label className="inline-check">
            <input
              type="checkbox"
              checked={value.confirmed}
              onChange={(event) =>
                onChange({ ...value, confirmed: event.target.checked })
              }
            />{" "}
            원문과 비교해 표·값·SQL을 확인했습니다
          </label>
          <p className="fine-print">
            원문 수정은 새 revision입니다. 일반 개념 질문은 이 입력 없이도 할 수
            있습니다.
          </p>
        </>
      )}
    </details>
  );
}
