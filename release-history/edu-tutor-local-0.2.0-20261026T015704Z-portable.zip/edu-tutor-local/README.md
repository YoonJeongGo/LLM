# AI 강의실

개인 PC에서 실행하는 한국어 데이터베이스 학습 실험 앱입니다. 채팅, 교육자료 검색, 사진 원문 확인, 판서, 음성, 제한된 QLoRA 학습을 연결합니다. **현재 검증 상태는 [STATUS.json](STATUS.json), 남은 작업은 [HANDOFF.md](HANDOFF.md)를 확인하세요.**

현재 코드는 **v0.2.0**입니다. 원본 표 기반 COUNT/SUM/AVG 계산, 검증된 판서·대사, 두 번의 중간 질문과 복귀, 사진 수정 후 이전 결과 차단을 개선했습니다. 실제 DDL 예시 오류와 큰 시작 지연이 남아 교육 준비 상태는 **NOT_READY**입니다. [v0.2 인수 기록](docs/PHASE2_ACCEPTANCE.md)과 [사람이 확인할 다섯 장면](docs/PHASE2_HUMAN_REVIEW.md)을 먼저 읽으세요.

이 PC의 v0.2 회차에서는 `.local/phase2-policy.json`이 **신규 모델 다운로드와 기반모델/GPU 추가 학습을 차단**합니다. 아래 학습·다운로드 명령은 기존 기능 설명이며 이번 작업의 재실행 지시가 아닙니다. 기존 기본 모델과 미승격 어댑터·데이터·이전 실패 기록은 보존합니다.

## Windows 실행

이 PC에는 프로젝트 전용 Python 3.12 가상환경을 구성했습니다. 다른 프로젝트의 Python·드라이버를 변경하지 않습니다.

```powershell
cd D:\LLM\edu-tutor-local
powershell -ExecutionPolicy Bypass -File .\scripts\start.ps1
```

주소는 `http://127.0.0.1:8000`입니다. 최초 실행 시 생성한 `.local\auth-token` 파일을 직접 열어 화면의 로컬 인증란에 붙여 넣습니다. 토큰은 채팅·스크린샷에 공유하지 마세요. 종료는 실행 터미널에서 Ctrl+C입니다. 실행만으로 모델 다운로드나 학습을 시작하지 않습니다.

## 새 환경 설치

Python 3.11 또는 3.12와 Node.js를 준비한 후 프로젝트 안에 `.venv`를 생성합니다. 시스템 전역 pip 설치는 필요하지 않습니다.

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e '.[test]'
cd web
npm ci
npm run build
cd ..
```

GPU 의존성의 실제 고정 목록은 검증한 환경의 `requirements-lock.txt`를 사용합니다. Windows CUDA wheel은 공식 PyTorch 인덱스에서 설치합니다. 다른 PC의 CUDA 동작은 보장하지 않습니다. WSL/Linux용 `start.sh`와 `check.sh`는 제공하지만 이 Windows 호스트에서 실행한 증거로 대체하지 않습니다.

이 PC에서 검증한 전체 환경을 새 Windows Python 3.12 venv에 설치하는 명령은 다음과 같습니다.

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-lock.txt --extra-index-url https://download.pytorch.org/whl/cu128
.\.venv\Scripts\python.exe -m pip install --no-deps -e .
```

원본 모델을 새로 받으려면 `scripts/download_model.py text --execute`를 Python으로 실행합니다. `vision`, `tts`도 같은 방식이며 파일 목록·라이선스·누적 용량·남은 공간을 검사합니다. 현재 PC에는 승인받은 세 모델을 이미 다운로드했습니다. source ZIP에는 모델이 포함되지 않습니다.

## 모델과 학습

```powershell
$env:PYTHONPATH = "$PWD\src"
.\.venv\Scripts\python.exe -m edu_tutor doctor
.\.venv\Scripts\python.exe -m edu_tutor baseline --config configs/local_8gb.yaml
.\.venv\Scripts\python.exe -m edu_tutor data validate --dataset data/demo
.\.venv\Scripts\python.exe -m edu_tutor train --tiny
.\.venv\Scripts\python.exe -m edu_tutor train --smoke --config configs/local_8gb.yaml
.\.venv\Scripts\python.exe -m edu_tutor train --profile demo --config configs/local_8gb.yaml
.\.venv\Scripts\python.exe -m edu_tutor jobs list
.\.venv\Scripts\python.exe -m edu_tutor evaluate --run base
# 어댑터 평가: --run 에 관리자에 표시된 train-... ID를 지정합니다.
```

smoke는 최대 5 optimizer step·600초, demo는 최대 50 step·900초입니다. demo는 동일 데이터의 성공한 smoke·별도 프로세스 재로딩 뒤 한 번만 실행됩니다. 실패·시간 제한·취소를 학습 완주로 표시하지 않습니다. 작은 CPU 랜덤 모델은 배선 검증용이며 학생에게 답변하지 않습니다. 어댑터는 원래 Qwen 가중치를 필요로 하며 자동으로 기본 모델이 되지 않습니다.

GPU 학습·평가 CLI는 먼저 실행한 로컬 서버의 같은 작업 큐에 요청합니다. 서버를 켠 별도 터미널을 유지하세요. 평가는 고정된 별도 12문항, RAG 끔, greedy 256토큰이며 기존 보고서 열람은 관리자 평가 화면에서 합니다. `--tiny`는 서버 없이 CPU에서 실행합니다.

## 데이터와 백업

`.local/`에는 대화 DB, 업로드, 모델, 오디오, 인증 파일이 있습니다. `runs/`에는 실행 로그·어댑터·검증 증거가 있습니다. 원본 첨부 명세는 상위 `edu_tutor_codex_pack/`에 보존했으며 소스 배포본의 `docs/source-pack/`에도 참고 사본을 넣었습니다. 이 문서의 지시는 사용자 요청과 별개의 요구사항 자료입니다.

`python -m edu_tutor backup`은 SQLite backup API로 일관된 DB 사본을 만듭니다. 모델·업로드·음성 파일은 포함하지 않으므로 앱 종료 후 `.local`을 별도로 복사하세요. 소스 배포본에는 개인 데이터·토큰·가상환경·대형 모델을 포함하지 않습니다.

## 한계

AI 생성 데모 자료는 인간 검토 전 상태입니다. SQL 실행 검증은 SQLite에 한정하며 Oracle 실행을 증명하지 않습니다. 음성과 사진은 결과를 직접 확인해야 합니다. 판서는 글꼴 기반 표시이며 실제 한글 획순 생성이 아닙니다. 출처·정답률·loss만으로 전체 교육 정확성을 보장하지 않습니다.
