$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $taskRoot
$taskPython = Join-Path $taskRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $taskPython)) { throw '프로젝트 .venv가 없습니다. README 설치 절차를 먼저 실행하세요.' }
$env:PYTHONPATH = Join-Path $taskRoot 'src'
$env:PYTHONUTF8 = '0'
$env:PYTHONIOENCODING = 'utf-8'
$env:HF_HUB_DISABLE_TELEMETRY = '1'
& $taskPython -m edu_tutor doctor --output (Join-Path $taskRoot 'runs\environment\startup-doctor.json')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $taskPython -m edu_tutor serve
exit $LASTEXITCODE
