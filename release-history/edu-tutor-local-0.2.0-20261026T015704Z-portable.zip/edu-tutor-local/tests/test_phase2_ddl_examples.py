"""A real, tiny SQLite run; these are fixture defenses, not model inference."""
from pathlib import Path

import pytest

from edu_tutor.problems.ddl_examples import build_ddl_example


def example(sql):
    return build_ddl_example('모델이 쓴 설명용 예시\n```sql\n'+sql+'\n```')


def test_create_insert_alter_drop_share_actual_before_after_cells():
    result=example("CREATE TABLE learners (name TEXT, score INTEGER);\n"
        "INSERT INTO learners VALUES ('Kim',80),('Yu',NULL);\n"
        "ALTER TABLE learners ADD COLUMN phone TEXT;\nDROP TABLE learners;")
    assert result['status']=='verified'
    create,insert,alter,drop=result['steps']
    assert create['before']==[] and create['after'][0]['rows']==[]
    assert insert['after'][0]['rows']==[['Kim',80],['Yu',None]]
    assert insert['effects']['columns_before']==insert['effects']['columns_after']==2
    assert alter['effects']['rows_before']==alter['effects']['rows_after']==2
    assert alter['after'][0]['rows']==[['Kim',80,None],['Yu',None,None]]
    assert alter['after'][0]['columns']==['name','score','phone']
    assert alter['before'][0]['id']==alter['after'][0]['id']
    assert alter['before'][0]['row_ids']==alter['after'][0]['row_ids']
    assert alter['before'][0]['cell_ids'][0]==alter['after'][0]['cell_ids'][0][:2]
    assert drop['after']==[] and drop['effects']['table_count_before']==1
    assert all(step['label']=='설명용 새 예시' for step in result['steps'])
    assert result['free_prose_verification']=='not_verified' and result['human_review']=='not_reviewed'


def test_insert_explicit_columns_quoted_literals_and_negative_numbers():
    result=example("CREATE TABLE people (name TEXT, score REAL); INSERT INTO people (score,name) VALUES (-2.5,'O''Brien');")
    assert result['status']=='verified'
    assert result['steps'][-1]['after'][0]['rows']==[["O'Brien",-2.5]]


@pytest.mark.parametrize('unsafe',[
    "ATTACH DATABASE 'escape.sqlite3' AS external;",
    "PRAGMA writable_schema=ON;",
    "SELECT load_extension('evil');",
    "CREATE TABLE x AS SELECT 1;",
    "CREATE VIRTUAL TABLE x USING fts5(text);",
    "CREATE TABLE x (v TEXT DEFAULT (randomblob(1000000000)));",
    "CREATE TABLE x (v TEXT); INSERT INTO x VALUES (readfile('secret.txt'));",
    "CREATE TABLE x (v TEXT); INSERT INTO x SELECT 'unsafe';",
    "CREATE TABLE main.x (v TEXT);",
    "CREATE TABLE x (v TEXT); ALTER TABLE x RENAME TO y;",
    "CREATE TABLE sqlite_secret (v TEXT);",
    "CREATE TABLE x (v TEXT); DELETE FROM x;",
    "CREATE TABLE x (v TEXT); INSERT INTO x VALUES ('ok'); DROP TABLE x; SELECT * FROM sqlite_master;",
])
def test_unsupported_or_malicious_sql_is_rejected_before_any_execution(unsafe):
    result=example(unsafe)
    assert result['status']=='blocked'
    assert result['steps']==[]
    assert result['partial_steps_audit_only']==[]


def test_literal_that_looks_like_sql_remains_data(tmp_path, monkeypatch):
    target=tmp_path/'should-not-exist.sqlite3'
    monkeypatch.chdir(tmp_path)
    payload="'); ATTACH DATABASE 'should-not-exist.sqlite3' AS stolen; --"
    literal="'"+payload.replace("'","''")+"'"
    result=example('CREATE TABLE notes (body TEXT); INSERT INTO notes VALUES ('+literal+');')
    assert result['status']=='verified'
    assert result['steps'][-1]['after'][0]['rows']==[[payload]]
    assert not target.exists()


def test_no_model_sql_never_invents_a_verified_example():
    result=build_ddl_example('DDL은 구조를 바꾸는 명령입니다. INSERT는 행을 추가합니다.')
    assert result['status']=='not_available' and result['steps']==[]
    assert result['execution']['status']=='not_run'


def test_failed_statement_does_not_publish_partial_teaching_plan():
    result=example('CREATE TABLE x (v INTEGER); INSERT INTO absent VALUES (1);')
    assert result['status']=='blocked' and result['steps']==[]
    assert len(result['partial_steps_audit_only'])==1


def test_cumulative_rows_columns_and_statement_caps():
    rows=','.join('('+str(i)+')' for i in range(20))
    assert example('CREATE TABLE x (v INTEGER); INSERT INTO x VALUES '+rows+'; INSERT INTO x VALUES (21);')['status']=='blocked'
    columns=','.join('v'+str(i)+' TEXT' for i in range(8))
    assert example('CREATE TABLE x ('+columns+'); ALTER TABLE x ADD COLUMN excess TEXT;')['status']=='blocked'
    assert example(';'.join('CREATE TABLE x'+str(i)+'(v TEXT)' for i in range(9)))['status']=='blocked'


def test_multiple_sql_blocks_are_one_ordered_example():
    raw='```sql\nCREATE TABLE x (v INTEGER);\n```\n행을 추가합니다.\n```sql\nINSERT INTO x VALUES (7);\n```'
    result=build_ddl_example(raw)
    assert result['status']=='verified' and result['steps'][-1]['after'][0]['rows']==[[7]]


def test_bare_fence_example_is_executed_and_mixed_fences_keep_order():
    raw="설명용 새 예시\n```\nCREATE TABLE people (name TEXT);\n```\n행 추가\n```sql\nINSERT INTO people VALUES ('Alice');\n```\n열 추가\n```\nALTER TABLE people ADD COLUMN score INTEGER;\n```"
    result=build_ddl_example(raw)
    assert result['status']=='verified' and len(result['source_sql_blocks'])==3
    assert [s['operation'] for s in result['steps']]==['create_table','insert_rows','add_column']
    assert result['steps'][-1]['after'][0]['rows']==[['Alice',None]]


@pytest.mark.parametrize('raw',[
    "```\nCREATE TABLE x (v INTEGER;\n```",
    "```\nCREATE TABLE x (v INTEGER); ATTACH DATABASE 'escape.sqlite3' AS external;\n```",
    "```\nCREATE TABLE x (v INTEGER);",
])
def test_malformed_or_unsafe_bare_sql_fence_is_blocked_not_missing(raw):
    result=build_ddl_example(raw)
    assert result['status']=='blocked' and result['steps']==[]
    assert result['partial_steps_audit_only']==[]


def test_non_sql_bare_code_is_not_invented_as_an_example():
    assert build_ddl_example('```\n행을 추가하는 의사 코드\n```')['status']=='not_available'
