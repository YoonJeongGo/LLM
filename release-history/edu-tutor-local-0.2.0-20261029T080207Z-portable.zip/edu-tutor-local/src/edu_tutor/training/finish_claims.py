"""Flag explicit machine-readable result claims; never approve all prose."""
import json
import re

from edu_tutor.evaluation.sql_sandbox import compare_results
from edu_tutor.problems.sql_response import _JSON_FENCE

PROTOCOL = 'saved_explicit_result_array_claims_v1'


def check_explicit_result_claim(item):
    value = {'id': item['id'], 'protocol': PROTOCOL, 'claims': [],
             'full_explanation_quality': 'H_PENDING', 'human_review': 'H_PENDING',
             'new_model_calls': 0, 'explicit_numeric_mismatch': False}
    raw = item.get('actual_answer') or ''
    match = _JSON_FENCE.fullmatch(raw)
    try:
        parsed = json.loads(match.group(1) if match else raw)
    except ValueError:
        return {**value, 'status': 'structured_explanation_unavailable'}
    explanation = parsed.get('explanation') if isinstance(parsed, dict) else None
    actual = item.get('actual') or {}
    if not isinstance(explanation, str) or actual.get('status') != 'executed':
        return {**value, 'status': 'structured_explanation_or_executed_sql_unavailable'}
    for found in re.finditer(r'결과\s*(\[)', explanation):
        fragment = explanation[found.start(1):]
        try:
            rows, length = json.JSONDecoder().raw_decode(fragment)
            if not isinstance(rows, list) or any(not isinstance(row, list) for row in rows):
                raise ValueError('Expected an explicit array of result rows')
        except ValueError as exc:
            value['claims'].append({'status': 'not_machine_readable', 'fragment': fragment, 'reason': str(exc), 'matches_sql_execution': None})
            continue
        comparison = {'columns': actual['columns'], 'rows': rows,
                      'row_order': 'ordered' if re.search(r'\bORDER\s+BY\b', item.get('sql', ''), re.I) else 'unordered',
                      'numeric_abs_tolerance': 1e-9}
        matches = compare_results(actual, comparison)
        value['claims'].append({'status': 'checked_against_candidate_sql_execution',
            'fragment': fragment[:length], 'claimed_rows': rows, 'actual_rows': actual['rows'],
            'matches_sql_execution': matches})
    mismatch = any(c['matches_sql_execution'] is False for c in value['claims'])
    return {**value, 'status': 'explicit_result_claim_mismatch' if mismatch else 'no_mismatch_found_in_parseable_claims',
            'explicit_numeric_mismatch': mismatch,
            'notice': 'This flags contradictions between a candidate SQL result and explicit numeric prose. Absence of a parseable contradiction is not an explanation, intent, educational or human pass.'}
