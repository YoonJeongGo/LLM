"""SQLite execution and explicitly bounded intent/calculation evidence.

No reference answers or question IDs are consulted. Tables supplied by the user
are the only numerical inputs. SQL execution is not an intent verdict.
"""
from __future__ import annotations

import copy
import hashlib
import re

import sqlglot
from sqlglot import exp

from edu_tutor.evaluation.sql_sandbox import execute_sql, compare_results
from .sql_response import extract_sql_candidate, SQL_EXTRACTION_PROTOCOL
from .models import canonical, identified_table, derive_hypothesis, infer_basic_intent


def quote(name):
    if not re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]{0,63}", name):
        raise ValueError("지원하지 않는 식별자입니다.")
    return '"' + name + '"'


def fixture(problem):
    return {"tables": [{"name": t["name"], "columns": [{"name": c["name"], "type": c["type"]} for c in t["columns"]],
                        "rows": t["rows"]} for t in problem["tables"]]}


def aggregate_spec(expression):
    value = expression.this if isinstance(expression, exp.Alias) else expression
    if not isinstance(value, (exp.Count, exp.Sum, exp.Avg, exp.Min, exp.Max)):
        return None
    operand = value.this
    distinct = isinstance(operand, exp.Distinct)
    if distinct:
        if len(operand.expressions) != 1:
            return None
        operand = operand.expressions[0]
    while isinstance(operand, exp.Paren):
        operand = operand.this
    # Only this SQLite predicate has a proved, row-local 0/1 interpretation.
    # Preserve SUM as SUM: on empty input it is NULL, not COUNT's zero.
    if (isinstance(value, exp.Sum) and not distinct and isinstance(operand, exp.Not)
            and isinstance(operand.this, exp.Is) and isinstance(operand.this.this, exp.Column)
            and isinstance(operand.this.expression, exp.Null)):
        column = operand.this.this.name
        return {"function": "sum", "column": column, "distinct": False,
                "input_transform": "is_not_null_indicator", "input_expression": column + " IS NOT NULL"}
    column = "*" if isinstance(operand, exp.Star) else operand.name if isinstance(operand, exp.Column) else None
    if column is None or column == "*" and not isinstance(value, exp.Count):
        return None
    return {"function": type(value).__name__.lower(), "column": column, "distinct": distinct}


def bounded_query(sql, problem):
    if problem.get("dialect", "sqlite") != "sqlite":
        raise ValueError("이 계산 근거는 SQLite에서만 검증합니다.")
    statements = sqlglot.parse(sql, read="sqlite")
    if len(statements) != 1 or not isinstance(statements[0], exp.Select):
        raise ValueError("논리 단계 계산 범위는 단일 SELECT입니다.")
    query = statements[0]
    if any(query.args.get(key) for key in ("with_", "joins", "limit", "offset", "distinct")) or any(query.find_all(exp.Subquery)):
        raise ValueError("이 계산 설명은 단일 표의 집계만 지원합니다. JOIN/CTE/중첩 질의는 실행 결과만 표시합니다.")
    temporal_functions={"date","time","datetime","julianday","strftime","time_to_str","ts_or_ds_to_timestamp",
                        "current_date","current_time","current_timestamp"}
    if any((function.name if isinstance(function,exp.Anonymous) else function.sql_name()).casefold() in temporal_functions
           for function in query.find_all(exp.Func)):
        raise ValueError("시간·날짜 함수가 있는 조건은 반복 실행 사이 같은 입력임을 보장할 수 없어 행·그룹 이유를 추적하지 않습니다.")
    source = query.args.get("from_")
    if not source or not isinstance(source.this, exp.Table):
        raise ValueError("원본 표를 확인할 수 없습니다.")
    table = next((t for t in problem["tables"] if t["name"].casefold() == source.this.name.casefold()), None)
    if table is None:
        raise ValueError("SQL이 원본에 없는 표를 참조합니다.")
    group = query.args.get("group")
    groups = list(group.expressions) if group else []
    if any(not isinstance(item, exp.Column) for item in groups):
        raise ValueError("그룹 식은 원본 열 이름만 지원합니다.")
    group_names = [item.name for item in groups]
    specs = []
    for item in query.expressions:
        spec = aggregate_spec(item)
        if spec:
            specs.append(spec)
        elif not isinstance(item, exp.Column) or item.name not in group_names:
            raise ValueError("집계 설명 범위는 그룹 열 및 COUNT/SUM/AVG와 숫자 열의 MIN/MAX입니다.")
    if not specs:
        raise ValueError("COUNT/SUM/AVG/MIN/MAX 계산을 찾지 못했습니다.")
    return query, table, specs, group_names


def normalized_clause(clause):
    if clause is None:
        return ""
    value = clause.copy()
    for column in value.find_all(exp.Column):
        column.set("table", None)
    for ident in value.find_all(exp.Identifier):
        ident.set("this", ident.name.casefold())
    return value.sql(dialect="sqlite", normalize=True)


def intent_sql(intent):
    columns = [quote(name) for name in intent.get("group_by", [])]
    for i, item in enumerate(intent["aggregates"]):
        function = item["function"].upper()
        if function not in {"COUNT", "SUM", "AVG", "MIN", "MAX"}:
            raise ValueError("지원하지 않는 집계 연산입니다.")
        operand = "*" if item["column"] == "*" else quote(item["column"])
        if item.get("distinct"):
            operand = "DISTINCT " + operand
        columns.append(f"{function}({operand}) AS result_{i + 1}")
    sql = "SELECT " + ", ".join(columns) + " FROM " + quote(intent["table"])
    for key, keyword in (("where", " WHERE "), ("group_by", " GROUP BY "), ("having", " HAVING ")):
        value = intent.get(key)
        if value:
            sql += keyword + (", ".join(quote(x) for x in value) if key == "group_by" else value)
    return sql


def check_intent(sql, problem, question):
    intent, scope = infer_basic_intent(problem, question)
    if not intent:
        return {"status": "unsupported", "scope": scope}, None
    try:
        candidate, table, specs, groups = bounded_query(sql, problem)
        expected, expected_table, expected_specs, expected_groups = bounded_query(intent_sql(intent), problem)
        def spec_key(items):
            return [(s["function"], s["column"].casefold(), bool(s["distinct"]), s.get("input_transform")) for s in items]
        candidate_keys = spec_key(specs)
        expected_keys = spec_key(expected_specs)
        equivalence = []
        if scope == "bounded_language_group_average":
            if candidate.args.get("order"):
                raise ValueError("그룹 평균의 정렬 검증은 지원하지 않습니다. 모델이 추가한 ORDER BY도 자동 수용하지 않습니다.")
            projected_groups = [item.name.casefold() for item in candidate.expressions if isinstance(item, exp.Column)]
            if projected_groups != [name.casefold() for name in expected_groups] or len(candidate.expressions) != 2:
                raise ValueError("각 평균을 구분할 원본 그룹 열이 SELECT 결과에 정확히 한 번 포함되어야 합니다.")
        compared_where = candidate.args.get("where")
        # COUNT(DISTINCT c) already excludes NULL. Removing only this same-column
        # predicate changes neither count nor empty-input behavior. Grouped
        # queries are excluded: the filter could erase all-NULL groups.
        if (len(specs) == len(expected_specs) == 1 and candidate_keys == expected_keys
                and specs[0]["function"] == "count" and specs[0]["distinct"]
                and specs[0]["column"] != "*" and not groups and not expected_groups
                and expected.args.get("where") is None and candidate.args.get("having") is None
                and expected.args.get("having") is None and compared_where is not None):
            predicate = compared_where.this
            if (isinstance(predicate, exp.Not) and isinstance(predicate.this, exp.Is)
                    and isinstance(predicate.this.this, exp.Column) and isinstance(predicate.this.expression, exp.Null)
                    and predicate.this.this.name.casefold() == specs[0]["column"].casefold()):
                equivalence.append({"kind": "count_distinct_same_column_nonnull_filter",
                    "column": specs[0]["column"], "status": "all_inputs_match_including_empty",
                    "scope": "단일 COUNT DISTINCT의 동일 열 IS NOT NULL만; 그룹·다른 조건은 동치 처리하지 않음"})
                compared_where = None
        if len(specs) == len(expected_specs):
            for index, (given, requested) in enumerate(zip(specs, expected_specs)):
                if (given.get("input_transform") == "is_not_null_indicator"
                        and requested["function"] == "count" and not requested["distinct"]
                        and given["column"].casefold() == requested["column"].casefold()
                        and not groups and not expected_groups):
                    trace = "SELECT COUNT(*) AS input_rows FROM " + candidate.args["from_"].this.sql(dialect="sqlite")
                    if candidate.args.get("where"):
                        trace += " " + candidate.args["where"].sql(dialect="sqlite")
                    input_size = execute_sql(trace, fixture(problem))
                    if input_size["status"] != "executed":
                        raise ValueError("조건식 집계의 입력 행 수를 안전하게 확인하지 못했습니다.")
                    count = input_size["rows"][0][0]
                    equivalence.append({"column": given["column"], "candidate_expression": "SUM(" + given["input_expression"] + ")",
                        "requested_expression": "COUNT(" + requested["column"] + ")", "input_row_count": count,
                        "status": "nonempty_input_match" if count else "empty_input_mismatch",
                        "scope": "현재 확정한 입력과 조건에서만 비교; SUM 원문을 COUNT로 바꾸지 않음",
                        "empty_input": {"sum_is_not_null": None, "count_column": 0}})
                    if count:
                        candidate_keys[index] = expected_keys[index]
        same = (table["name"].casefold() == expected_table["name"].casefold()
                and candidate_keys == expected_keys
                and [x.casefold() for x in groups] == [x.casefold() for x in expected_groups]
                and normalized_clause(compared_where) == normalized_clause(expected.args.get("where"))
                and normalized_clause(candidate.args.get("having")) == normalized_clause(expected.args.get("having")))
        return {"status": "supported_match" if same else "mismatch", "scope": scope,
                "requested": intent, "candidate_aggregates": specs,
                "input_bound_equivalence": equivalence,
                "reason": "확인된 기본 집계·조건·그룹 구조가 질문의 의도와 일치합니다." if same else
                    "빈 입력의 SUM(열 IS NOT NULL)은 NULL이며 요청한 COUNT(열)의 0과 다릅니다." if any(e["status"] == "empty_input_mismatch" for e in equivalence) else
                    "실행 가능 여부와 별개로 집계 대상·NULL 처리·조건·그룹 중 요청과 다른 부분이 있습니다."}, intent
    except (ValueError, sqlglot.errors.ParseError) as exc:
        return {"status": "unsupported", "scope": scope, "reason": str(exc)}, intent


def logical_evidence(sql, problem, namespace, final_result=None):
    query, table, specs, group_names = bounded_query(sql, problem)
    display = identified_table(problem, table, namespace=namespace)
    names = [c["name"] for c in table["columns"]]
    lookup = {name.casefold(): i for i, name in enumerate(names)}
    if any(s["column"] != "*" and s["column"].casefold() not in lookup for s in specs):
        raise ValueError("집계 열이 원본에 없습니다.")
    source = query.args["from_"].this
    rowid = next((name for name in ("_rowid_", "rowid", "oid") if name.casefold() not in lookup), None)
    if rowid is None:
        raise ValueError("안정적인 행 추적에 필요한 내부 식별자가 모두 가려져 있습니다.")
    qualifier = quote(source.alias_or_name)
    trace = "SELECT " + qualifier + "." + rowid + " - 1 AS row_index FROM " + source.sql(dialect="sqlite")
    if query.args.get("where"):
        trace += " " + query.args["where"].sql(dialect="sqlite")
    filtered = execute_sql(trace, fixture(problem))
    if filtered["status"] != "executed":
        raise ValueError("WHERE 행 추적 실패: " + filtered.get("error", ""))
    indices = [int(row[0]) for row in filtered["rows"]]
    indicator_checks = {}
    for spec in specs:
        if spec.get("input_transform") != "is_not_null_indicator" or spec["column"].casefold() in indicator_checks:
            continue
        column = names[lookup[spec["column"].casefold()]]
        indicator_sql = "SELECT " + qualifier + "." + rowid + " - 1 AS row_index, " + qualifier + "." + quote(column) + " IS NOT NULL AS indicator FROM " + source.sql(dialect="sqlite")
        if query.args.get("where"):
            indicator_sql += " " + query.args["where"].sql(dialect="sqlite")
        actual_inputs = execute_sql(indicator_sql, fixture(problem))
        expected_inputs = [[index, int(table["rows"][index][lookup[column.casefold()]] is not None)] for index in indices]
        if not compare_results(actual_inputs, {"columns": ["row_index", "indicator"], "rows": expected_inputs,
                "row_order": "unordered", "numeric_abs_tolerance": 0}):
            raise ValueError("독립 1/0 조건값과 SQLite 행별 조건 계산이 일치하지 않습니다.")
        indicator_checks[column.casefold()] = {"status": "sqlite_indicator_match", "sql": indicator_sql,
                                               "rows": expected_inputs}
    groups = {}
    for index in indices:
        row = table["rows"][index]
        key = tuple(row[lookup[name.casefold()]] for name in group_names)
        groups.setdefault(key, []).append(index)
    if not group_names and not groups:
        groups[()] = []
    aggregates, computed_rows = [], []
    for number, (key, members) in enumerate(groups.items()):
        group_id = display["id"] + "-group-" + hashlib.sha256(canonical(key).encode()).hexdigest()[:10]
        results = []
        for position, spec in enumerate(specs):
            column = spec["column"]
            col = None if column == "*" else lookup[column.casefold()]
            indicator = spec.get("input_transform") == "is_not_null_indicator"
            included = members if col is None or indicator else [i for i in members if table["rows"][i][col] is not None]
            values = [int(table["rows"][i][col] is not None) if indicator else 1 if col is None else table["rows"][i][col] for i in included]
            if spec["distinct"]:
                unique = []
                seen = []
                for index, value in zip(included, values):
                    if value not in seen:
                        seen.append(value)
                        unique.append(index)
                included, values = unique, seen
            count = len(values)
            if spec["function"] in {"sum", "avg"} and any(not isinstance(v, (int, float)) for v in values):
                raise ValueError("SUM/AVG 중간 계산은 숫자 열만 지원합니다.")
            if spec["function"] in {"min", "max"} and (table["columns"][col]["type"] not in {"INTEGER", "REAL", "NUMERIC"}
                    or any(type(v) not in {int, float} for v in values)):
                raise ValueError("MIN/MAX 중간 계산은 숫자 열만 지원합니다. 문자열·혼합 자료형의 SQLite 정렬 규칙은 이 설명 범위에 포함하지 않습니다.")
            total = sum(values) if values and spec["function"] in {"sum", "avg"} else None
            if spec["function"] == "count":
                value = count
            elif spec["function"] == "sum":
                value = total
            elif spec["function"] == "avg":
                value = total / count if count else None
            else:
                value = (min(values) if spec["function"] == "min" else max(values)) if values else None
            results.append(value)
            aggregate = {"id": f"{group_id}-aggregate-{position}", "group_id": group_id, "group_values": list(key),
                **spec, "included_values": values, "count": count, "sum": total, "result": value,
                "included_row_ids": [display["row_ids"][i] for i in included],
                "included_cell_ids": [] if col is None else [display["cell_ids"][i][col] for i in included],
                "excluded_null_cell_ids": [] if col is None or indicator else [display["cell_ids"][i][col] for i in members if table["rows"][i][col] is None]}
            if indicator:
                aggregate["input_rows"] = [{"row_id": display["row_ids"][i], "cell_id": display["cell_ids"][i][col],
                    "source_value": table["rows"][i][col], "value": int(table["rows"][i][col] is not None)} for i in members]
                aggregate["input_trace_check"] = indicator_checks[column.casefold()]
            aggregates.append(aggregate)
        row, aggregate_index = [], 0
        for item in query.expressions:
            if aggregate_spec(item):
                row.append(results[aggregate_index]); aggregate_index += 1
            else:
                row.append(key[group_names.index(item.name)])
        computed_rows.append(row)
    unfiltered = query.copy()
    unfiltered.set("having", None)
    unfiltered.set("order", None)
    intermediate = execute_sql(unfiltered.sql(dialect="sqlite"), fixture(problem))
    expected = {"columns": intermediate.get("columns", []), "rows": computed_rows, "row_order": "unordered", "numeric_abs_tolerance": 1e-8}
    if not compare_results(intermediate, expected):
        raise ValueError("독립 집계 계산과 SQLite 중간 결과가 일치하지 않습니다.")
    # Preserve the original projection and HAVING aliases while adding group
    # keys for provenance. Matching only displayed result values is ambiguous
    # when two different groups have the same aggregate result.
    survival_query = query.copy()
    survival_query.set("order", None)
    group_expressions = query.args["group"].expressions if group_names else [exp.Literal.number(1)]
    survival_query.set("expressions", [item.copy() for item in query.expressions] + [
        exp.alias_(item.copy(), f"__teaching_group_{i}") for i, item in enumerate(group_expressions)])
    survival = execute_sql(survival_query.sql(dialect="sqlite"), fixture(problem))
    if survival["status"] != "executed":
        raise ValueError("HAVING 그룹 추적 실패: " + survival.get("error", ""))
    width = len(query.expressions)
    final_result = final_result or execute_sql(sql, fixture(problem))
    # sqlglot spells IS NOT NULL as NOT ... IS NULL. SQLite uses the SQL
    # spelling as an unaliased output label, so identical AST projections can
    # have different labels in the tracing query. Bind only proven identical
    # projection positions to the untouched original query's output labels.
    if (query.expressions != survival_query.expressions[:width]
            or len(final_result.get("columns", [])) != width):
        raise ValueError("추적 질의의 출력 위치를 원본 SELECT와 연결하지 못했습니다.")
    projection_binding = {"status": "same_ast_projection_positions", "original_columns": final_result["columns"],
                          "trace_columns": survival["columns"][:width]}
    projected = {"status":"executed", "columns":final_result["columns"],
                 "rows":[row[:width] for row in survival["rows"]]}
    if not compare_results(projected, {"columns":final_result.get("columns", []),
            "rows":final_result.get("rows", []), "row_order":"unordered", "numeric_abs_tolerance":1e-8}):
        raise ValueError("그룹 추적과 원본 SELECT 결과가 일치하지 않습니다.")
    surviving_keys = {tuple(row[width:]) if group_names else () for row in survival["rows"]}
    intermediate["columns"] = list(final_result["columns"])
    where = query.args.get("where")
    return {"kind": "logical_teaching_steps_not_physical_execution", "table_id": display["id"],
            "where_sql": where.sql(dialect="sqlite") if where else None,
            "where_columns": list(dict.fromkeys(names[lookup[column.name.casefold()]] for column in where.find_all(exp.Column))) if where else [],
            "filtered_row_ids": [display["row_ids"][i] for i in indices],
            "group_columns": group_names, "groups": [{"values": list(key), "row_ids": [display["row_ids"][i] for i in members],
                "having_passed": key in surviving_keys} for key, members in groups.items()],
            "aggregates": aggregates, "before_having": intermediate,
            "projection_binding": projection_binding,
            "having_sql": query.args["having"].sql(dialect="sqlite") if query.args.get("having") else None}


def verify_answer(problem, raw_response, question, hypothesis=None):
    base = copy.deepcopy(problem)
    scope_problem, hypothesis_value = derive_hypothesis(base, hypothesis) if hypothesis else (base, None)
    scenario = "hypothesis" if hypothesis_value else "original"
    evidence = {"id": "evidence-" + hashlib.sha256(canonical({"problem": base, "hypothesis": hypothesis_value, "question": question}).encode()).hexdigest()[:20],
        "problem_id": base["id"], "problem_revision": base["revision"], "task_kind":base["task_kind"], "scenario": scenario, "hypothesis": hypothesis_value,
        "input": {"status": "user_confirmed" if base["confirmed"] else "unconfirmed", "source": base["source"]},
        "schema": {"status": "not_checked"}, "execution": {"status": "not_run", "dialect": base["dialect"]},
        "calculation": {"status": "not_checked"}, "intent": {"status": "not_checked"},
        "expected_result_check": {"status": "not_available", "reason": "실사용 문제에 독립 정답이 제공되지 않았습니다."},
        "explanation": {"status": "not_verified"}, "human_review": "not_reviewed",
        "original_tables": [identified_table(base, t) for t in base["tables"]],
        "working_tables": [identified_table(scope_problem, t, namespace=scenario) for t in scope_problem["tables"]],
        "result": None, "logical_steps": None, "status": "needs_input", "can_repair": False, "reasons": []}
    def stop(reason, status="needs_input", repair=False):
        evidence.update(status=status, reasons=[reason], can_repair=repair)
        return evidence
    if base["task_kind"] == "concept":
        return stop("일반 설명은 자동 진실성 검증 대상이 아닙니다. 새 예시는 설명용으로 표시합니다.", "concept_unverified")
    if not base["confirmed"]:
        return stop("원본 표·SQL·조건을 확인하고 확정해 주세요.")
    if base["missing_conditions"]:
        return stop("필요한 조건: " + "; ".join(base["missing_conditions"]))
    if base["dialect"] != "sqlite":
        return stop(f"{base['dialect']} 문제는 SQLite로 정확성을 검증하지 않습니다. DBMS에 맞는 실행 결과 또는 조건이 필요합니다.", "unsupported")
    if not base["tables"]:
        return stop("수치 결과를 계산할 원본 표의 열 이름·자료형·행 값이 필요합니다.")
    supplied = base["task_kind"] in {"query_result", "explain_error"}
    if supplied:
        sql = base.get("query")
        if not sql:
            # Aggregate requests with no supplied SQL can still be computed
            # from an unambiguous, bounded requested intent.
            intent, reason = infer_basic_intent(base, base["raw_text"])
            if not intent:
                return stop("실행할 원문 SQL이 필요합니다. " + reason)
            sql = intent_sql(intent)
            evidence["intent"] = {"status": "supported_match", "scope": reason, "requested": intent}
            evidence["sql_origin"] = "application_from_confirmed_bounded_intent"
        else:
            evidence["intent"] = {"status": "given_query_result", "scope": "학생이 제공한 SQL 자체의 실행 결과. 그 SQL이 다른 자연어 목적에 맞는지는 별개입니다."}
            evidence["sql_origin"] = "unchanged_user_query"
    else:
        try:
            evidence["sql_extraction_protocol"] = SQL_EXTRACTION_PROTOCOL
            sql = extract_sql_candidate(raw_response)
        except ValueError:
            return stop("모델 SQL 후보를 명확히 추출하지 못했습니다.", "stopped", True)
        evidence["sql_origin"] = "model_candidate"
        evidence["intent"], _ = check_intent(sql, base, base["raw_text"])
    evidence["sql"] = sql
    actual = execute_sql(sql, fixture(scope_problem), dialect=base["dialect"])
    evidence["execution"] = {**actual, "dialect": base["dialect"]}
    if actual["status"] != "executed":
        evidence["schema"] = {"status": "failed", "reason": actual.get("error")}
        return stop("원문 스키마에서 SQL을 실행하지 못했습니다: " + actual.get("error", actual["status"]), "stopped", not supplied)
    evidence["schema"] = {"status": "resolved_by_sqlite_prepare", "scope": "별칭·CTE를 포함한 SQLite 이름 해석과 안전한 실행"}
    if evidence["intent"]["status"] not in {"given_query_result", "supported_match"}:
        return stop(evidence["intent"].get("reason", evidence["intent"].get("scope", "질문 의도 확인 불가")), "stopped", evidence["intent"]["status"] == "mismatch")
    evidence["result"] = {"columns": actual["columns"], "rows": actual["rows"]}
    try:
        evidence["logical_steps"] = logical_evidence(sql, scope_problem, scenario, actual)
        evidence["calculation"] = {"status": "independent_aggregate_match", "scope": "원본 값의 COUNT/SUM/AVG 및 숫자 MIN/MAX를 별도 계산하여 SQLite 집계 결과와 비교"}
    except (ValueError, KeyError, sqlglot.errors.ParseError) as exc:
        evidence["calculation"] = {"status": "outside_supported_trace", "reason": str(exc)}
    evidence.update(status="verified", can_repair=False)
    evidence["explanation"] = {"status": "tool_derived_numeric_statements_only", "scope": "수치·표·집계 대사만 공유 근거에서 생성. 모델 자유 설명 전체는 검증하지 않음."}
    return evidence


def display_answer(evidence):
    if evidence["status"] != "verified":
        return "확인 필요: " + " ".join(evidence["reasons"])
    prefix = "설명용 새 가정의 결과입니다. 원래 문제의 값은 바꾸지 않았습니다.\n" if evidence["scenario"] == "hypothesis" else "확정한 원본 문제를 기준으로 도구가 계산한 결과입니다. 모델 초안과 구분합니다.\n"
    if evidence.get("app_correction"):
        prefix += "모델 SQL에 집계 의도 오류가 있어 앱이 확인된 연산으로 다시 구성했습니다. 원시 답변과 오류 기록은 보존했습니다.\n"
    result = evidence["result"]
    lines = [" | ".join(result["columns"])]
    lines.extend(" | ".join("NULL" if v is None else str(v) for v in row) for row in result["rows"])
    if not result["rows"]:
        lines.append("결과 행이 없습니다.")
    sql = "```sql\n" + evidence["sql"] + "\n```\n" if evidence.get("task_kind") == "write_sql" else ""
    return prefix + sql + "\n".join(lines)
