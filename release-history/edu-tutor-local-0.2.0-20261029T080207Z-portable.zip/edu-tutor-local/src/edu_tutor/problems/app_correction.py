"""Derive a bounded app calculation without relabelling a model error.

This path only uses an intent independently extracted from the confirmed
question. It cannot repair an unknown intent, syntax error, missing schema,
unsupported trace or a student-supplied SQL question.
"""
from __future__ import annotations

import copy
import hashlib
import json

from .evidence import intent_sql, verify_answer
from .models import canonical, infer_basic_intent


def verify_with_app_correction(problem, raw_response, question, hypothesis=None):
    original = verify_answer(problem, raw_response, question, hypothesis)
    if (problem.get("task_kind") != "write_sql" or hypothesis is not None
            or original.get("status") != "stopped"
            or original.get("execution", {}).get("status") != "executed"
            or original.get("intent", {}).get("status") != "mismatch"
            or original["intent"].get("scope") != "bounded_language_aggregate"):
        return original
    requested, scope = infer_basic_intent(problem, problem["raw_text"])
    if (scope != "bounded_language_aggregate" or not requested
            or canonical(requested) != canonical(original["intent"].get("requested"))):
        return original
    # Never derive predicates from the failed model answer. This narrow language
    # adapter has already rejected conditions, grouping and ordering it cannot
    # prove. Keep that boundary explicit even if the adapter later expands.
    if any(requested.get(k) for k in ("where", "having", "group_by")):
        return original
    corrected_sql = intent_sql(requested)
    checked = verify_answer(problem, json.dumps({"sql": corrected_sql}), question)
    if (checked.get("status") != "verified"
            or checked.get("calculation", {}).get("status") != "independent_aggregate_match"
            or not checked.get("logical_steps")):
        return original
    checked["sql_origin"] = "application_correction_from_confirmed_bounded_intent"
    checked["app_correction"] = {
        "kind": "bounded_aggregate_reconstruction_v1",
        "new_model_calls": 0,
        "raw_model_response_sha256": hashlib.sha256(raw_response.encode("utf-8")).hexdigest(),
        "original_candidate": copy.deepcopy(original),
        "corrected_sql": corrected_sql,
        "reason": "모델 SQL의 집계 의도 불일치를 보존하고, 확정한 질문의 집계 구조에서 앱이 별도 계산했습니다.",
        "model_answer_status": "incorrect_intent_not_promoted",
        "scope": "조건·그룹·정렬 없는 단일 표 집계; SQLite와 독립 중간 계산 모두 일치",
    }
    return checked
